"""
Flask 웹 대시보드 — 세션 인식 자동매매
"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))

import json
import time
import threading
from datetime import datetime

from flask import Flask, render_template, jsonify, request, redirect, url_for, session, send_from_directory
from flask_socketio import SocketIO, emit
from flask_cors import CORS
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.interval import IntervalTrigger

from config import Config
from utils.logger import get_logger
from utils.notifier import TelegramNotifier
from utils.market_session import session_info, is_tradeable, SESSION_OFF, us_session_info, is_us_tradeable

logger   = get_logger("Dashboard")
notifier = TelegramNotifier()

app = Flask(__name__, template_folder="templates", static_folder="static")
app.secret_key = Config.FLASK_SECRET_KEY
CORS(app)
socketio = SocketIO(app, cors_allowed_origins="*", async_mode="threading")

# ── 글로벌 상태 ────────────────────────────────────────────
_api          = None
_strategy_mgr = None
_us_strategy  = None      # ★ 해외주식 전략 매니저
_scheduler    = None
_bot_running  = False

# ── 해외주식 관심종목 (티커 기반) ──────────────────────────
_us_watch_list   = []     # [{"symbol":"NVDA","name":"엔비디아","excd":"NASD"}, ...]
_us_last_signals = {}     # symbol → 최근 신호

# ── 봇 상태 영속 파일 (재시작해도 유지) ──────────────────────
_BOT_STATE_FILE = os.path.join(os.path.dirname(__file__), "data", "bot_state.json")

def _save_bot_state(running: bool):
    """봇 실행 상태를 파일에 저장 (supervisord 재시작 후에도 복원용)"""
    try:
        os.makedirs(os.path.dirname(_BOT_STATE_FILE), exist_ok=True)
        import json as _json
        with open(_BOT_STATE_FILE, "w") as f:
            _json.dump({"running": running, "saved_at": datetime.now().isoformat()}, f)
    except Exception as e:
        logger.warning(f"봇 상태 저장 실패: {e}")

def _load_bot_state() -> bool:
    """저장된 봇 실행 상태 로드"""
    try:
        if os.path.exists(_BOT_STATE_FILE):
            import json as _json
            data = _json.load(open(_BOT_STATE_FILE))
            return bool(data.get("running", False))
    except Exception:
        pass
    return False

# ★ 관심종목 목록: .env WATCH_LIST_CODES 우선, 없으면 빈 리스트
# (스크리너가 자동으로 종목을 발굴해 채웁니다)
def _build_watch_list() -> list:
    codes_env = os.environ.get("WATCH_LIST_CODES", "").strip()
    if codes_env:
        NAME_MAP = {
            "005930": "삼성전자", "000660": "SK하이닉스", "035420": "NAVER",
            "035720": "카카오", "373220": "LG에너지솔루션", "005380": "현대차",
            "000270": "기아", "051910": "LG화학", "006400": "삼성SDI",
            "207940": "삼성바이오로직스",
        }
        return [{"code": c.strip(), "name": NAME_MAP.get(c.strip(), c.strip())}
                for c in codes_env.split(",") if c.strip()]
    return []

_watch_list   = _build_watch_list()
_last_signals = {}
_status_log   = []

# ── 전략 실험실 ───────────────────────────────────────────
_lab_engine   = None    # StrategyLabEngine 인스턴스 (지연 초기화)


def _log(msg: str, level: str = "info"):
    entry = {"time": datetime.now().strftime("%H:%M:%S"), "msg": msg, "level": level}
    _status_log.append(entry)
    if len(_status_log) > 150:
        _status_log.pop(0)
    socketio.emit("log", entry)


# ── 스크리닝 DB에서 오늘 매수후보 → 관심종목 자동 로드 ──────
def _load_screener_candidates():
    """앱 시작 시 오늘 스크리닝 결과가 있으면 관심종목에 반영"""
    global _watch_list
    try:
        from screener.screener_db import get_buy_candidates
        cands = get_buy_candidates()   # 오늘 날짜 기준
        if not cands:
            return
        existing_codes = {s["code"] for s in _watch_list}
        added = []
        for c in cands:
            code = c.get("code", "")
            name = c.get("name", code)
            if code and code not in existing_codes:
                _watch_list.append({"code": code, "name": name})
                existing_codes.add(code)
                added.append(name)
        if added:
            logger.info(f"[시작] 스크리닝 후보 자동 로드: {', '.join(added)}")
    except Exception as e:
        logger.warning(f"[시작] 스크리닝 후보 로드 실패 (무시): {e}")


# ── API 초기화 ────────────────────────────────────────────
def _init_api() -> bool:
    global _api, _strategy_mgr, _us_strategy, _us_watch_list
    from api.kis_api import KISApi
    from strategies.strategy_manager import StrategyManager
    from strategies.us_strategy_manager import USStrategyManager, DEFAULT_US_WATCHLIST
    try:
        _api          = KISApi()
        _strategy_mgr = StrategyManager(_api)
        _log("✅ KIS API 초기화 완료")

        # ★ 해외주식 전략 매니저 초기화
        max_us_usd   = float(os.environ.get("MAX_US_INVESTMENT_USD", 3000.0))
        _us_strategy = USStrategyManager(_api, max_total_usd=max_us_usd)

        # ★ 해외주식 기본 관심종목 로드 (.env US_WATCH_LIST 우선)
        env_us = os.environ.get("US_WATCH_LIST", "").strip()
        if env_us:
            for item in env_us.split(","):
                parts = item.strip().split(":")
                sym  = parts[0].strip().upper()
                excd = parts[1].strip().upper() if len(parts) > 1 else "NASD"
                name = DEFAULT_US_WATCHLIST.get(sym, {}).get("name", sym)
                if sym and not any(s["symbol"] == sym for s in _us_watch_list):
                    _us_watch_list.append({"symbol": sym, "name": name, "excd": excd})
        else:
            for sym, info in DEFAULT_US_WATCHLIST.items():
                _us_watch_list.append({"symbol": sym, **info})

        # ★ 해외주식 잔고 기반 포지션 자동 복원
        _us_strategy.sync_from_balance()
        _log(f"✅ 해외주식 초기화 완료 — 관심종목 {len(_us_watch_list)}개", "info")

        # ★ API 초기화 후 오늘 스크리닝 후보 관심종목에 자동 반영
        _load_screener_candidates()
        # ★ 실제 잔고 기반 피라미딩 포지션 자동 복원
        _sync_positions_from_balance()
        return True
    except Exception as e:
        _log(f"❌ API 초기화 실패: {e}", "error")
        return False


def _sync_positions_from_balance():
    """
    실제 KIS 잔고 ↔ 봇 피라미딩 포지션 완전 동기화.
    1) 누락 종목 → 자동 등록 (500에러 등으로 포지션 미등록된 경우 복원)
    2) avg_price 불일치 → KIS 실제 평균단가로 교정
       (pyramid_positions.json에 잘못된 avg_price가 기록된 경우 수정)
    ★ 손절 기준이 avg_price 기반이므로 이 값이 정확해야 손절이 작동함
    """
    global _strategy_mgr
    if _strategy_mgr is None:
        return
    try:
        balance = _api.get_balance()
        holdings = balance.get("holdings", [])
        if not holdings:
            return
        pyramid = _strategy_mgr.pyramid
        synced  = []
        corrected = []

        for h in holdings:
            code      = h.get("code", "")
            name      = h.get("name", code)
            qty       = int(h.get("qty", 0))
            avg_price = float(h.get("avg_price", 0))   # KIS 실제 평균단가
            if not code or qty <= 0 or avg_price <= 0:
                continue

            if code not in pyramid.positions:
                # ── 미등록 종목 → 1단계로 자동 등록 ──
                pyramid.apply_buy(code, name, 1, qty, avg_price, using_compound=0)
                synced.append(f"{name}({code}) {qty}주 @{avg_price:,.0f}원")
            else:
                # ── 등록된 종목 → avg_price 불일치 교정 ──
                pos = pyramid.positions[code]
                bot_avg = pos.avg_price
                # 차이가 1% 이상이면 KIS 잔고 기준으로 교정
                if bot_avg > 0 and abs(bot_avg - avg_price) / avg_price > 0.01:
                    old_avg = pos.avg_price
                    pos.avg_price    = avg_price
                    pos.entry_price  = avg_price
                    pos.total_qty    = qty
                    # level_entries 도 교정
                    for lvl_key in pos.level_entries:
                        pos.level_entries[lvl_key]["avg_price"] = avg_price
                        pos.level_entries[lvl_key]["price"]     = avg_price
                        pos.level_entries[lvl_key]["qty"]       = qty
                        pos.level_entries[lvl_key]["remaining"] = qty
                    corrected.append(
                        f"{name}({code}) avg: {old_avg:,.0f}→{avg_price:,.0f}원"
                    )

        pyramid._save()

        if synced:
            _log(f"🔄 포지션 자동 복원: {', '.join(synced)}", "info")
        if corrected:
            _log(f"🔧 포지션 avg_price 교정 (KIS 잔고 기준): {', '.join(corrected)}", "info")
        if not synced and not corrected:
            logger.info("[포지션동기화] 모든 보유종목 포지션 일치 — 복원 불필요")
    except Exception as e:
        logger.warning(f"[포지션동기화] 실패 (무시): {e}")


# ── 봇 자동 시작 (앱 기동 시 이전 상태 복원) ─────────────────
def _auto_start_bot():
    """supervisord 재시작 후 이전에 봇이 실행 중이었으면 자동으로 재개"""
    global _bot_running, _scheduler
    if not _load_bot_state():
        logger.info("[자동시작] 이전 봇 상태: 정지 — 자동 시작 안 함")
        return
    logger.info("[자동시작] 이전 봇 상태: 실행 중 → 봇 자동 재개...")
    if _api is None and not _init_api():
        logger.error("[자동시작] API 초기화 실패 — 봇 자동 시작 불가")
        return
    _bot_running = True
    if _scheduler is None or not _scheduler.running:
        _scheduler = BackgroundScheduler(timezone="Asia/Seoul")
        sess = session_info()
        _scheduler.add_job(_trading_loop,  "interval", seconds=sess["check_sec"],
                           id="trading_loop",       replace_existing=True)
        _scheduler.add_job(_session_watcher, "interval", seconds=30,
                           id="session_watcher",    replace_existing=True)
        _scheduler.add_job(_daily_screen_job, "cron", hour=16, minute=5,
                           timezone="Asia/Seoul",   id="daily_screener",   replace_existing=True)
        _scheduler.add_job(_weekly_lab_ranking_job, "cron", day_of_week="mon", hour=9, minute=0,
                           timezone="Asia/Seoul",   id="weekly_lab_ranking", replace_existing=True)
        _scheduler.add_job(_us_market_job, "cron", hour=0, minute=0,
                           timezone="Asia/Seoul",   id="us_market_screener", replace_existing=True)
        _scheduler.start()
        # ★ 자동 재개 시 토큰 안정화 후 1회 신호 점검 (15초 딜레이)
        def _delayed_loop():
            time.sleep(15)
            _trading_loop()
        threading.Thread(target=_delayed_loop, daemon=True).start()
    logger.info("[자동시작] ✅ 봇 자동 재개 완료")


# ── ETF 포지션 비중 계산 헬퍼 ──────────────────────────────
def _get_etf_position_ratio(asset_type: str, regime: str) -> float:
    """
    국면 + 자산군에 따른 ETF 단일 종목 투자 비중 반환.
    계좌 총 자산 대비 비율.
      BULL + 레버리지 → 10% (레버리지는 보수적으로)
      BULL + 일반ETF  → 10%
      LATERAL + 일반  → 12% (횡보장엔 ETF 비중 높임)
      LATERAL + 인버스→  5% (소량 헤지)
      BEAR + 인버스   → 15% (하락장 방어)
      BEAR + 일반ETF  →  8%
    """
    table = {
        ("BULL",    "ETF_LEVERAGE"): 0.10,
        ("BULL",    "ETF_GENERAL"):  0.10,
        ("BULL",    "ETF_INVERSE"):  0.00,
        ("LATERAL", "ETF_GENERAL"):  0.12,
        ("LATERAL", "ETF_INVERSE"):  0.05,
        ("LATERAL", "ETF_LEVERAGE"): 0.00,
        ("BEAR",    "ETF_INVERSE"):  0.15,
        ("BEAR",    "ETF_GENERAL"):  0.08,
        ("BEAR",    "ETF_LEVERAGE"): 0.00,
    }
    return table.get((regime, asset_type), 0.08)


def _detect_current_regime() -> str:
    """
    마지막 스크리닝 결과 또는 실시간 지수 기반 시장 국면 반환.
    스크리닝 결과가 있으면 그것을 우선 사용.
    """
    if _last_screen and _last_screen.get("regime"):
        return _last_screen["regime"]
    # 기본값 LATERAL (보수적)
    return "LATERAL"


# ── 세션 인식 매매 루프 ───────────────────────────────────
def _trading_loop():
    if not _bot_running or _strategy_mgr is None:
        return

    sess = session_info()

    # ── ★ 국내 휴장이어도 미국장 + 손절 점검은 반드시 실행 ──────
    if not sess["tradeable"]:
        _log(f"😴 [{sess['time_kst']}] 국내 휴장 — 손절 점검 + 미국장 체크...", "info")
        # ★ 장 마감 중에도 포지션 손절 감시 (고아종목 포함)
        try:
            _orphan_loss_cut()
        except Exception as _e:
            _log(f"❌ 손절 점검 오류: {_e}", "error")
        _us_trading_loop()   # 미국 정규장이면 실행, 아니면 내부에서 스킵
        return

    regime = _detect_current_regime()
    _log(
        f"{sess['icon']} [{sess['time_kst']}] {sess['session']} "
        f"({sess['order_label']}) 신호 점검... [국면:{regime}]",
        "info"
    )

    for stock in list(_watch_list):
        try:
            code       = stock["code"]
            name       = stock["name"]
            asset_type = stock.get("asset_type", "")

            # ── ETF 전용 매매 경로 ─────────────────────────────
            from screener.asset_universe import (
                ASSET_ETF_GENERAL, ASSET_ETF_LEVERAGE, ASSET_ETF_INVERSE,
                is_etf, classify_asset_type, ETF_CODE_MAP,
            )
            # asset_type 없으면 코드/이름으로 자동 판별
            if not asset_type:
                asset_type = ETF_CODE_MAP.get(code, {}).get("asset_type") or \
                             classify_asset_type(code, name, "")
                stock["asset_type"] = asset_type  # 캐싱

            if is_etf(asset_type):
                _handle_etf_trade(stock, asset_type, regime, sess)
                continue

            # ── 개별주식 매매 (기존 로직) ──────────────────────
            result = _strategy_mgr.run(stock)
            _last_signals[code] = result
            action = result.get("action", "HOLD")

            if action == "BUY":
                _log(
                    f"🟢 매수 [{result.get('session','')}] "
                    f"{name} {result['price']:,}원 × {result['qty']}주",
                    "buy"
                )
                notifier.notify_buy(
                    name, code,
                    result["price"], result["qty"],
                    result.get("reason", "")
                )
            elif action == "BUY_FAIL":
                # ── BUY_FAIL 상세 원인 표시 ──────────────────────────
                fail_reason = result.get("reason") or "KIS API 주문 거부"
                _log(
                    f"❌ BUY_FAIL [{name}] — KIS 주문 실패: {fail_reason} "
                    f"(계좌:{Config.KIS_ACCOUNT_NO})",
                    "error"
                )
            elif action == "SELL":
                profit = result.get("profit", 0)
                emoji  = "💰" if profit >= 0 else "🔴"
                _log(
                    f"{emoji} 매도 [{result.get('session','')}] "
                    f"{name}  손익 {profit:+,.0f}원",
                    "sell" if profit >= 0 else "error"
                )
                notifier.notify_sell(
                    name, code,
                    result["price"], result["qty"],
                    profit, result.get("reason", "")
                )
            elif action == "HOLD":
                _log(
                    f"⏸ {name}  BUY={result.get('buy_score',0):.2f} "
                    f"SELL={result.get('sell_score',0):.2f} "
                    f"(기준 ≥{result.get('cutoff',0.55)})",
                    "info"
                )
        except Exception as e:
            _log(f"❌ {stock['name']} 오류: {e}", "error")

    # ── 관심종목 미등록 보유 종목 자동 손절 (고아 종목 처리) ─────
    try:
        _orphan_loss_cut()
    except Exception as _e:
        _log(f"❌ 고아 종목 손절 오류: {_e}", "error")

    # ── ★ 해외주식 매매 루프 (미국 정규장 중일 때만) ──────────
    _us_trading_loop()

    # 잔고 실시간 업데이트
    try:
        balance = _api.get_balance()
        socketio.emit("balance_update", balance)
    except Exception:
        pass


# ── ★ 해외주식 매매 루프 ─────────────────────────────────────
def _us_trading_loop():
    """
    미국 정규장(ET 09:30~16:00) 중 호출.
    _us_watch_list 종목들을 순회하며 USStrategyManager.run() 실행.
    """
    global _us_last_signals
    if not _bot_running or _us_strategy is None:
        return

    us_sess = us_session_info()
    if not us_sess["tradeable"]:
        return   # 미국 휴장 시 조용히 스킵

    _log(f"🇺🇸 [{us_sess['time_et']}] 해외주식 신호 점검...", "info")

    for stock in list(_us_watch_list):
        symbol = stock.get("symbol", "")
        name   = stock.get("name", symbol)
        try:
            result = _us_strategy.run(stock)
            _us_last_signals[symbol] = result
            action = result.get("action", "HOLD")

            if action == "BUY":
                _log(
                    f"🟢 [US매수] {name}({symbol}) "
                    f"${result['price']:.2f} × {result['qty']}주 "
                    f"≈ ${result.get('amount_usd',0):.0f}",
                    "buy"
                )
            elif action == "BUY_FAIL":
                _log(f"❌ [US BUY_FAIL] {name}({symbol}) — {result.get('reason','')}", "error")
            elif action == "SELL":
                emoji = "💰" if result.get("pnl_usd", 0) >= 0 else "🔴"
                _log(
                    f"{emoji} [US매도] {name}({symbol}) "
                    f"손익 ${result.get('pnl_usd',0):+.2f} ({result.get('pnl_pct',0):+.1f}%)",
                    "sell"
                )
            # HOLD/SKIP 은 로그 미출력 (노이즈 방지)
        except Exception as e:
            _log(f"❌ [US] {name}({symbol}) 오류: {e}", "error")

    # 해외잔고 실시간 업데이트
    try:
        us_bal = _api.get_us_balance()
        socketio.emit("us_balance_update", us_bal)
    except Exception:
        pass


def _handle_etf_trade(stock: dict, asset_type: str, regime: str, sess: dict):
    """
    ETF 전용 매매 로직.
    국면(BULL/LATERAL/BEAR) + 기술적 점수 기반으로 매수/매도 결정.

    전략:
      - 매수: 가격이 MA20 위에 있고 국면이 해당 ETF에 적합하면 매수
      - 매도: 손절(-7%) 또는 국면 변경으로 부적합해진 경우 매도
      - 포지션 크기: _get_etf_position_ratio() 기준
    """
    from screener.asset_universe import (
        ASSET_ETF_LEVERAGE, ASSET_ETF_INVERSE, ASSET_ETF_GENERAL,
    )
    code = stock["code"]
    name = stock["name"]

    # 레버리지 ETF — BULL 아니면 즉시 매도 (이미 보유한 경우)
    if asset_type == ASSET_ETF_LEVERAGE and regime != "BULL":
        _etf_force_sell(code, name, f"국면전환({regime}) — 레버리지 해제")
        return

    # 인버스 ETF — BULL 국면에서 보유 중이면 즉시 매도
    if asset_type == ASSET_ETF_INVERSE and regime == "BULL":
        _etf_force_sell(code, name, f"BULL 전환 — 인버스 헤지 해제")
        return

    try:
        if _api is None:
            return

        # 현재가 + MA20 조회 (일봉 20개)
        candles = _api.get_ohlcv(code, period="D", count=25)
        if len(candles) < 20:
            _log(f"⚠️ ETF {name} — 캔들 데이터 부족({len(candles)}개)", "info")
            return

        closes  = [c["close"] for c in candles]
        ma20    = sum(closes[-20:]) / 20
        cur     = closes[-1]
        ret_pct = (cur - closes[-2]) / closes[-2] * 100 if len(closes) >= 2 else 0

        # 기보유 여부 확인 (KIS 실계좌)
        bal         = _api.get_balance()
        holdings    = {h["code"]: h for h in bal.get("holdings", [])}
        total_eval  = bal.get("total_eval", 0) or Config.MAX_TOTAL_INVESTMENT
        is_held     = code in holdings

        # ─ 매도 판단 ───────────────────────────────────────────
        if is_held:
            pos    = holdings[code]
            avg_px = float(pos.get("avg_price", cur))
            pnl    = (cur - avg_px) / avg_px * 100

            stop_loss_pct = -7.0   # ETF 손절선 (개별주식보다 타이트)

            if pnl <= stop_loss_pct:
                qty = pos.get("qty", 1)
                _log(f"🔴 ETF 손절매도 {name} PnL:{pnl:.1f}% (≤{stop_loss_pct}%)", "sell")
                try:
                    _api.sell(code, qty, cur)
                    notifier.notify_sell(name, code, cur, qty, (cur-avg_px)*qty, f"ETF손절{pnl:.1f}%")
                except Exception as e:
                    _log(f"❌ ETF 손절 주문 실패 {name}: {e}", "error")
                return

            # 인버스/일반: MA20 아래로 내려왔고 수익 중이면 익절
            if asset_type in (ASSET_ETF_INVERSE, ASSET_ETF_GENERAL):
                if cur < ma20 * 0.98 and pnl >= 5.0:
                    qty = pos.get("qty", 1)
                    _log(f"💰 ETF 익절매도 {name} PnL:{pnl:.1f}% (MA20 하향 이탈)", "sell")
                    try:
                        _api.sell(code, qty, cur)
                        notifier.notify_sell(name, code, cur, qty, (cur-avg_px)*qty, f"ETF익절{pnl:.1f}%")
                    except Exception as e:
                        _log(f"❌ ETF 익절 주문 실패 {name}: {e}", "error")
                    return

            _log(
                f"📦 ETF 보유 {name} [{asset_type}] "
                f"현재가:{cur:,} MA20:{ma20:,.0f} "
                f"PnL:{pnl:+.1f}%",
                "info"
            )
            _last_signals[code] = {
                "action": "HOLD", "price": cur, "pnl_pct": pnl,
                "asset_type": asset_type, "regime": regime,
                "buy_score": 0, "sell_score": 0,
            }
            return

        # ─ 매수 판단 ───────────────────────────────────────────
        # 조건: 현재가 > MA20 (상승 추세) + 국면 적합
        above_ma20 = cur > ma20

        # 인버스는 하락 추세(가격 < MA20)에서 매수
        if asset_type == ASSET_ETF_INVERSE:
            above_ma20 = cur < ma20  # 인버스: MA20 하회 = 지수 하락 = 인버스 매수 신호

        if not above_ma20:
            _log(
                f"⏸ ETF 대기 {name} [{asset_type}] "
                f"현재가:{cur:,} MA20:{ma20:,.0f} "
                f"({'MA20 상회 대기' if asset_type == ASSET_ETF_INVERSE else 'MA20 하회'})",
                "info"
            )
            _last_signals[code] = {
                "action": "HOLD", "price": cur,
                "asset_type": asset_type, "regime": regime,
                "buy_score": 0, "sell_score": 0,
            }
            return

        # 포지션 크기 계산
        ratio       = _get_etf_position_ratio(asset_type, regime)
        invest_amt  = int(total_eval * ratio)
        invest_amt  = max(invest_amt, 100_000)   # 최소 10만원
        invest_amt  = min(invest_amt, Config.MAX_INVESTMENT_PER_STOCK)
        qty         = max(1, invest_amt // cur)

        # 레이블
        type_label  = {"ETF_LEVERAGE": "🔶 레버리지", "ETF_INVERSE": "🔴 인버스",
                       "ETF_GENERAL":  "📦 일반ETF"}.get(asset_type, "ETF")

        _log(
            f"🟢 ETF 매수 {type_label} {name} "
            f"{cur:,}원 × {qty}주 "
            f"({ratio*100:.0f}% / {invest_amt:,}원) [국면:{regime}]",
            "buy"
        )
        try:
            _api.buy(code, qty, cur)
            notifier.notify_buy(name, code, cur, qty,
                                f"ETF매수({asset_type}/{regime})")
        except Exception as e:
            _log(f"❌ ETF 매수 주문 실패 {name}: {e}", "error")

        _last_signals[code] = {
            "action": "BUY", "price": cur, "qty": qty,
            "asset_type": asset_type, "regime": regime,
            "buy_score": 1, "sell_score": 0,
        }

    except Exception as e:
        _log(f"❌ ETF 처리 오류 {name}: {e}", "error")


def _etf_force_sell(code: str, name: str, reason: str):
    """국면 변경으로 ETF 강제 매도 (보유 중인 경우에만)"""
    if _api is None:
        return
    try:
        bal      = _api.get_balance()
        holdings = {h["code"]: h for h in bal.get("holdings", [])}
        if code not in holdings:
            return
        pos = holdings[code]
        qty = pos.get("qty", 0)
        cur = pos.get("cur_price", 0)
        avg = pos.get("avg_price", cur)
        if qty > 0:
            _api.sell(code, qty, cur)
            pnl = (cur - avg) * qty
            _log(f"🔄 ETF 강제매도 {name} — {reason} | 손익:{pnl:+,.0f}원", "sell")
            notifier.notify_sell(name, code, cur, qty, pnl, reason)
    except Exception as e:
        _log(f"❌ ETF 강제매도 실패 {name}: {e}", "error")


def _orphan_loss_cut():
    """
    보유 종목 전체 손절·트레일링 감시 (관심종목 등록 여부 무관).

    매 루프마다 KIS 실제 잔고의 모든 종목을 순회해서:
      1) 실질수익률 ≤ STOP_LOSS_PCT(-3%)      → 즉시 전량 손절
      2) 트레일링 활성화 후 고점대비 ≤ -2%    → 즉시 전량 매도
    watch_list 에 있는 종목도 포함 (strategy_manager 가 SKIP 한 경우 이중 보장)
    """
    if _api is None:
        return
    try:
        from strategies.pyramid_strategy import (
            STOP_LOSS_PCT, TRAILING_STOP_PCT, TRAILING_ACTIVATE_PCT,
            price_for_net_pct_from_cost,
        )
        from screener.transaction_cost import net_profit_pct_from_cost

        bal      = _api.get_balance()
        holdings = bal.get("holdings", [])
        if not holdings:
            return

        # pyramid 객체에서 직접 PyramidPosition 접근 (avg_price, highest_price)
        pyramid_obj = _strategy_mgr.pyramid if _strategy_mgr else None

        for h in holdings:
            code = h.get("code", "")
            name = h.get("name", code)
            qty  = int(h.get("qty", 0))
            if qty <= 0 or not code:
                continue

            # ── avg_price: pyramid 객체 우선, 없으면 KIS 잔고 ──────────
            pyramid_pos_obj = pyramid_obj.positions.get(code) if pyramid_obj else None
            if pyramid_pos_obj is not None:
                avg_px      = float(pyramid_pos_obj.avg_price)
                highest_px  = float(pyramid_pos_obj.highest_price)
            else:
                avg_px      = float(h.get("avg_price", 0))
                highest_px  = avg_px
            if avg_px <= 0:
                continue

            # ── cur_price: KIS 잔고 우선, 0이면 API 직접 조회 ──────────
            cur_px = float(h.get("cur_price", 0))
            if cur_px <= 0:
                try:
                    cur_data = _api.get_current_price(code)
                    cur_px   = float(cur_data.get("price", 0))
                except Exception:
                    cur_px = 0
            if cur_px <= 0:
                # 오늘 OHLCV 마지막 종가 사용
                try:
                    candles = _api.get_ohlcv(code, period="D", count=1)
                    if candles:
                        cur_px = float(candles[-1].get("close", 0))
                        # 당일 고가도 반영
                        td_high = float(candles[-1].get("high", cur_px))
                        if pyramid_pos_obj and td_high > highest_px:
                            pyramid_pos_obj.update_high(td_high)
                            highest_px = pyramid_pos_obj.highest_price
                except Exception:
                    pass
            if cur_px <= 0:
                _log(f"⚠️ [{name}({code})] 현재가 조회 실패 — 손절 점검 스킵", "info")
                continue

            # highest_price 갱신
            if pyramid_pos_obj and cur_px > highest_px:
                pyramid_pos_obj.update_high(cur_px)
                highest_px = pyramid_pos_obj.highest_price

            # ── 실질수익률 + 트레일링 계산 ────────────────────────────
            net_pct    = net_profit_pct_from_cost(avg_px, cur_px)
            act_price  = price_for_net_pct_from_cost(avg_px, TRAILING_ACTIVATE_PCT)
            trail_pct  = (cur_px - highest_px) / highest_px * 100 if highest_px > 0 else 0
            is_orphan  = code not in {s["code"] for s in _watch_list}

            # ── 판단 ──────────────────────────────────────────────────
            sell_reason = None

            if net_pct <= STOP_LOSS_PCT:
                sell_reason = (
                    f"손절 실질{net_pct:.2f}% ≤ {STOP_LOSS_PCT}% "
                    f"(매입{avg_px:,.0f}원→현재{cur_px:,.0f}원)"
                )
            elif highest_px >= act_price and trail_pct <= TRAILING_STOP_PCT:
                sell_reason = (
                    f"트레일링스탑 고점대비{trail_pct:.2f}% ≤ {TRAILING_STOP_PCT}% "
                    f"(고점{highest_px:,.0f}원→현재{cur_px:,.0f}원, 실질{net_pct:+.2f}%)"
                )

            if sell_reason:
                tag = "고아종목 " if is_orphan else ""
                _log(
                    f"🔴 [{tag}자동매도] {name}({code}) {sell_reason} — 전량 매도",
                    "sell"
                )
                try:
                    result = _api.sell(code, qty, 0)  # 시장가 전량 매도
                    if result.get("rt_cd") == "0":
                        if pyramid_obj:
                            pyramid_obj.positions.pop(code, None)
                            pyramid_obj._save()
                        _log(f"✅ 매도 체결 완료: {name}({code}) {qty}주", "sell")
                    else:
                        _log(f"❌ 매도 주문 실패 {name}: {result.get('msg1','?')}", "error")
                except Exception as e:
                    _log(f"❌ 매도 주문 오류 {name}: {e}", "error")

            elif net_pct <= -2.0 and is_orphan:
                _log(
                    f"⚠️ [고아종목] {name}({code}) 실질{net_pct:.2f}% "
                    f"(손절선:{STOP_LOSS_PCT}%)", "info"
                )
            else:
                tag = "고아" if is_orphan else ""
                _log(
                    f"📋 [{tag}{name}({code})] 실질{net_pct:+.2f}% "
                    f"고점{highest_px:,.0f}원 트레일{trail_pct:+.1f}% — 홀드",
                    "info"
                )

        # 변경된 highest_price 저장
        if pyramid_obj:
            pyramid_obj._save()

    except Exception as e:
        _log(f"❌ 손절/트레일링 감시 오류: {e}", "error")


def _reschedule(interval_sec: int):
    """스케줄러 주기를 동적으로 변경"""
    global _scheduler
    if _scheduler and _scheduler.running:
        _scheduler.reschedule_job("trading_loop",
                                  trigger=IntervalTrigger(seconds=interval_sec))


def _session_watcher():
    """세션 변경 감지 → 스케줄 주기 자동 조정 (30초마다 체크)"""
    if not _bot_running:
        return
    sess = session_info()
    _reschedule(sess["check_sec"])
    socketio.emit("session_update", {
        "session":     sess["session"],
        "icon":        sess["icon"],
        "order_label": sess["order_label"],
        "check_sec":   sess["check_sec"],
        "tradeable":   sess["tradeable"],
        "time_kst":    sess["time_kst"],
    })


def _get_lab() -> "StrategyLabEngine":
    """
    StrategyLabEngine 인스턴스 반환 (지연 초기화).
    처음 호출 시 DB 및 전략 포트폴리오를 초기화한다.
    """
    global _lab_engine
    if _lab_engine is None:
        from strategy_lab.lab_engine import StrategyLabEngine
        _lab_engine = StrategyLabEngine()
        logger.info("[App] StrategyLabEngine 초기화 완료")
    return _lab_engine


def _apply_us_screen_to_watchlist(top_buy: list) -> dict:
    """
    미국 스크리닝 BUY 후보 → _us_watch_list 자동 반영
    ─────────────────────────────────────────────────
    규칙:
      1. 포지션 보유 종목은 무조건 유지 (강제 제거 X)
      2. BUY 후보 상위 MAX_US_WATCH개를 새 목록으로 교체
      3. 포지션 보유 중이나 BUY 후보에 없는 종목은 목록 하단에 유지
      4. BEAR 국면이면 watchlist 교체 보류 (기존 유지)
    반환: {"added": [...], "removed": [...], "kept": [...]}
    """
    global _us_watch_list

    MAX_US_WATCH = 10   # 최대 관심종목 수

    # 스크리닝 결과 없으면 스킵
    if not top_buy:
        return {"added": [], "removed": [], "kept": []}

    # 현재 포지션 보유 심볼 (강제 유지 대상)
    held_syms = set()
    if _us_strategy and _us_strategy.positions:
        held_syms = {sym for sym, p in _us_strategy.positions.items()
                     if (p.get("qty") or p.get("current_level", 0)) > 0}

    # 스크리닝 BUY 후보 → 딕셔너리 변환
    # excd 결정: 스크리닝 종목은 대부분 NASD/NYSE
    #   SPY·QQQ·SOXX·SOXS = NASD, 나머지 = NASD 기본
    NYSE_SYMS = {"JPM", "BAC", "GS", "JNJ", "UNH", "XOM", "CAT", "BA", "DIS", "WMT", "COST"}
    candidate_syms = []
    for c in top_buy:
        sym  = c.get("symbol", "")
        name = c.get("name",   sym)
        excd = "NYSE" if sym in NYSE_SYMS else "NASD"
        if sym:
            candidate_syms.append({"symbol": sym, "name": name, "excd": excd})

    # 새 watchlist 구성
    new_list  = []
    added     = []
    removed   = []
    kept      = []

    # ① BUY 후보를 우선 추가 (최대 MAX_US_WATCH개)
    for c in candidate_syms[:MAX_US_WATCH]:
        new_list.append(c)
        if not any(s["symbol"] == c["symbol"] for s in _us_watch_list):
            added.append(c["symbol"])

    # ② 포지션 보유 종목이 new_list에 없으면 하단에 추가 (강제 유지)
    for sym in held_syms:
        if not any(s["symbol"] == sym for s in new_list):
            old = next((s for s in _us_watch_list if s["symbol"] == sym), None)
            entry = old or {"symbol": sym, "name": sym, "excd": "NASD"}
            new_list.append(entry)
            kept.append(sym)

    # ③ 제거된 종목 계산 (기존에 있었으나 새 목록에 없는 것)
    old_syms = {s["symbol"] for s in _us_watch_list}
    new_syms = {s["symbol"] for s in new_list}
    removed  = list(old_syms - new_syms)

    _us_watch_list = new_list

    logger.info(
        f"🇺🇸 [스크리닝→관심종목] 추가:{added} | 제거:{removed} | 포지션유지:{kept} | "
        f"총 {len(_us_watch_list)}개"
    )
    return {"added": added, "removed": removed, "kept": kept}


def _us_market_job():
    """매일 00:00 KST — 미국 증시 야간 분석 + 관심종목 자동 갱신"""
    try:
        from screener.us_market_screener import run_us_screening
        _log("🇺🇸 [자동] 미국 증시 야간 분석 시작 (00:00)...", "info")
        result  = run_us_screening()
        s       = result.get("summary", {})
        regime  = s.get("regime", "?")
        sp500   = s.get("sp500_pct", 0)
        vix     = s.get("vix", 0)
        top_buy = result.get("top_buy", [])
        buy_cnt = s.get("buy_candidates", 0)
        _log(
            f"✅ [자동] 미국 분석 완료 — 국면:{regime} | "
            f"S&P500:{sp500:+.2f}% | VIX:{vix:.1f} | 매수후보:{buy_cnt}개",
            "info"
        )

        # ★ BEAR 국면이 아닐 때만 watchlist 자동 교체
        wl_diff = {}
        if regime != "BEAR" and top_buy:
            wl_diff = _apply_us_screen_to_watchlist(top_buy)
            added   = wl_diff.get("added", [])
            removed = wl_diff.get("removed", [])
            if added or removed:
                _log(
                    f"🇺🇸 [관심종목 갱신] +{added} / -{removed} → 총{len(_us_watch_list)}개",
                    "info"
                )
                # 텔레그램 알림
                pass  # 텔레그램 알림 미사용
        elif regime == "BEAR":
            _log("🐻 BEAR 국면 — 미국 관심종목 교체 보류 (기존 유지)", "info")

        # 텔레그램 알림 미사용
        socketio.emit("us_screen_done", {
            "summary":      s,
            "korea_impact": result.get("korea_impact", {}),
            "top_buy":      top_buy[:5],
            "wl_diff":      wl_diff,
            "watch_list":   _us_watch_list,
        })
    except Exception as e:
        _log(f"❌ [자동] 미국 분석 오류: {e}", "error")


def _weekly_lab_ranking_job():
    """APScheduler 에서 호출되는 주간 랭킹 계산 작업 (매주 월요일 09:00)"""
    try:
        from strategy_lab.lab_db import save_ranking_snapshot, save_ai_recs_from_ranking
        _log("📊 [자동] 전략 실험실 주간 랭킹 계산 시작...", "info")
        lab = _get_lab()
        ranking = lab.calc_ranking()
        regime  = lab.market_regime
        save_ranking_snapshot(ranking, regime)
        save_ai_recs_from_ranking(ranking, regime)
        top = ranking[0] if ranking else {}
        _log(
            f"✅ [자동] 랭킹 완료 — "
            f"1위: {top.get('name','?')} ({top.get('score',0):.1f}점) "
            f"| 국면: {regime}",
            "info",
        )
        socketio.emit("lab_ranking_done", {
            "ranking": ranking[:5],
            "regime":  regime,
        })
    except Exception as e:
        _log(f"❌ [자동] 랭킹 오류: {e}", "error")


def _apply_screen_result(result: dict):
    """
    스크리닝 결과(result)를 _watch_list에 반영하고 대시보드에 실시간 push.
    _daily_screen_job과 api_screener_run 양쪽에서 공유.
    """
    global _watch_list
    regime  = result.get("regime", "LATERAL")
    cnt     = result["summary"]["buy_candidate"]
    etf_cnt = result["summary"].get("etf_buy_candidate", 0)

    existing_codes = {s["code"] for s in _watch_list}
    added_stocks = []
    added_etfs   = []

    # ── ① 주식 매수후보 → 관심종목 추가 ────────────────────
    for c in result.get("candidates_10", [])[:10]:
        code = c.get("code", "")
        name = c.get("name", code)
        if code and code not in existing_codes:
            _watch_list.append({"code": code, "name": name, "asset_type": "STOCK_KOSPI"})
            existing_codes.add(code)
            added_stocks.append(name)

    # ── ② ETF 매수후보 → 관심종목 추가 (국면별 자동 반영) ──
    for e in result.get("etf_candidates", []):
        code      = e.get("code", "")
        name      = e.get("name", code)
        atype     = e.get("asset_type", "ETF_GENERAL")
        ai_score  = e.get("ai_score", 0)
        if not code:
            continue
        if atype == "ETF_LEVERAGE" and regime != "BULL":
            _log(f"⛔ ETF 제외({name}) — 레버리지는 BULL 국면에서만 허용 (현재:{regime})", "info")
            continue
        if atype == "ETF_LEVERAGE" and ai_score < 80:
            _log(f"⛔ ETF 제외({name}) — 레버리지 AI점수미달({ai_score:.0f}<80)", "info")
            continue
        if code not in existing_codes:
            _watch_list.append({"code": code, "name": name, "asset_type": atype})
            existing_codes.add(code)
            added_etfs.append(f"{name}[{atype}]")

    # ── ③ BEAR 국면: 인버스 ETF 상위 2개 자동 추가 ─────────
    if regime == "BEAR":
        inv_etfs = [e for e in result.get("etf_by_type", {}).get("ETF_INVERSE", [])
                    if e.get("grade") in ("BUY_CANDIDATE", "WATCH_HIGH")][:2]
        for e in inv_etfs:
            code  = e.get("code", "")
            name  = e.get("name", code)
            atype = "ETF_INVERSE"
            if code and code not in existing_codes:
                _watch_list.append({"code": code, "name": name, "asset_type": atype})
                existing_codes.add(code)
                added_etfs.append(f"{name}[인버스]")
                _log(f"🔴 [BEAR 국면] 인버스ETF 자동추가: {name}({code})", "info")

    # ── ④ 국면 변경 시 부적합 ETF 제거 ─────────────────────
    removed = []
    new_watch = []
    for s in _watch_list:
        atype = s.get("asset_type", "")
        code  = s.get("code", "")
        if atype == "ETF_LEVERAGE" and regime != "BULL" and code not in [c.get("code") for c in result.get("candidates_10", [])]:
            removed.append(s["name"])
            continue
        if atype == "ETF_INVERSE" and regime == "BULL":
            removed.append(s["name"])
            continue
        new_watch.append(s)
    if removed:
        _watch_list = new_watch
        _log(f"🔄 [국면변경:{regime}] 관심종목 제거: {', '.join(removed)}", "info")

    # ── ⑤ 주식 관심종목 최소 7개 보완 ──────────────────────
    stock_watch_cnt = sum(1 for s in _watch_list if not s.get("asset_type","").startswith("ETF"))
    TARGET_STOCK_WATCH = 7
    if stock_watch_cnt < TARGET_STOCK_WATCH:
        need = TARGET_STOCK_WATCH - stock_watch_cnt
        existing_codes = {s["code"] for s in _watch_list}
        focus_list = sorted(result.get("focus_30", []), key=lambda x: x.get("ai_score", 0), reverse=True)
        filled = []
        for c in focus_list:
            if len(filled) >= need:
                break
            code = c.get("code", "")
            name = c.get("name", code)
            if code and code not in existing_codes:
                atype = c.get("asset_type", "STOCK_KOSPI")
                if not atype.startswith("ETF"):
                    _watch_list.append({"code": code, "name": name, "asset_type": atype, "auto_fill": True})
                    existing_codes.add(code)
                    filled.append(name)
        if filled:
            _log(f"🔄 [자동보완] focus_30에서 {len(filled)}개 추가: {', '.join(filled)}", "info")

        FALLBACK_STOCKS = [
            {"code": "005930", "name": "삼성전자",       "asset_type": "STOCK_KOSPI"},
            {"code": "000660", "name": "SK하이닉스",      "asset_type": "STOCK_KOSPI"},
            {"code": "035420", "name": "NAVER",          "asset_type": "STOCK_KOSPI"},
            {"code": "005380", "name": "현대차",          "asset_type": "STOCK_KOSPI"},
            {"code": "000270", "name": "기아",            "asset_type": "STOCK_KOSPI"},
            {"code": "051910", "name": "LG화학",          "asset_type": "STOCK_KOSPI"},
            {"code": "035720", "name": "카카오",          "asset_type": "STOCK_KOSPI"},
            {"code": "207940", "name": "삼성바이오로직스",  "asset_type": "STOCK_KOSPI"},
            {"code": "006400", "name": "삼성SDI",         "asset_type": "STOCK_KOSPI"},
            {"code": "034730", "name": "SK",              "asset_type": "STOCK_KOSPI"},
        ]
        existing_codes2  = {s["code"] for s in _watch_list}
        stock_watch_cnt2 = sum(1 for s in _watch_list if not s.get("asset_type","").startswith("ETF"))
        if stock_watch_cnt2 < TARGET_STOCK_WATCH:
            need2 = TARGET_STOCK_WATCH - stock_watch_cnt2
            fb_added = []
            for fb in FALLBACK_STOCKS:
                if len(fb_added) >= need2:
                    break
                if fb["code"] not in existing_codes2:
                    _watch_list.append({**fb, "auto_fill": True, "fallback": True})
                    existing_codes2.add(fb["code"])
                    fb_added.append(fb["name"])
            if fb_added:
                _log(f"🏦 [기본종목] 우량주 자동추가: {', '.join(fb_added)}", "info")

    total_watch = len(_watch_list)
    stock_final = sum(1 for s in _watch_list if not s.get("asset_type","").startswith("ETF"))
    etf_final   = total_watch - stock_final

    if added_stocks:
        _log(f"📈 주식 관심종목 추가 — {', '.join(added_stocks)} ({len(added_stocks)}개)", "info")
    if added_etfs:
        _log(f"📦 ETF 관심종목 추가 — {', '.join(added_etfs)} ({len(added_etfs)}개)", "info")
    if not added_stocks and not added_etfs:
        _log("📋 관심종목 변동 없음 (이미 포함된 종목)", "info")
    _log(f"📋 [관심종목 현황] 주식:{stock_final}개 / ETF:{etf_final}개 / 합계:{total_watch}개", "info")

    # 대시보드 실시간 반영
    socketio.emit("watchlist_updated", {"watch_list": _watch_list, "regime": regime})


def _daily_screen_job():
    """APScheduler 에서 호출되는 일일 스크리닝 작업"""
    global _last_screen
    try:
        _log("📊 [자동] 일일 종목 스크리닝 시작 (16:05)...", "info")
        sc = _get_screener()
        result = sc.run()
        _last_screen = result
        regime  = result.get("regime", "LATERAL")
        cnt     = result["summary"]["buy_candidate"]
        etf_cnt = result["summary"].get("etf_buy_candidate", 0)
        _log(f"✅ [자동] 스크리닝 완료 — 국면:{regime} | 주식후보 {cnt}개 | ETF후보 {etf_cnt}개", "info")

        # 관심종목 반영 + 대시보드 push (공통 함수)
        _apply_screen_result(result)

        socketio.emit("screen_done", {
            "summary":        result["summary"],
            "candidates":     result["candidates_10"][:10],
            "focus":          result["focus_30"][:30],
            "etf_candidates": result.get("etf_candidates", []),
            "regime":         regime,
        })
    except Exception as e:
        _log(f"❌ [자동] 스크리닝 오류: {e}", "error")


# ── Flask 라우트 ──────────────────────────────────────────
@app.route("/")
def index():
    # ★ .env에 API 키가 있으면 어느 PC/브라우저에서 접속해도 바로 대시보드
    # (세션 쿠키 불필요 — 서버에 키가 있으면 무조건 통과)
    if Config.KIS_APP_KEY and Config.KIS_APP_SECRET and Config.KIS_ACCOUNT_NO:
        session["configured"] = True   # 호환성 유지
        if _api is None:
            _init_api()
        return render_template("dashboard.html",
                               watch_list=_watch_list)
    # API 키가 없을 때만 setup 화면
    return redirect(url_for("setup"))


@app.route("/demo")
def demo():
    """KIS API 키 없이 대시보드 UI 확인용"""
    session["configured"] = True
    return render_template("dashboard.html",
                           watch_list=_watch_list)


@app.route("/setup", methods=["GET", "POST"])
def setup():
    if request.method == "POST":
        env_path = os.path.join(os.path.dirname(__file__), ".env")
        with open(env_path, "w") as f:
            # KIS API (실전 전용 — KIS_IS_REAL 항상 true)
            f.write(f"KIS_APP_KEY={request.form['app_key']}\n")
            f.write(f"KIS_APP_SECRET={request.form['app_secret']}\n")
            f.write(f"KIS_ACCOUNT_NO={request.form['account_no']}\n")
            f.write("KIS_IS_REAL=true\n")
            # 텔레그램
            f.write(f"TELEGRAM_BOT_TOKEN={request.form.get('tg_token','')}\n")
            f.write(f"TELEGRAM_CHAT_ID={request.form.get('tg_chat_id','')}\n")
            # 투자금
            f.write(f"MAX_INVESTMENT_PER_STOCK={request.form.get('max_per_stock',5000000)}\n")
            f.write(f"MAX_TOTAL_INVESTMENT={request.form.get('max_total',5000000)}\n")
            # 손절/트레일링
            f.write(f"STOP_LOSS_PERCENT={request.form.get('stop_loss',10.0)}\n")
            f.write(f"USE_TAKE_PROFIT={request.form.get('use_take_profit','false')}\n")
            f.write(f"TAKE_PROFIT_PERCENT={request.form.get('take_profit',15.0)}\n")
            f.write(f"TRAILING_STOP_PCT={request.form.get('trailing_stop',15.0)}\n")
            f.write(f"TRAILING_ACTIVATE_PCT={request.form.get('trailing_activate',5.0)}\n")
            # 추가매수 (피라미딩)
            f.write(f"ADD_BUY_PROFIT={request.form.get('add_buy_profit','false')}\n")
            f.write(f"ADD_BUY_LOSS={request.form.get('add_buy_loss','false')}\n")
            f.write(f"PYRAMID_STEP_1={request.form.get('pyramid_1',10.0)}\n")
            f.write(f"PYRAMID_STEP_2={request.form.get('pyramid_2',20.0)}\n")
            f.write(f"PYRAMID_STEP_3={request.form.get('pyramid_3',35.0)}\n")
            # 실험 전략 (Strategy Lab)
            f.write(f"USE_LAB={request.form.get('use_lab','false')}\n")
            f.write(f"LAB_TRAILING_LIST={request.form.get('lab_trailing','10,12,15,18,20,25')}\n")
            f.write(f"LAB_STOPLOSS_LIST={request.form.get('lab_stoploss','5,7,10,12')}\n")
            f.write(f"LAB_PYRAMID_LIST={request.form.get('lab_pyramid','10-20-35,15-30-50,20-40-60')}\n")
            # Flask
            f.write(f"FLASK_SECRET_KEY={Config.FLASK_SECRET_KEY}\n")
        from importlib import reload
        import config as cfg_mod
        reload(cfg_mod)
        session["configured"] = True
        _init_api()
        return redirect(url_for("index"))
    return render_template("setup.html")


# ── API 엔드포인트 ────────────────────────────────────────
@app.route("/api/status")
def api_status():
    sess     = session_info()
    compound = _strategy_mgr.pyramid.compound_pool if _strategy_mgr else 0

    # ★ positions = 봇이 직접 관리하는 피라미딩 포지션 (로컬 파일 기반)
    #   실제 KIS 계좌 잔고는 /api/balance 에서 가져옵니다
    bot_positions = _strategy_mgr.positions if _strategy_mgr else {}

    # 시장 국면 + ETF 배분 현황
    regime = _detect_current_regime()
    from screener.asset_universe import (
        REGIME_TARGET_WEIGHTS, get_asset_type_label,
        ASSET_ETF_GENERAL, ASSET_ETF_LEVERAGE, ASSET_ETF_INVERSE,
        ASSET_STOCK_KOSPI, ASSET_STOCK_KOSDAQ,
    )
    target_weights = REGIME_TARGET_WEIGHTS.get(regime, {})
    etf_watch = [s for s in _watch_list if s.get("asset_type","").startswith("ETF")]
    stock_watch = [s for s in _watch_list if not s.get("asset_type","").startswith("ETF")]

    # 해외주식 세션 정보
    us_sess = us_session_info()

    return jsonify({
        "bot_running":   _bot_running,
        "api_ready":     _api is not None,
        "watch_list":    _watch_list,
        "positions":     bot_positions,
        "session":       sess,
        "compound_pool": compound,
        "regime":        regime,
        "target_weights": {k: round(v*100, 1) for k, v in target_weights.items()},
        "etf_watch_count":   len(etf_watch),
        "stock_watch_count": len(stock_watch),
        "etf_watch":         etf_watch,
        "stop_loss_pct":     Config.STOP_LOSS_PERCENT,
        # ★ 해외주식 정보
        "us_session":        us_sess,
        "us_watch_list":     _us_watch_list,
        "us_positions":      _us_strategy.positions if _us_strategy else {},
        "us_tradeable":      us_sess["tradeable"],
    })

@app.route("/api/session")
def api_session():
    return jsonify(session_info())

@app.route("/api/balance")
def api_balance():
    """실제 KIS 증권사 계좌 잔고 — holdings 가 진짜 보유 종목"""
    if _api is None:
        return jsonify({"error": "API 미초기화", "holdings": [], "total_eval": 0, "cash": 0})
    return jsonify(_api.get_balance())

@app.route("/api/holdings")
def api_holdings():
    """KIS 계좌 실제 보유 종목만 반환 (대시보드 보유현황용)"""
    if _api is None:
        return jsonify({"holdings": [], "error": "API 미초기화"})
    try:
        bal = _api.get_balance()
        return jsonify({"holdings": bal.get("holdings", [])})
    except Exception as e:
        logger.error(f"holdings 조회 실패: {e}")
        return jsonify({"holdings": [], "error": str(e)})

@app.route("/api/signals")
def api_signals():
    return jsonify(_last_signals)

# ── ★ 해외주식 전용 API ───────────────────────────────────────

@app.route("/api/us/signals")
def api_us_signals():
    """해외주식 최신 신호"""
    return jsonify(_us_last_signals)

@app.route("/api/us/positions")
def api_us_positions():
    """해외주식 봇 포지션"""
    if _us_strategy is None:
        return jsonify({})
    return jsonify(_us_strategy.positions)

@app.route("/api/us/balance")
def api_us_balance():
    """해외주식 KIS 계좌 잔고"""
    if _api is None:
        return jsonify({"holdings": [], "error": "API 미초기화"})
    try:
        bal = _api.get_us_balance()
        rate = _api.get_usd_exchange_rate()
        bal["exchange_rate"] = rate
        # 원화 환산 추가
        for h in bal.get("holdings", []):
            h["cur_price_krw"] = round(h.get("cur_price", 0) * rate)
            h["avg_price_krw"] = round(h.get("avg_price", 0) * rate)
            h["pnl_krw"]       = round(h.get("pnl_amt",  0) * rate)
        return jsonify(bal)
    except Exception as e:
        return jsonify({"holdings": [], "error": str(e)})

@app.route("/api/us/session")
def api_us_session():
    """미국장 세션 정보"""
    return jsonify(us_session_info())

@app.route("/api/us/watchlist", methods=["GET"])
def api_us_watchlist_get():
    """해외주식 관심종목 조회"""
    return jsonify({"watch_list": _us_watch_list})

@app.route("/api/us/watchlist/add", methods=["POST"])
def api_us_watchlist_add():
    """해외주식 관심종목 추가"""
    global _us_watch_list
    data   = request.get_json() or {}
    symbol = data.get("symbol", "").strip().upper()
    name   = data.get("name",   symbol).strip()
    excd   = data.get("excd",   "NASD").strip().upper()
    if not symbol:
        return jsonify({"ok": False, "error": "symbol 필요"})
    if any(s["symbol"] == symbol for s in _us_watch_list):
        return jsonify({"ok": False, "error": "이미 추가된 종목"})
    _us_watch_list.append({"symbol": symbol, "name": name, "excd": excd})
    _log(f"🇺🇸 해외 관심종목 추가: {name}({symbol})", "info")
    socketio.emit("us_watchlist_updated", {"watch_list": _us_watch_list})
    return jsonify({"ok": True, "watch_list": _us_watch_list})

@app.route("/api/us/watchlist/remove", methods=["POST"])
def api_us_watchlist_remove():
    """해외주식 관심종목 삭제"""
    global _us_watch_list
    data   = request.get_json() or {}
    symbol = data.get("symbol", "").strip().upper()
    before = len(_us_watch_list)
    _us_watch_list = [s for s in _us_watch_list if s["symbol"] != symbol]
    removed = before - len(_us_watch_list)
    if removed:
        _log(f"🗑️ 해외 관심종목 삭제: {symbol}", "info")
        socketio.emit("us_watchlist_updated", {"watch_list": _us_watch_list})
    return jsonify({"ok": bool(removed), "watch_list": _us_watch_list})

@app.route("/api/us/chart/<symbol>")
def api_us_chart(symbol):
    """해외주식 캔들 데이터"""
    if _api is None:
        return jsonify({"error": "API 미초기화"})
    excd = request.args.get("excd", "NASD")
    try:
        candles = _api.get_us_ohlcv(symbol.upper(), excd, count=60)
        return jsonify({"symbol": symbol, "excd": excd, "candles": candles})
    except Exception as e:
        return jsonify({"error": str(e)})

# ── 미국 증시 분석 API ─────────────────────────────────────
@app.route("/api/us/status")
def api_us_status():
    """저장된 미국 분석 결과 반환 (캐시)"""
    from screener.us_market_screener import load_us_result
    return jsonify(load_us_result())

@app.route("/api/us/run", methods=["POST"])
def api_us_run():
    """미국 분석 즉시 실행 + 관심종목 자동 갱신 (수동 트리거)"""
    try:
        from screener.us_market_screener import run_us_screening
        _log("🇺🇸 [수동] 미국 증시 분석 시작...", "info")
        result  = run_us_screening()
        s       = result.get("summary", {})
        regime  = s.get("regime", "?")
        top_buy = result.get("top_buy", [])
        _log(f"✅ [수동] 미국 분석 완료 — 국면:{regime} | S&P500:{s.get('sp500_pct',0):+.2f}%", "info")

        # ★ 관심종목 자동 갱신 (BEAR 제외)
        wl_diff = {}
        if regime != "BEAR" and top_buy:
            wl_diff = _apply_us_screen_to_watchlist(top_buy)
            added   = wl_diff.get("added", [])
            removed = wl_diff.get("removed", [])
            if added or removed:
                _log(f"🇺🇸 [수동 갱신] +{added} / -{removed} → 총{len(_us_watch_list)}개", "info")
        elif regime == "BEAR":
            _log("🐻 BEAR 국면 — 수동 분석 시 관심종목 교체 보류", "info")

        socketio.emit("us_screen_done", {
            "summary":      s,
            "korea_impact": result.get("korea_impact", {}),
            "top_buy":      top_buy[:5],
            "wl_diff":      wl_diff,
            "watch_list":   _us_watch_list,
        })
        return jsonify({
            "ok":         True,
            "summary":    s,
            "wl_diff":    wl_diff,
            "watch_list": _us_watch_list,
        })
    except Exception as e:
        logger.error(f"미국 분석 실행 오류: {e}")
        return jsonify({"ok": False, "error": str(e)})

@app.route("/api/trades")
def api_trades():
    if _strategy_mgr is None:
        return jsonify([])
    return jsonify(_strategy_mgr.get_trade_history(50))

@app.route("/api/chart/<code>")
def api_chart(code):
    if _api is None:
        return jsonify([])
    candles = _api.get_ohlcv(code, period="D", count=120)
    return jsonify(candles)


@app.route("/api/backtest", methods=["POST"])
def api_backtest():
    from backtesting.backtest_engine import BacktestEngine
    data        = request.json or {}
    code        = data.get("code", "005930")
    strategy    = data.get("strategy", "combined")
    stop_loss   = float(data.get("stop_loss", 3.0))
    take_profit = float(data.get("take_profit", 5.0))
    capital     = float(data.get("capital", 10_000_000))
    if _api is None:
        return jsonify({"error": "API 미초기화"})
    candles = _api.get_ohlcv(code, period="D", count=500)
    if not candles:
        return jsonify({"error": "데이터 없음"})
    engine = BacktestEngine(capital)
    return jsonify(engine.run(candles, strategy, stop_loss, take_profit))

@app.route("/api/bot/start", methods=["POST"])
def bot_start():
    global _bot_running, _scheduler
    if _api is None and not _init_api():
        return jsonify({"ok": False, "msg": "API 초기화 실패"})
    _bot_running = True
    _save_bot_state(True)   # ★ 상태 파일에 저장

    if _scheduler is None or not _scheduler.running:
        _scheduler = BackgroundScheduler(timezone="Asia/Seoul")
        sess = session_info()
        _scheduler.add_job(_trading_loop,  "interval", seconds=sess["check_sec"],
                           id="trading_loop",         replace_existing=True)
        _scheduler.add_job(_session_watcher, "interval", seconds=30,
                           id="session_watcher",      replace_existing=True)
        _scheduler.add_job(_daily_screen_job, "cron", hour=16, minute=5,
                           timezone="Asia/Seoul",     id="daily_screener",     replace_existing=True)
        _scheduler.add_job(_weekly_lab_ranking_job, "cron", day_of_week="mon", hour=9, minute=0,
                           timezone="Asia/Seoul",     id="weekly_lab_ranking", replace_existing=True)
        _scheduler.add_job(_us_market_job, "cron", hour=0, minute=0,
                           timezone="Asia/Seoul",     id="us_market_screener", replace_existing=True)
        _scheduler.start()
        # ★ 봇 시작 시 토큰 안정화 후 1회 신호 점검 (15초 딜레이)
        def _delayed_loop_start():
            time.sleep(15)
            _trading_loop()
        threading.Thread(target=_delayed_loop_start, daemon=True).start()

    _log(f"🚀 자동매매 봇 시작! 현재 세션: {session_info()['session']}", "info")
    notifier.notify_system("자동매매 봇 시작")
    return jsonify({"ok": True})


@app.route("/api/bot/stop", methods=["POST"])
def bot_stop():
    global _bot_running
    _bot_running = False
    _save_bot_state(False)   # ★ 상태 파일에 저장
    _log("⏹ 자동매매 봇 정지", "info")
    notifier.notify_system("자동매매 봇 정지")
    return jsonify({"ok": True})


@app.route("/api/bot/run_now", methods=["POST"])
def bot_run_now():
    """
    트레이딩 루프 즉시 강제 실행 (손절·트레일링·매매 신호 즉시 점검).
    세션(장중/휴장) 무관하게 _orphan_loss_cut() 포함 전체 루프 실행.
    """
    if not _bot_running or _strategy_mgr is None:
        return jsonify({"ok": False, "msg": "봇이 실행 중이지 않습니다"})
    def _run():
        try:
            _orphan_loss_cut()   # 손절·트레일링 즉시 점검
            _trading_loop()      # 전체 루프
        except Exception as e:
            _log(f"❌ 강제 실행 오류: {e}", "error")
    threading.Thread(target=_run, daemon=True).start()
    _log("⚡ 트레이딩 루프 즉시 강제 실행", "info")
    return jsonify({"ok": True, "msg": "실행 시작됨"})


@app.route("/api/analyze/<code>")
def api_analyze(code):
    if _strategy_mgr is None:
        return jsonify({"error": "API 미초기화"})
    name   = next((s["name"] for s in _watch_list if s["code"] == code), code)
    result = _strategy_mgr.run({"code": code, "name": name})
    _last_signals[code] = result
    return jsonify(result)


@app.route("/api/watchlist/add", methods=["POST"])
def watchlist_add():
    data = request.json or {}
    code = data.get("code", "").strip()
    name = data.get("name", code)
    if not code:
        return jsonify({"ok": False, "msg": "코드 없음"})
    if any(s["code"] == code for s in _watch_list):
        return jsonify({"ok": False, "msg": "이미 추가됨"})
    _watch_list.append({"code": code, "name": name})
    return jsonify({"ok": True, "watch_list": _watch_list})


@app.route("/api/watchlist/remove", methods=["POST"])
def watchlist_remove():
    global _watch_list
    code = (request.json or {}).get("code", "")
    _watch_list = [s for s in _watch_list if s["code"] != code]
    return jsonify({"ok": True, "watch_list": _watch_list})


@app.route("/api/logs")
def api_logs():
    return jsonify(_status_log[-50:])


# ══════════════════════════════════════════════════════════
# 스크리너 API 엔드포인트
# ══════════════════════════════════════════════════════════

_screener      = None      # DailyScreener 인스턴스
_last_screen   = {}        # 마지막 스크리닝 결과 캐시


def _get_screener():
    """
    DailyScreener 인스턴스 반환.
    실전 KIS API 전용 — KISDataFetcher(demo_mode=False) 고정.
    """
    global _screener
    from screener.daily_screener import DailyScreener
    from screener.kis_data_fetcher import KISDataFetcher

    if _screener is None:
        fetcher = KISDataFetcher(demo_mode=False)
        _screener = DailyScreener(fetcher=fetcher, demo_mode=False)
    return _screener


@app.route("/screener")
def screener_page():
    """스크리너 대시보드 페이지"""
    return render_template("screener.html",
                           watch_list=_watch_list)


@app.route("/api/screener/run", methods=["POST"])
def api_screener_run():
    """즉시 스크리닝 실행 (백그라운드) — 완료 후 관심종목 자동 반영"""
    global _last_screen
    def _run():
        global _last_screen
        try:
            _log("📊 종목 스크리닝 시작...", "info")
            sc = _get_screener()
            result = sc.run()
            _last_screen = result
            cnt     = result["summary"]["buy_candidate"]
            etf_cnt = result["summary"].get("etf_buy_candidate", 0)
            regime  = result.get("regime", "LATERAL")
            _log(f"✅ 스크리닝 완료 — 매수후보 {cnt}개 / ETF {etf_cnt}개", "info")

            # ★ 스크리닝 결과를 _watch_list 에 즉시 반영
            _apply_screen_result(result)

            socketio.emit("screen_done", {
                "summary":        result["summary"],
                "candidates":     result["candidates_10"][:10],
                "focus":          result["focus_30"][:30],
                "etf_candidates": result.get("etf_candidates", []),
                "regime":         regime,
            })
        except Exception as e:
            _log(f"❌ 스크리닝 오류: {e}", "error")
    threading.Thread(target=_run, daemon=True).start()
    return jsonify({"ok": True, "msg": "스크리닝 시작됨"})


@app.route("/api/screener/results")
def api_screener_results():
    """최신 스크리닝 결과 조회"""
    from screener.screener_db import get_latest_scores, get_buy_candidates, get_screen_summary
    grade   = request.args.get("grade", "")
    limit   = int(request.args.get("limit", 100))
    scores  = get_latest_scores(limit=limit, grade_filter=grade or None)
    cands   = get_buy_candidates()
    summary = get_screen_summary(days=1)
    return jsonify({
        "scores":     scores,
        "candidates": cands,
        "summary":    summary[0] if summary else {},
    })


@app.route("/api/screener/candidates")
def api_screener_candidates():
    """매수 후보 10개"""
    from screener.screener_db import get_buy_candidates
    return jsonify(get_buy_candidates())


@app.route("/api/screener/focus")
def api_screener_focus():
    """집중감시 30개"""
    from screener.screener_db import get_watchlist_db
    return jsonify(get_watchlist_db(focus_only=True))


@app.route("/api/screener/watchlist")
def api_screener_watchlist():
    """전체 감시 200개"""
    from screener.screener_db import get_watchlist_db
    return jsonify(get_watchlist_db(focus_only=False))


@app.route("/api/screener/analyze/<code>")
def api_screener_analyze(code):
    """단일 종목 즉시 분석"""
    name = request.args.get("name", code)
    sc   = _get_screener()
    result = sc.analyze_single(code, name)
    return jsonify(result)


@app.route("/api/screener/history/<code>")
def api_screener_history(code):
    """종목 점수 이력"""
    from screener.screener_db import get_score_history
    return jsonify(get_score_history(code, days=30))


@app.route("/api/screener/summary")
def api_screener_summary():
    """스크리닝 요약 (최근 7일)"""
    from screener.screener_db import get_screen_summary
    return jsonify(get_screen_summary(days=7))


# ══════════════════════════════════════════════════════════
# 전략 실험실 (Strategy Lab) API 엔드포인트
# ══════════════════════════════════════════════════════════

@app.route("/lab")
def lab_page():
    """전략 실험실 대시보드 페이지"""
    return render_template("lab.html",
                           watch_list=_watch_list)


@app.route("/api/lab/status")
def api_lab_status():
    """전략 실험실 전체 현황 (대시보드 카드)"""
    lab = _get_lab()
    return jsonify(lab.get_all_status())


@app.route("/api/lab/ranking")
def api_lab_ranking():
    """최신 전략 랭킹 (캐시 or 파일)"""
    lab = _get_lab()
    ranking = lab.get_ranking()
    return jsonify({
        "ranking": ranking,
        "regime":  lab.market_regime,
        "calc_date": lab._last_rank_date or "",
    })


@app.route("/api/lab/ranking/run", methods=["POST"])
def api_lab_ranking_run():
    """즉시 랭킹 재계산 (수동 트리거)"""
    def _run():
        try:
            from strategy_lab.lab_db import save_ranking_snapshot, save_ai_recs_from_ranking
            lab     = _get_lab()
            ranking = lab.calc_ranking()
            regime  = lab.market_regime
            save_ranking_snapshot(ranking, regime)
            save_ai_recs_from_ranking(ranking, regime)
            socketio.emit("lab_ranking_done", {
                "ranking": ranking[:5],
                "regime":  regime,
            })
        except Exception as e:
            logger.error(f"[Lab] 랭킹 계산 오류: {e}")
    threading.Thread(target=_run, daemon=True).start()
    return jsonify({"ok": True, "msg": "랭킹 계산 시작됨"})


@app.route("/api/lab/strategy/<sid>")
def api_lab_strategy(sid):
    """단일 전략 상세 (메트릭 + 포지션 + 거래내역)"""
    lab = _get_lab()
    detail = lab.get_strategy_detail(sid)
    if not detail:
        return jsonify({"error": f"전략 없음: {sid}"}), 404
    return jsonify(detail)


@app.route("/api/lab/regime")
def api_lab_regime():
    """시장 국면 분석"""
    lab = _get_lab()
    return jsonify(lab.get_regime_analysis())


@app.route("/api/lab/ai")
def api_lab_ai():
    """최신 AI 추천 (전략별)"""
    from strategy_lab.lab_db import get_latest_ai_recs
    return jsonify(get_latest_ai_recs(limit=20))


@app.route("/api/lab/tier/history")
def api_lab_tier_history():
    """계층 변경 이력"""
    from strategy_lab.lab_db import get_tier_history
    sid = request.args.get("strategy_id", None)
    return jsonify(get_tier_history(strategy_id=sid, limit=50))


@app.route("/api/lab/trades")
def api_lab_trades():
    """가상 거래 기록 조회"""
    from strategy_lab.lab_db import get_trades
    sid        = request.args.get("strategy_id", None)
    code       = request.args.get("code", None)
    action     = request.args.get("action", None)
    start_date = request.args.get("start_date", None)
    limit      = int(request.args.get("limit", 100))
    return jsonify(get_trades(
        strategy_id=sid, code=code, action=action,
        start_date=start_date, limit=limit,
    ))


@app.route("/api/lab/equity/<sid>")
def api_lab_equity(sid):
    """전략별 자산 곡선"""
    from strategy_lab.lab_db import get_equity_curve
    days = int(request.args.get("days", 120))
    return jsonify(get_equity_curve(sid, days=days))


@app.route("/api/lab/demo", methods=["POST"])
def api_lab_demo():
    """데모 시뮬레이션 실행 (실계좌 완전 무관)"""
    days = int((request.json or {}).get("days", 60))
    days = max(10, min(days, 365))   # 10~365일 범위 제한

    def _run():
        try:
            from strategy_lab.lab_db import save_ranking_snapshot, save_ai_recs_from_ranking
            lab    = _get_lab()
            result = lab.run_demo_simulation(days=days)
            save_ranking_snapshot(result["ranking"], result["regime"])
            save_ai_recs_from_ranking(result["ranking"], result["regime"])
            socketio.emit("lab_demo_done", result)
        except Exception as e:
            logger.error(f"[Lab] 데모 시뮬레이션 오류: {e}")
            socketio.emit("lab_demo_done", {"error": str(e)})

    threading.Thread(target=_run, daemon=True).start()
    return jsonify({"ok": True, "msg": f"{days}일 데모 시뮬레이션 시작됨"})


@app.route("/api/lab/db/stats")
def api_lab_db_stats():
    """Lab DB 통계 (모니터링)"""
    from strategy_lab.lab_db import get_db_stats
    return jsonify(get_db_stats())


@app.route("/api/lab/performance")
def api_lab_performance():
    """전략 성과 테이블 (DB 기반)"""
    from strategy_lab.lab_db import get_strategy_performance_table
    return jsonify(get_strategy_performance_table())


@app.route("/api/lab/regime/best")
def api_lab_regime_best():
    """시장 국면별 최고 전략"""
    from strategy_lab.lab_db import get_weekly_best_by_regime
    return jsonify(get_weekly_best_by_regime())


# ══════════════════════════════════════════════════════════
# 자산군 유니버스 API  /api/universe/*
# ══════════════════════════════════════════════════════════

@app.route("/api/universe/status")
def api_universe_status():
    """
    현재 자산군 배분 현황
    — 국면, 자산군별 타겟/실제 비중, 비중 한도 여유분 반환
    """
    try:
        from screener.asset_universe import (
            WEIGHT_LIMITS, REGIME_TARGET_WEIGHTS,
            REGIME_PRIORITY, ALL_ASSET_TYPES, get_asset_type_label,
        )
        from screener.daily_screener import _detect_regime
        sc      = _get_screener()
        fetcher = sc._get_fetcher()
        kospi   = fetcher.get_market_index("KOSPI")
        kosdaq  = fetcher.get_market_index("KOSDAQ")
        regime  = _detect_regime(kospi, kosdaq)

        target_wts = REGIME_TARGET_WEIGHTS.get(regime, {})
        cash_min   = WEIGHT_LIMITS.get("CASH", 0.10)
        lev_max    = WEIGHT_LIMITS.get("ETF_LEVERAGE", 0.20)
        inv_max    = WEIGHT_LIMITS.get("ETF_INVERSE",  0.40)

        return jsonify({
            "ok":     True,
            "regime": regime,
            "target_weights": {
                k: {"weight": round(v, 4), "label": get_asset_type_label(k)}
                for k, v in target_wts.items()
            },
            "regime_priority": REGIME_PRIORITY.get(regime, []),
            "weight_limits": {
                "leverage_max": lev_max,
                "inverse_max":  inv_max,
                "cash_min":     cash_min,
            },
            "market": {
                "kospi_price":    kospi.get("price", 0),
                "kospi_ret20":    kospi.get("return_20d", 0),
                "kosdaq_price":   kosdaq.get("price", 0),
                "kosdaq_ret20":   kosdaq.get("return_20d", 0),
            },
        })
    except Exception as e:
        logger.error(f"/api/universe/status 오류: {e}")
        return jsonify({"ok": False, "error": str(e)}), 500


@app.route("/api/universe/allocation")
def api_universe_allocation():
    """
    현재 국면 기준 배분 계획 (스크리닝 캐시 사용).
    캐시 없을 경우 간이 데모 데이터 반환.
    """
    try:
        from screener.asset_universe import REGIME_TARGET_WEIGHTS, REGIME_PRIORITY, get_asset_type_label
        from screener.daily_screener import _detect_regime
        from screener.asset_allocator import get_allocation_plan

        sc      = _get_screener()
        fetcher = sc._get_fetcher()
        kospi   = fetcher.get_market_index("KOSPI")
        kosdaq  = fetcher.get_market_index("KOSDAQ")
        regime  = _detect_regime(kospi, kosdaq)

        # 최근 스크리닝 결과 캐시에서 후보 가져오기 (없으면 빈 리스트)
        try:
            from screener.screener_db import get_watchlist_db
            candidates = get_watchlist_db(focus_only=True) or []
        except Exception:
            candidates = []

        # ETF 목록 추가 (데모 목록)
        try:
            etf_list = fetcher.get_etf_list()
        except Exception:
            etf_list = []

        all_screened = candidates + etf_list

        plan = get_allocation_plan(
            screened      = all_screened,
            regime        = regime,
            total_capital = 10_000_000,
            cash          = 10_000_000,
        )

        return jsonify({
            "ok":     True,
            "regime": regime,
            "target_weights": {
                k: round(v, 4)
                for k, v in plan.target_weights.items()
            },
            "buy_list": [
                {
                    "code":            bd.code,
                    "name":            bd.name,
                    "asset_type":      bd.asset_type,
                    "asset_type_kr":   get_asset_type_label(bd.asset_type),
                    "ai_score":        round(bd.ai_score, 1),
                    "rs_value":        round(bd.rs_value, 2),
                    "can_buy":         bd.can_buy,
                    "reason":          bd.reason,
                    "suggested_ratio": round(bd.suggested_ratio, 4),
                    "max_amount":      round(bd.max_amount, 0),
                    "priority_rank":   bd.priority_rank,
                }
                for bd in plan.buy_list
                if bd.can_buy
            ],
            "blocked_list": [
                {
                    "code":       bd.code,
                    "name":       bd.name,
                    "asset_type": bd.asset_type,
                    "reason":     bd.reason,
                }
                for bd in plan.buy_list
                if not bd.can_buy
            ],
            "warnings":         plan.warnings,
            "rebalance_needed": plan.rebalance_needed,
            "summary":          plan.summary,
        })
    except Exception as e:
        logger.error(f"/api/universe/allocation 오류: {e}")
        return jsonify({"ok": False, "error": str(e)}), 500


@app.route("/api/universe/plan", methods=["POST"])
def api_universe_plan():
    """
    POST JSON {screened: [...], regime: str, total_capital: float, cash: float}
    → 배분 계획 실행 후 결과 반환
    """
    try:
        from screener.asset_allocator import get_allocation_plan
        from screener.asset_universe import get_asset_type_label

        data          = request.get_json(force=True) or {}
        screened      = data.get("screened", [])
        regime        = data.get("regime", "LATERAL")
        total_capital = float(data.get("total_capital", 10_000_000))
        cash          = float(data.get("cash",          total_capital))
        positions     = data.get("positions", {})

        if not screened:
            return jsonify({"ok": False, "error": "screened 목록이 비어 있습니다"}), 400

        plan = get_allocation_plan(
            screened      = screened,
            regime        = regime,
            total_capital = total_capital,
            cash          = cash,
            positions     = positions,
        )
        return jsonify({
            "ok":     True,
            "regime": plan.regime,
            "target_weights":   plan.target_weights,
            "current_weights":  plan.current_weights,
            "rebalance_needed": plan.rebalance_needed,
            "warnings":         plan.warnings,
            "buyable_count":    sum(1 for d in plan.buy_list if d.can_buy),
            "blocked_count":    sum(1 for d in plan.buy_list if not d.can_buy),
            "buy_list": [
                {
                    "code":            bd.code,
                    "name":            bd.name,
                    "asset_type":      bd.asset_type,
                    "asset_type_kr":   get_asset_type_label(bd.asset_type),
                    "ai_score":        round(bd.ai_score, 1),
                    "rs_value":        round(bd.rs_value, 2),
                    "can_buy":         bd.can_buy,
                    "reason":          bd.reason,
                    "suggested_ratio": round(bd.suggested_ratio, 4),
                    "max_amount":      round(bd.max_amount, 0),
                }
                for bd in plan.buy_list
            ],
            "summary": plan.summary,
        })
    except Exception as e:
        logger.error(f"/api/universe/plan 오류: {e}")
        return jsonify({"ok": False, "error": str(e)}), 500


@app.route("/api/universe/etf/list")
def api_universe_etf_list():
    """
    투자 대상 ETF 유니버스 목록.
    자산군별(일반/레버리지/인버스) 분류 포함.
    """
    try:
        from screener.asset_universe import (
            get_demo_etf_list, classify_asset_type, get_asset_type_label,
            ETF_CODE_MAP,
        )
        sc      = _get_screener()
        fetcher = sc._get_fetcher()
        try:
            raw_list = fetcher.get_etf_list()
        except Exception:
            raw_list = get_demo_etf_list()

        result = []
        for e in raw_list:
            code  = e.get("code", "")
            name  = e.get("name", code)
            atype = e.get("asset_type") or classify_asset_type(code, name, "ETF")
            result.append({
                "code":         code,
                "name":         name,
                "asset_type":   atype,
                "asset_type_kr": get_asset_type_label(atype),
                "market_cap":   e.get("market_cap", 0),
                "daily_amount": e.get("daily_amount", 0),
            })

        # 자산군별 그룹화
        by_type: dict = {}
        for r in result:
            at = r["asset_type"]
            by_type.setdefault(at, []).append(r)

        return jsonify({
            "ok":       True,
            "total":    len(result),
            "by_type":  by_type,
            "etf_list": result,
        })
    except Exception as e:
        logger.error(f"/api/universe/etf/list 오류: {e}")
        return jsonify({"ok": False, "error": str(e)}), 500


@app.route("/api/universe/regime/weights")
def api_universe_regime_weights():
    """
    국면별 타겟 비중 + 비중 한도 테이블 반환.
    UI의 비중 게이지 / 도넛 차트에 사용.
    """
    try:
        from screener.asset_universe import (
            REGIME_TARGET_WEIGHTS, WEIGHT_LIMITS,
            REGIME_PRIORITY, ALL_ASSET_TYPES, get_asset_type_label,
        )
        from screener.daily_screener import _detect_regime
        sc      = _get_screener()
        fetcher = sc._get_fetcher()
        kospi   = fetcher.get_market_index("KOSPI")
        kosdaq  = fetcher.get_market_index("KOSDAQ")
        current_regime = _detect_regime(kospi, kosdaq)

        # 모든 국면의 타겟 비중을 한번에 반환
        all_regime_weights = {}
        for regime, wt_map in REGIME_TARGET_WEIGHTS.items():
            all_regime_weights[regime] = {
                k: {
                    "weight":   round(v, 4),
                    "label":    get_asset_type_label(k),
                    "priority": (REGIME_PRIORITY.get(regime, []).index(k) + 1
                                 if k in REGIME_PRIORITY.get(regime, [])
                                 else 99),
                }
                for k, v in wt_map.items()
            }

        return jsonify({
            "ok":             True,
            "current_regime": current_regime,
            "regime_weights": all_regime_weights,
            "regime_priority": {
                r: REGIME_PRIORITY.get(r, [])
                for r in ["BULL", "LATERAL", "BEAR"]
            },
            "weight_limits": {
                k: {"limit": v, "label": get_asset_type_label(k)}
                for k, v in WEIGHT_LIMITS.items()
            },
            "asset_labels": {
                at: get_asset_type_label(at) for at in ALL_ASSET_TYPES
            },
        })
    except Exception as e:
        logger.error(f"/api/universe/regime/weights 오류: {e}")
        return jsonify({"ok": False, "error": str(e)}), 500


# ── SocketIO ─────────────────────────────────────────────
@socketio.on("connect")
def on_connect():
    emit("log_history", _status_log[-30:])
    emit("session_update", session_info())


@socketio.on("run_now")
def on_run_now():
    threading.Thread(target=_trading_loop, daemon=True).start()


# ── 진입점 ────────────────────────────────────────────────
@app.route("/favicon.ico")
def favicon():
    return send_from_directory(
        os.path.join(os.path.dirname(__file__), "static"),
        "favicon.ico", mimetype="image/vnd.microsoft.icon"
    )


if __name__ == "__main__":
    print("=" * 60)
    print("  📈 주식 자동매매 시스템")
    print(f"  🌐 http://0.0.0.0:{Config.DASHBOARD_PORT}")
    print("=" * 60)

    env_path = os.path.join(os.path.dirname(__file__), ".env")
    if os.path.exists(env_path) and os.path.getsize(env_path) > 10:
        _init_api()

    # 전략 실험실 미리 초기화 (DB 스키마 생성 및 포트폴리오 로드)
    try:
        _get_lab()
    except Exception as _e:
        print(f"[App] 전략 실험실 초기화 실패 (무시): {_e}")

    # ★ 이전에 봇이 실행 중이었으면 자동 재개
    _auto_start_bot()

    socketio.run(app, host="0.0.0.0", port=Config.DASHBOARD_PORT,
                 debug=False, allow_unsafe_werkzeug=True)
