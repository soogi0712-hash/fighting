"""
한국투자증권 KIS Open API 연동 모듈
- OAuth2 토큰 발급 / 갱신
- 주식 현재가 조회 (국내 + 해외)
- 매수 / 매도 주문 (국내 + 해외)
- 잔고 조회 (국내 + 해외)
- 체결 내역 조회
"""
import json
import time
import hashlib
import requests
from datetime import datetime, timedelta
from utils.logger import get_logger
from config import Config

logger = get_logger("KIS_API")


class KISApi:
    def __init__(self):
        self.app_key    = Config.KIS_APP_KEY
        self.app_secret = Config.KIS_APP_SECRET
        self.account_no = Config.KIS_ACCOUNT_NO
        self.base_url   = Config.BASE_URL

        self._access_token    = None
        self._token_expired   = None
        self._approval_key    = None   # 웹소켓 실시간용

    # ──────────────────────────────────────────────────────────
    # 1. OAuth2 토큰 관리
    # ──────────────────────────────────────────────────────────
    def _get_token(self) -> str:
        """액세스 토큰 발급 (만료 전 자동 갱신)"""
        now = datetime.now()
        if self._access_token and self._token_expired and now < self._token_expired:
            return self._access_token

        url  = f"{self.base_url}/oauth2/tokenP"
        body = {
            "grant_type": "client_credentials",
            "appkey":     self.app_key,
            "appsecret":  self.app_secret,
        }
        resp = requests.post(url, json=body, timeout=10)
        resp.raise_for_status()
        data = resp.json()

        self._access_token  = data["access_token"]
        expires_in          = int(data.get("expires_in", 86400))
        self._token_expired = now + timedelta(seconds=expires_in - 60)
        logger.info("✅ KIS 액세스 토큰 발급 성공")
        return self._access_token

    def _hashkey(self, body: dict) -> str:
        """매수/매도 주문용 HashKey 생성"""
        url  = f"{self.base_url}/uapi/hashkey"
        hdrs = {
            "content-type": "application/json",
            "appkey":        self.app_key,
            "appsecret":     self.app_secret,
        }
        resp = requests.post(url, headers=hdrs, json=body, timeout=10)
        resp.raise_for_status()
        return resp.json()["HASH"]

    def _headers(self, tr_id: str, use_hash: bool = False, body: dict = None) -> dict:
        token = self._get_token()
        h = {
            "content-type":  "application/json; charset=utf-8",
            "authorization": f"Bearer {token}",
            "appkey":         self.app_key,
            "appsecret":      self.app_secret,
            "tr_id":          tr_id,
            "custtype":       "P",
        }
        if use_hash and body:
            h["hashkey"] = self._hashkey(body)
        return h

    # ──────────────────────────────────────────────────────────
    # 2. 시세 조회
    # ──────────────────────────────────────────────────────────
    def get_current_price(self, stock_code: str) -> dict:
        """주식 현재가 조회"""
        url = f"{self.base_url}/uapi/domestic-stock/v1/quotations/inquire-price"
        tr_id = "FHKST01010100"
        params = {
            "fid_cond_mrkt_div_code": "J",
            "fid_input_iscd": stock_code,
        }
        try:
            resp = requests.get(url, headers=self._headers(tr_id),
                                params=params, timeout=10)
            resp.raise_for_status()
            data = resp.json()
            output = data.get("output", {})
            return {
                "code":          stock_code,
                "price":         int(output.get("stck_prpr", 0)),
                "open":          int(output.get("stck_oprc", 0)),
                "high":          int(output.get("stck_hgpr", 0)),
                "low":           int(output.get("stck_lwpr", 0)),
                "volume":        int(output.get("acml_vol", 0)),
                "change_rate":   float(output.get("prdy_ctrt", 0)),
                "change_price":  int(output.get("prdy_vrss", 0)),
                "market_cap":    output.get("hts_avls", "0"),
            }
        except Exception as e:
            logger.error(f"현재가 조회 실패 {stock_code}: {e}")
            return {}

    def get_ohlcv(self, stock_code: str, period: str = "D",
                  count: int = 100) -> list[dict]:
        """
        일/주/월봉 조회
        period: D(일), W(주), M(월)
        """
        url = f"{self.base_url}/uapi/domestic-stock/v1/quotations/inquire-daily-itemchartprice"
        tr_id = "FHKST03010100"
        end_dt   = datetime.now().strftime("%Y%m%d")
        start_dt = (datetime.now() - timedelta(days=count * 2)).strftime("%Y%m%d")
        params = {
            "fid_cond_mrkt_div_code": "J",
            "fid_input_iscd":         stock_code,
            "fid_input_date_1":       start_dt,
            "fid_input_date_2":       end_dt,
            "fid_period_div_code":    period,
            "fid_org_adj_prc":        "0",
        }
        try:
            resp = requests.get(url, headers=self._headers(tr_id),
                                params=params, timeout=10)
            resp.raise_for_status()
            data   = resp.json()
            output = data.get("output2", [])
            candles = []
            for row in output:
                candles.append({
                    "date":   row.get("stck_bsop_date", ""),
                    "open":   int(row.get("stck_oprc", 0)),
                    "high":   int(row.get("stck_hgpr", 0)),
                    "low":    int(row.get("stck_lwpr", 0)),
                    "close":  int(row.get("stck_clpr", 0)),
                    "volume": int(row.get("acml_vol", 0)),
                })
            candles.sort(key=lambda x: x["date"])
            return candles[-count:]
        except Exception as e:
            logger.error(f"OHLCV 조회 실패 {stock_code}: {e}")
            return []

    # ──────────────────────────────────────────────────────────
    # 3. 주문
    # ──────────────────────────────────────────────────────────
    def _order(self, stock_code: str, order_type: str,
               qty: int, price: int = 0,
               ord_dvsn: str = None) -> dict:
        """
        order_type : BUY | SELL
        price      : 0 이면 시장가
        ord_dvsn   : KIS 주문유형 코드
                     00 지정가 / 01 시장가
                     05 장전시간외 / 06 장후시간외
                     None → price 값으로 자동 선택
        """
        url = f"{self.base_url}/uapi/domestic-stock/v1/trading/order-cash"
        # 실전 전용: TTTC0802U(매수) / TTTC0801U(매도)
        tr_id = "TTTC0802U" if order_type == "BUY" else "TTTC0801U"

        acc_no, acc_prod = self.account_no.split("-") \
            if "-" in self.account_no else (self.account_no, "01")

        # 주문 유형 코드 자동 결정
        if ord_dvsn is None:
            ord_dvsn = "01" if price == 0 else "00"

        body = {
            "CANO":         acc_no,
            "ACNT_PRDT_CD": acc_prod,
            "PDNO":         stock_code,
            "ORD_DVSN":     ord_dvsn,
            "ORD_QTY":      str(qty),
            "ORD_UNPR":     str(price) if price > 0 else "0",
        }
        try:
            resp = requests.post(url,
                                 headers=self._headers(tr_id, use_hash=True, body=body),
                                 json=body, timeout=10)
            resp.raise_for_status()
            result = resp.json()
            if result.get("rt_cd") == "0":
                logger.info(f"✅ {order_type} 주문 성공 | {stock_code} {qty}주 {price}원")
            else:
                logger.warning(f"⚠️ {order_type} 주문 실패 | {result.get('msg1')}")
            return result
        except Exception as e:
            logger.error(f"주문 오류 {stock_code}: {e}")
            return {"rt_cd": "9", "msg1": str(e)}

    def buy(self, stock_code: str, qty: int, price: int = 0,
           ord_dvsn: str = None) -> dict:
        return self._order(stock_code, "BUY", qty, price, ord_dvsn)

    def sell(self, stock_code: str, qty: int, price: int = 0,
            ord_dvsn: str = None) -> dict:
        return self._order(stock_code, "SELL", qty, price, ord_dvsn)

    # ──────────────────────────────────────────────────────────
    # 4. 잔고 조회
    # ──────────────────────────────────────────────────────────
    def get_balance(self) -> dict:
        """보유 주식 및 예수금 조회"""
        url = f"{self.base_url}/uapi/domestic-stock/v1/trading/inquire-balance"
        tr_id = "TTTC8434R"  # 실전 전용
        acc_no, acc_prod = self.account_no.split("-") \
            if "-" in self.account_no else (self.account_no, "01")
        params = {
            "CANO":         acc_no,
            "ACNT_PRDT_CD": acc_prod,
            "AFHR_FLPR_YN": "N",
            "OFL_YN":       "",
            "INQR_DVSN":    "02",
            "UNPR_DVSN":    "01",
            "FUND_STTL_ICLD_YN": "N",
            "FNCG_AMT_AUTO_RDPT_YN": "N",
            "PRCS_DVSN":    "01",
            "CTX_AREA_FK100": "",
            "CTX_AREA_NK100": "",
        }
        try:
            resp = requests.get(url, headers=self._headers(tr_id),
                                params=params, timeout=10)
            resp.raise_for_status()
            data = resp.json()
            holdings = []
            for item in data.get("output1", []):
                qty = int(item.get("hldg_qty", 0))
                if qty > 0:
                    pnl_pct = float(item.get("evlu_pfls_rt", 0))
                    pnl_amt = int(item.get("evlu_pfls_amt", 0))
                    holdings.append({
                        "code":       item.get("pdno", ""),
                        "name":       item.get("prdt_name", ""),
                        "qty":        qty,
                        "avg_price":  float(item.get("pchs_avg_pric", 0)),
                        "cur_price":  int(item.get("prpr", 0)),
                        "pnl_pct":    pnl_pct,   # 대시보드 호환
                        "pnl_amt":    pnl_amt,   # 대시보드 호환
                        "profit_pct": pnl_pct,   # 하위 호환
                        "profit_amt": pnl_amt,   # 하위 호환
                    })
            summary = data.get("output2", [{}])[0]
            return {
                "holdings":       holdings,
                "total_eval":     int(summary.get("tot_evlu_amt", 0)),
                "cash":           int(summary.get("dnca_tot_amt", 0)),
                "total_profit":   int(summary.get("evlu_pfls_smtl_amt", 0)),
                "total_profit_pct": float(summary.get("tot_evlu_pfls_rt", 0)),
            }
        except Exception as e:
            logger.error(f"잔고 조회 실패: {e}")
            return {"holdings": [], "total_eval": 0, "cash": 0,
                    "total_profit": 0, "total_profit_pct": 0}

    # ──────────────────────────────────────────────────────────
    # 5. 체결 내역 조회
    # ──────────────────────────────────────────────────────────
    # ──────────────────────────────────────────────────────────
    # ★ 해외주식 API (미국/홍콩 등)
    # ──────────────────────────────────────────────────────────

    # 거래소 코드 매핑 (KIS 기준)
    # NASD=나스닥 NYSE=뉴욕 AMEX=아멕스 SEHK=홍콩 SHAA=상하이A SZAA=선전A TKSE=도쿄
    US_EXCD = {
        "NASD": "나스닥",
        "NYSE": "뉴욕증권거래소",
        "AMEX": "아멕스",
    }

    def get_us_current_price(self, symbol: str, excd: str = "NASD") -> dict:
        """
        해외주식 현재가 조회
        symbol: 티커 (AAPL, NVDA ...)
        excd  : 거래소코드 (NASD/NYSE/AMEX)
        """
        url   = f"{self.base_url}/uapi/overseas-price/v1/quotations/price"
        tr_id = "HHDFS00000300"
        params = {
            "AUTH":  "",
            "EXCD":  excd,
            "SYMB":  symbol,
        }
        try:
            resp = requests.get(url, headers=self._headers(tr_id),
                                params=params, timeout=10)
            resp.raise_for_status()
            data   = resp.json()
            output = data.get("output", {})
            price  = float(output.get("last", 0) or 0)
            return {
                "symbol":       symbol,
                "excd":         excd,
                "price":        price,           # USD
                "open":         float(output.get("open",  0) or 0),
                "high":         float(output.get("high",  0) or 0),
                "low":          float(output.get("low",   0) or 0),
                "volume":       int(output.get("tvol",    0) or 0),
                "change_rate":  float(output.get("rate",  0) or 0),   # 등락률 %
                "change_price": float(output.get("diff",  0) or 0),   # 등락액 USD
                "market_cap":   output.get("mktcap", ""),
                "currency":     "USD",
            }
        except Exception as e:
            logger.error(f"해외현재가 조회 실패 {symbol}: {e}")
            return {}

    def get_us_ohlcv(self, symbol: str, excd: str = "NASD",
                     count: int = 100) -> list[dict]:
        """
        해외주식 일봉 OHLCV 조회 (최근 count일)
        """
        url   = f"{self.base_url}/uapi/overseas-price/v1/quotations/dailyprice"
        tr_id = "HHDFS76240000"
        end_dt   = datetime.now().strftime("%Y%m%d")
        start_dt = (datetime.now() - timedelta(days=count * 2)).strftime("%Y%m%d")
        params = {
            "AUTH":  "",
            "EXCD":  excd,
            "SYMB":  symbol,
            "GUBN":  "0",        # 0:일 1:주 2:월
            "BYMD":  end_dt,
            "MODP":  "1",        # 수정주가
            "KEYB":  "",
        }
        try:
            resp = requests.get(url, headers=self._headers(tr_id),
                                params=params, timeout=10)
            resp.raise_for_status()
            data   = resp.json()
            output = data.get("output2", [])
            candles = []
            for row in output:
                c = float(row.get("clos", 0) or 0)
                if c <= 0:
                    continue
                candles.append({
                    "date":   row.get("xymd", ""),
                    "open":   float(row.get("open", 0) or 0),
                    "high":   float(row.get("high", 0) or 0),
                    "low":    float(row.get("low",  0) or 0),
                    "close":  c,
                    "volume": int(row.get("tvol", 0) or 0),
                })
            candles.sort(key=lambda x: x["date"])
            return candles[-count:]
        except Exception as e:
            logger.error(f"해외 OHLCV 조회 실패 {symbol}: {e}")
            return []

    def buy_us(self, symbol: str, qty: int, price: float = 0,
               excd: str = "NASD") -> dict:
        """
        해외주식 매수 (실전)
        price=0 → 시장가
        """
        url   = f"{self.base_url}/uapi/overseas-stock/v1/trading/order"
        tr_id = "TTTT1002U"   # 실전 해외주식 매수
        acc_no, acc_prod = self.account_no.split("-") \
            if "-" in self.account_no else (self.account_no, "01")

        # 시장가/지정가 구분
        sll_type = "00" if price > 0 else "00"   # 00=지정가, KIS는 해외도 지정가 권장
        ord_price = f"{price:.2f}" if price > 0 else "0"

        body = {
            "CANO":         acc_no,
            "ACNT_PRDT_CD": acc_prod,
            "OVRS_EXCG_CD": excd,
            "PDNO":         symbol,
            "ORD_DVSN":     sll_type,
            "ORD_QTY":      str(qty),
            "OVRS_ORD_UNPR": ord_price,
            "ORD_SVR_DVSN_CD": "0",
        }
        try:
            resp = requests.post(url,
                                 headers=self._headers(tr_id, use_hash=True, body=body),
                                 json=body, timeout=10)
            resp.raise_for_status()
            result = resp.json()
            if result.get("rt_cd") == "0":
                logger.info(f"✅ 해외 BUY 성공 | {symbol}({excd}) {qty}주 ${price:.2f}")
            else:
                logger.warning(f"⚠️ 해외 BUY 실패 | {result.get('msg1')}")
            return result
        except Exception as e:
            logger.error(f"해외 매수 오류 {symbol}: {e}")
            return {"rt_cd": "9", "msg1": str(e)}

    def sell_us(self, symbol: str, qty: int, price: float = 0,
                excd: str = "NASD") -> dict:
        """
        해외주식 매도 (실전)
        """
        url   = f"{self.base_url}/uapi/overseas-stock/v1/trading/order"
        tr_id = "TTTT1006U"   # 실전 해외주식 매도
        acc_no, acc_prod = self.account_no.split("-") \
            if "-" in self.account_no else (self.account_no, "01")

        ord_price = f"{price:.2f}" if price > 0 else "0"

        body = {
            "CANO":         acc_no,
            "ACNT_PRDT_CD": acc_prod,
            "OVRS_EXCG_CD": excd,
            "PDNO":         symbol,
            "ORD_DVSN":     "00",
            "ORD_QTY":      str(qty),
            "OVRS_ORD_UNPR": ord_price,
            "ORD_SVR_DVSN_CD": "0",
        }
        try:
            resp = requests.post(url,
                                 headers=self._headers(tr_id, use_hash=True, body=body),
                                 json=body, timeout=10)
            resp.raise_for_status()
            result = resp.json()
            if result.get("rt_cd") == "0":
                logger.info(f"✅ 해외 SELL 성공 | {symbol}({excd}) {qty}주 ${price:.2f}")
            else:
                logger.warning(f"⚠️ 해외 SELL 실패 | {result.get('msg1')}")
            return result
        except Exception as e:
            logger.error(f"해외 매도 오류 {symbol}: {e}")
            return {"rt_cd": "9", "msg1": str(e)}

    def get_us_balance(self) -> dict:
        """
        해외주식 보유잔고 + 예수금 조회 (실전)
        """
        url   = f"{self.base_url}/uapi/overseas-stock/v1/trading/inquire-balance"
        tr_id = "TTTS3012R"   # 실전 해외주식 잔고
        acc_no, acc_prod = self.account_no.split("-") \
            if "-" in self.account_no else (self.account_no, "01")
        params = {
            "CANO":         acc_no,
            "ACNT_PRDT_CD": acc_prod,
            "OVRS_EXCG_CD": "NASD",   # 전체 조회용 (KIS 전체 잔고 반환)
            "TR_CRCY_CD":   "USD",
            "CTX_AREA_FK200": "",
            "CTX_AREA_NK200": "",
        }
        try:
            resp = requests.get(url, headers=self._headers(tr_id),
                                params=params, timeout=10)
            resp.raise_for_status()
            data = resp.json()
            holdings = []
            for item in data.get("output1", []):
                qty = int(item.get("ccld_qty_smtl", 0) or 0)
                if qty <= 0:
                    continue
                holdings.append({
                    "symbol":      item.get("pdno", ""),
                    "name":        item.get("prdt_name", ""),
                    "excd":        item.get("ovrs_excg_cd", "NASD"),
                    "qty":         qty,
                    "avg_price":   float(item.get("pchs_avg_pric", 0) or 0),   # USD
                    "cur_price":   float(item.get("now_pric2",     0) or 0),   # USD
                    "pnl_pct":     float(item.get("evlu_pfls_rt",  0) or 0),
                    "pnl_amt":     float(item.get("frcr_evlu_pfls_amt", 0) or 0),  # USD
                    "currency":    "USD",
                    "is_overseas": True,
                })
            output2 = data.get("output2", {})
            if isinstance(output2, list):
                output2 = output2[0] if output2 else {}
            return {
                "holdings":     holdings,
                "total_eval":   float(output2.get("tot_evlu_pfls_amt", 0) or 0),
                "cash_usd":     float(output2.get("frcr_dncl_amt_2",   0) or 0),
                "total_profit": float(output2.get("ovrs_tot_pfls",      0) or 0),
            }
        except Exception as e:
            logger.error(f"해외 잔고 조회 실패: {e}")
            return {"holdings": [], "total_eval": 0, "cash_usd": 0, "total_profit": 0}

    def get_usd_exchange_rate(self) -> float:
        """
        USD/KRW 환율 조회 (KST 기준 당일 환율)

        방법 1: KIS API  inquire-daily-chartprice
          - TR_ID : FHKST03030100
          - 심볼  : FX@KRWKFTC  (서울외국환중개 기준율, 가장 정확)
          - 응답  : output2[0].ovrs_nmix_prpr  (종가 = 당일 환율)
          - output1.ovrs_nmix_prpr 도 시도 (장중 현재값)

        방법 2: yfinance  USDKRW=X  (KIS 실패 시 폴백)
        """
        # ── 방법 1: KIS API ──────────────────────────────────────
        url   = f"{self.base_url}/uapi/overseas-price/v1/quotations/inquire-daily-chartprice"
        tr_id = "FHKST03030100"
        today = datetime.now().strftime("%Y%m%d")
        params = {
            "FID_COND_MRKT_DIV_CODE": "X",
            "FID_INPUT_ISCD":          "FX@KRWKFTC",   # ← 서울외국환중개 USD/KRW
            "FID_INPUT_DATE_1":        today,
            "FID_INPUT_DATE_2":        today,
            "FID_PERIOD_DIV_CODE":     "D",
        }
        try:
            resp = requests.get(url, headers=self._headers(tr_id),
                                params=params, timeout=5)
            resp.raise_for_status()
            body = resp.json()

            # output1 → 당일 현재 환율 (장중 업데이트)
            out1 = body.get("output1", {})
            if isinstance(out1, list):
                out1 = out1[0] if out1 else {}
            rate = float(out1.get("ovrs_nmix_prpr", 0) or 0)
            if rate > 500:
                logger.info(f"✅ KIS 환율(output1) 조회 성공: {rate:.2f}")
                return rate

            # output2 → 최근 일봉 (output1 없을 때 최신 종가 사용)
            out2 = body.get("output2", [])
            if isinstance(out2, list) and out2:
                rate = float(out2[0].get("ovrs_nmix_prpr", 0) or 0)
                if rate > 500:
                    logger.info(f"✅ KIS 환율(output2) 조회 성공: {rate:.2f}")
                    return rate

            logger.warning(f"⚠️ KIS 환율 응답 이상 (rt_cd={body.get('rt_cd')}, msg={body.get('msg1')})")
        except Exception as e:
            logger.warning(f"⚠️ KIS 환율 조회 실패: {e}")

        # ── 방법 2: yfinance 폴백 ─────────────────────────────────
        try:
            import yfinance as yf
            ticker = yf.Ticker("USDKRW=X")
            # fast_info 우선 (빠름), 실패 시 history
            rate = float(ticker.fast_info.get("last_price") or 0)
            if rate > 500:
                logger.info(f"✅ yfinance 환율 조회 성공: {rate:.2f}")
                return rate
            hist = ticker.history(period="2d")
            if not hist.empty:
                rate = float(hist["Close"].iloc[-1])
                if rate > 500:
                    logger.info(f"✅ yfinance(history) 환율 조회 성공: {rate:.2f}")
                    return rate
        except Exception as e:
            logger.warning(f"⚠️ yfinance 환율 조회 실패: {e}")

        # ── 방법 3: 외부 공개 API (최후 수단) ────────────────────
        try:
            resp = requests.get(
                "https://api.exchangerate-api.com/v4/latest/USD",
                timeout=5
            )
            resp.raise_for_status()
            rate = float(resp.json().get("rates", {}).get("KRW", 0))
            if rate > 500:
                logger.info(f"✅ ExchangeRate-API 환율 조회 성공: {rate:.2f}")
                return rate
        except Exception as e:
            logger.warning(f"⚠️ ExchangeRate-API 실패: {e}")

        logger.error("❌ 모든 환율 조회 실패 → 기본값 1300 사용")
        return 1300.0    # 최후 안전 기본값

    def get_order_history(self, days: int = 7) -> list[dict]:
        """최근 체결 내역 조회"""
        url = f"{self.base_url}/uapi/domestic-stock/v1/trading/inquire-daily-ccld"
        tr_id = "TTTC8001R"  # 실전 전용
        acc_no, acc_prod = self.account_no.split("-") \
            if "-" in self.account_no else (self.account_no, "01")
        start = (datetime.now() - timedelta(days=days)).strftime("%Y%m%d")
        end   = datetime.now().strftime("%Y%m%d")
        params = {
            "CANO":         acc_no,
            "ACNT_PRDT_CD": acc_prod,
            "INQR_STRT_DT": start,
            "INQR_END_DT":  end,
            "SLL_BUY_DVSN_CD": "00",
            "INQR_DVSN":    "00",
            "PDNO":         "",
            "CCLD_DVSN":    "01",
            "ORD_GNO_BRNO":  "",
            "ODNO":         "",
            "INQR_DVSN_3":  "00",
            "INQR_DVSN_1":  "",
            "CTX_AREA_FK100": "",
            "CTX_AREA_NK100": "",
        }
        try:
            resp = requests.get(url, headers=self._headers(tr_id),
                                params=params, timeout=10)
            resp.raise_for_status()
            data = resp.json()
            orders = []
            for item in data.get("output1", []):
                orders.append({
                    "date":    item.get("ord_dt", ""),
                    "time":    item.get("ord_tmd", ""),
                    "code":    item.get("pdno", ""),
                    "name":    item.get("prdt_name", ""),
                    "type":    "매수" if item.get("sll_buy_dvsn_cd") == "02" else "매도",
                    "qty":     int(item.get("tot_ccld_qty", 0)),
                    "price":   int(item.get("avg_prvs", 0)),
                    "amount":  int(item.get("tot_ccld_amt", 0)),
                    "status":  item.get("ord_stts_name", ""),
                })
            return orders
        except Exception as e:
            logger.error(f"체결 내역 조회 실패: {e}")
            return []
