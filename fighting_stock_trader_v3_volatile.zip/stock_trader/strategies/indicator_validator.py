"""
보조지표 검증 레이어
=====================
피라미딩 진입 전 보조지표로 신호를 검증합니다.
각 지표가 "매수" 신호를 보낼 때 +1점 카운트 → indicator_score 반환

사용 지표 (총 6개):
  1. MA   — 이동평균 배열 (MA5 > MA20 > MA60)
  2. RSI  — 과매도 탈출 (30→50 회복 구간)
  3. MACD — MACD > Signal, 히스토그램 양전환
  4. BB   — 볼린저밴드 하단 터치 후 반등
  5. ATR  — 변동성 확대 (추세 출현 신호)
  6. OBV  — 거래량 증가 동반 (매집 신호)

★ 추가: trend_score (0~100) — 강한 종목 집중 철학 지원 ★
  추세강도 점수: 아래 4개 요소 합산 (각 0~25점)
    A. RS  (상대강도)        — 시장 대비 최근 20일 수익률 우위
    B. ADX (추세방향 강도)   — DMI+ > DMI- 이고 ADX > 25
    C. 모멘텀 가속도         — 최근 5일 가격 변화율이 20일 평균보다 높음
    D. 고점 경신             — 현재가가 최근 20일 고점 근처 (95% 이상)
  → trend_score = 0~100 (높을수록 강한 상승 추세)
  → 'strong_trend': True if trend_score ≥ 60
"""

import numpy as np
import pandas as pd
from utils.logger import get_logger

logger = get_logger("IndicatorValidator")

# ── 추세강도 점수 기준 ────────────────────────────────────────
STRONG_TREND_THRESHOLD = 60   # trend_score ≥ 60 → 강한 추세 종목
ADX_STRONG_LEVEL       = 25   # ADX ≥ 25 → 추세 강함
ADX_VERY_STRONG        = 40   # ADX ≥ 40 → 매우 강한 추세


class IndicatorValidator:
    """
    candles 리스트를 받아 각 보조지표 매수 신호 여부 판단.

    returns: {
        score,       매수 신호 보조지표 개수 (0~6)
        sell_score,  매도 신호 보조지표 개수 (0~6)
        signals,     {지표명: True/False}
        detail,      {지표명: {value, signal, reason}}
        trend_score, 추세강도 점수 (0~100) ★ 신규
        strong_trend,True if trend_score ≥ 60 ★ 신규
        trend_detail, {A~D: {score, reason}} ★ 신규
        reason,
    }
    """

    def validate(self, candles: list[dict]) -> dict:
        """
        returns:
          score       : 매수 신호 보조지표 개수 (0~6)
          signals     : {지표명: True/False}
          detail      : {지표명: {value, signal, reason}}
          sell_score  : 매도 신호 보조지표 개수
          trend_score : 추세강도 점수 (0~100) ★
          strong_trend: True if trend_score ≥ 60 ★
          trend_detail: 추세강도 세부 내역 ★
        """
        if len(candles) < 65:
            return {
                "score": 0, "sell_score": 0,
                "signals": {}, "detail": {},
                "trend_score": 0, "strong_trend": False,
                "trend_detail": {},
                "reason": "데이터 부족",
            }

        df = pd.DataFrame(candles)
        c  = df["close"].astype(float)
        h  = df["high"].astype(float)
        lo = df["low"].astype(float)
        v  = df["volume"].astype(float)

        results = {}
        results["MA"]   = self._check_ma(c)
        results["RSI"]  = self._check_rsi(c)
        results["MACD"] = self._check_macd(c)
        results["BB"]   = self._check_bb(c)
        results["ATR"]  = self._check_atr(c, h, lo)
        results["OBV"]  = self._check_obv(c, v)

        buy_score  = sum(1 for r in results.values() if r["signal"] == "BUY")
        sell_score = sum(1 for r in results.values() if r["signal"] == "SELL")
        signals    = {k: (r["signal"] == "BUY") for k, r in results.items()}

        # ★ 추세강도 점수 계산
        trend_result = self._calc_trend_score(c, h, lo, v)
        trend_score  = trend_result["trend_score"]
        strong_trend = trend_score >= STRONG_TREND_THRESHOLD

        # 종합 사유
        buy_names  = [k for k, r in results.items() if r["signal"] == "BUY"]
        sell_names = [k for k, r in results.items() if r["signal"] == "SELL"]
        reason = (f"매수지표: {', '.join(buy_names) or '없음'} | "
                  f"매도지표: {', '.join(sell_names) or '없음'} | "
                  f"추세강도: {trend_score:.0f}/100"
                  f"{'(★강)' if strong_trend else ''}")

        logger.debug(
            f"지표검증 BUY={buy_score} SELL={sell_score} "
            f"추세={trend_score:.0f}/100 | {reason}"
        )
        return {
            "score":        buy_score,
            "sell_score":   sell_score,
            "signals":      signals,
            "detail":       results,
            "trend_score":  round(trend_score, 1),
            "strong_trend": strong_trend,
            "trend_detail": trend_result["detail"],
            "reason":       reason,
        }

    # ══════════════════════════════════════════════════════════
    # ★ 추세강도 점수 (0~100) — 강한 종목 집중 철학 지원
    # ══════════════════════════════════════════════════════════
    def _calc_trend_score(self, c: pd.Series,
                          h: pd.Series,
                          lo: pd.Series,
                          v: pd.Series) -> dict:
        """
        4개 요소로 추세강도 점수 계산 (각 0~25점, 합산 0~100점).

        A. RS (상대강도 대리지표)
           — 최근 20일 수익률이 최근 60일 평균 수익률의 몇 배인지
        B. ADX (추세방향 강도)
           — DMI+ > DMI- 이고 ADX ≥ 25: 방향성 있는 추세
        C. 모멘텀 가속도
           — 최근 5일 일평균 변화율이 20일 일평균보다 높음
        D. 고점 경신 근접도
           — 현재가가 최근 20일 고점의 95% 이상
        """
        detail = {}
        total  = 0.0

        # ── A. RS 대리지표: 최근 20일 수익률 우위 ──────────
        # 시장 벤치마크 없이 자체 모멘텀으로 RS 근사
        ret20 = (float(c.iloc[-1]) / float(c.iloc[-20]) - 1) * 100
        ret60 = (float(c.iloc[-1]) / float(c.iloc[-60]) - 1) * 100

        if ret20 > 10:
            rs_score = 25.0
        elif ret20 > 5:
            rs_score = 20.0
        elif ret20 > 2:
            rs_score = 15.0
        elif ret20 > 0:
            rs_score = 10.0
        elif ret20 > -3:
            rs_score = 5.0
        else:
            rs_score = 0.0

        # 20일 수익률이 60일 수익률 대비 가속 중이면 보너스
        if ret20 > ret60:
            rs_score = min(25.0, rs_score + 5.0)

        total += rs_score
        detail["A_RS"] = {
            "score":  round(rs_score, 1),
            "ret20":  round(ret20, 2),
            "ret60":  round(ret60, 2),
            "reason": (f"20일수익률={ret20:.1f}% 60일={ret60:.1f}% "
                       f"{'가속↑' if ret20 > ret60 else '감속↓'}"),
        }

        # ── B. ADX (추세방향 강도) ──────────────────────────
        adx_data = self._calc_adx(c, h, lo, period=14)
        adx      = adx_data["adx"]
        plus_di  = adx_data["plus_di"]
        minus_di = adx_data["minus_di"]
        bullish  = plus_di > minus_di   # 상승 추세 방향

        if bullish and adx >= ADX_VERY_STRONG:   # ≥ 40: 매우 강한 추세
            adx_score = 25.0
        elif bullish and adx >= ADX_STRONG_LEVEL:  # ≥ 25: 강한 추세
            adx_score = 20.0
        elif bullish and adx >= 15:              # 약한 추세 형성
            adx_score = 10.0
        elif not bullish and adx >= ADX_STRONG_LEVEL:  # 하락 추세
            adx_score = 0.0
        else:
            adx_score = 5.0   # 방향성 약함

        total += adx_score
        detail["B_ADX"] = {
            "score":    round(adx_score, 1),
            "adx":      round(adx, 1),
            "plus_di":  round(plus_di, 1),
            "minus_di": round(minus_di, 1),
            "reason":   (f"ADX={adx:.1f} +DI={plus_di:.1f} -DI={minus_di:.1f} "
                         f"{'상승추세↑' if bullish else '하락추세↓'}"),
        }

        # ── C. 모멘텀 가속도 ────────────────────────────────
        # 최근 5일 일평균 변화율 vs 최근 20일 일평균 변화율
        daily_ret = c.pct_change()
        mom5  = float(daily_ret.iloc[-5:].mean()) * 100   # 최근 5일 평균 일수익률
        mom20 = float(daily_ret.iloc[-20:].mean()) * 100  # 최근 20일 평균 일수익률

        if mom5 > 0.5 and mom5 > mom20 * 1.5:
            mom_score = 25.0   # 강한 가속
        elif mom5 > 0.2 and mom5 > mom20:
            mom_score = 18.0   # 보통 가속
        elif mom5 > 0:
            mom_score = 10.0   # 약한 상승
        elif mom5 > -0.2:
            mom_score = 5.0    # 횡보
        else:
            mom_score = 0.0    # 하락 모멘텀

        total += mom_score
        detail["C_Momentum"] = {
            "score":  round(mom_score, 1),
            "mom5":   round(mom5, 3),
            "mom20":  round(mom20, 3),
            "reason": (f"5일평균일수익={mom5:.3f}% 20일={mom20:.3f}% "
                       f"{'가속↑' if mom5 > mom20 else '감속↓'}"),
        }

        # ── D. 고점 경신 근접도 ─────────────────────────────
        price    = float(c.iloc[-1])
        high20   = float(h.iloc[-20:].max())
        nearness = price / high20  # 1.0 = 신고점

        if nearness >= 1.0:
            near_score = 25.0   # 신고점 돌파
        elif nearness >= 0.98:
            near_score = 22.0   # 고점 98% 이상
        elif nearness >= 0.95:
            near_score = 15.0   # 고점 95% 이상
        elif nearness >= 0.90:
            near_score = 8.0    # 고점 90% 이상
        else:
            near_score = 0.0    # 고점과 거리 멈

        total += near_score
        detail["D_HighProximity"] = {
            "score":    round(near_score, 1),
            "price":    round(price),
            "high20":   round(high20),
            "nearness": round(nearness * 100, 1),
            "reason":   (f"현재가={price:.0f} 20일고점={high20:.0f} "
                         f"근접도={nearness*100:.1f}%"
                         f"{'★신고점' if nearness >= 1.0 else ''}"),
        }

        return {
            "trend_score": round(min(total, 100.0), 1),
            "detail":      detail,
        }

    # ══════════════════════════════════════════════════════════
    # ADX / DMI 계산 (추세강도용)
    # ══════════════════════════════════════════════════════════
    def _calc_adx(self, c: pd.Series, h: pd.Series,
                  lo: pd.Series, period: int = 14) -> dict:
        """
        ADX (Average Directional Index) + DMI ±.
        방향성 있는 추세의 강도를 0~100 으로 나타냄.
        ADX ≥ 25: 추세 강함, ADX < 20: 횡보/약한 추세.
        """
        # True Range
        prev_c  = c.shift(1)
        tr      = pd.concat([
            h - lo,
            (h - prev_c).abs(),
            (lo - prev_c).abs()
        ], axis=1).max(axis=1)

        # Directional Movement
        up_move   = h.diff()
        down_move = (-lo.diff())
        plus_dm   = up_move.where((up_move > down_move) & (up_move > 0), 0.0)
        minus_dm  = down_move.where((down_move > up_move) & (down_move > 0), 0.0)

        # Smoothed (Wilder's EMA ≈ rolling mean for simplicity)
        atr_s     = tr.rolling(period).mean()
        plus_di_s = plus_dm.rolling(period).mean()
        minus_di_s= minus_dm.rolling(period).mean()

        plus_di   = (plus_di_s / atr_s.replace(0, 1e-10) * 100).iloc[-1]
        minus_di  = (minus_di_s / atr_s.replace(0, 1e-10) * 100).iloc[-1]

        # DX → ADX
        di_sum  = plus_di + minus_di
        dx      = abs(plus_di - minus_di) / (di_sum if di_sum != 0 else 1e-10) * 100
        # ADX는 DX의 이동평균 (간략 계산: 마지막 period 개 DX의 평균)
        plus_di_series  = plus_di_s / atr_s.replace(0, 1e-10) * 100
        minus_di_series = minus_di_s / atr_s.replace(0, 1e-10) * 100
        di_sum_series   = plus_di_series + minus_di_series
        dx_series = (
            (plus_di_series - minus_di_series).abs()
            / di_sum_series.replace(0, 1e-10) * 100
        )
        adx = float(dx_series.rolling(period).mean().iloc[-1])

        return {
            "adx":      float(adx if not np.isnan(adx) else 0.0),
            "plus_di":  float(plus_di if not np.isnan(plus_di) else 0.0),
            "minus_di": float(minus_di if not np.isnan(minus_di) else 0.0),
        }

    # ── 1. 이동평균 ────────────────────────────────────────
    def _check_ma(self, c: pd.Series) -> dict:
        ma5  = float(c.rolling(5).mean().iloc[-1])
        ma20 = float(c.rolling(20).mean().iloc[-1])
        ma60 = float(c.rolling(60).mean().iloc[-1])
        price= float(c.iloc[-1])

        # 정배열: MA5 > MA20 > MA60 + 현재가가 MA5 위
        bull = (ma5 > ma20 > ma60) and (price > ma5)
        # 역배열: 매도
        bear = (ma5 < ma20 < ma60) and (price < ma5)

        signal = "BUY" if bull else ("SELL" if bear else "HOLD")
        return {
            "signal": signal,
            "value":  {"MA5": round(ma5), "MA20": round(ma20), "MA60": round(ma60)},
            "reason": (f"정배열({'✅' if bull else '❌'}) "
                       f"MA5={ma5:.0f} MA20={ma20:.0f} MA60={ma60:.0f}"),
        }

    # ── 2. RSI ─────────────────────────────────────────────
    def _check_rsi(self, c: pd.Series) -> dict:
        delta    = c.diff()
        gain     = delta.clip(lower=0).ewm(alpha=1/14, adjust=False).mean()
        loss     = (-delta).clip(lower=0).ewm(alpha=1/14, adjust=False).mean()
        rsi      = float(100 - 100 / (1 + gain / loss.replace(0, 1e-10)).iloc[-1])
        prev_rsi = float(100 - 100 / (1 + gain / loss.replace(0, 1e-10)).iloc[-2])

        oversold_cross = (prev_rsi <= 35) and (rsi > 35)
        mid_up         = (rsi > 40) and (rsi < 60) and (rsi > prev_rsi)
        overbought     = rsi >= 70

        signal = ("BUY"  if (oversold_cross or mid_up) else
                  "SELL" if overbought else "HOLD")
        return {
            "signal": signal,
            "value":  {"RSI": round(rsi, 1), "prev_RSI": round(prev_rsi, 1)},
            "reason": (f"RSI={rsi:.1f} "
                       f"({'과매도탈출' if oversold_cross else '상승중' if mid_up else '과매수' if overbought else '중립'})"),
        }

    # ── 3. MACD ────────────────────────────────────────────
    def _check_macd(self, c: pd.Series) -> dict:
        ema12    = c.ewm(span=12, adjust=False).mean()
        ema26    = c.ewm(span=26, adjust=False).mean()
        macd     = ema12 - ema26
        signal_l = macd.ewm(span=9, adjust=False).mean()
        hist     = macd - signal_l

        mc  = float(macd.iloc[-1]);    mp  = float(macd.iloc[-2])
        sc  = float(signal_l.iloc[-1]); sp  = float(signal_l.iloc[-2])
        hc  = float(hist.iloc[-1]);    hp  = float(hist.iloc[-2])

        golden = (mp <= sp) and (mc > sc)
        hist_up= (hp < 0) and (hc > hp)
        dead   = (mp >= sp) and (mc < sc)

        signal = ("BUY"  if (golden or (mc > sc and hist_up)) else
                  "SELL" if dead else "HOLD")
        return {
            "signal": signal,
            "value":  {"MACD": round(mc, 2), "Signal": round(sc, 2),
                       "Hist": round(hc, 2)},
            "reason": (f"MACD={mc:.2f}/Sig={sc:.2f} "
                       f"({'골든크로스' if golden else '히스토그램↑' if hist_up else '데드크로스' if dead else '중립'})"),
        }

    # ── 4. 볼린저 밴드 ─────────────────────────────────────
    def _check_bb(self, c: pd.Series) -> dict:
        ma20 = c.rolling(20).mean()
        std  = c.rolling(20).std()
        upper= ma20 + 2 * std
        lower= ma20 - 2 * std
        bw   = (upper - lower) / ma20 * 100

        price  = float(c.iloc[-1])
        prev   = float(c.iloc[-2])
        lo_cur = float(lower.iloc[-1])
        lo_prev= float(lower.iloc[-2])
        up_cur = float(upper.iloc[-1])
        ma_cur = float(ma20.iloc[-1])
        bw_cur = float(bw.iloc[-1])

        touch_lower      = (prev <= lo_prev) and (price > lo_cur)
        above_mid_expand = (price > ma_cur) and (bw_cur > float(bw.rolling(10).mean().iloc[-1]))
        touch_upper      = price >= up_cur * 0.99

        signal = ("BUY"  if (touch_lower or above_mid_expand) else
                  "SELL" if touch_upper else "HOLD")
        return {
            "signal": signal,
            "value":  {"상단": round(up_cur), "중심": round(ma_cur),
                       "하단": round(lo_cur), "밴드폭": round(bw_cur, 1)},
            "reason": (f"현재={price:.0f} 하단={lo_cur:.0f} 상단={up_cur:.0f} "
                       f"({'하단반등' if touch_lower else '추세강화' if above_mid_expand else '상단과매수' if touch_upper else '중립'})"),
        }

    # ── 5. ATR (변동성) ────────────────────────────────────
    def _check_atr(self, c: pd.Series, h: pd.Series, lo: pd.Series) -> dict:
        prev_c  = c.shift(1)
        tr      = pd.concat([h - lo,
                             (h - prev_c).abs(),
                             (lo - prev_c).abs()], axis=1).max(axis=1)
        atr14   = float(tr.rolling(14).mean().iloc[-1])
        atr5    = float(tr.rolling(5).mean().iloc[-1])
        price   = float(c.iloc[-1])
        atr_pct = atr14 / price * 100

        vol_expand = atr5 > atr14 * 1.1
        high_vol   = atr_pct > 5.0

        signal = ("BUY"  if vol_expand and not high_vol else
                  "SELL" if high_vol else "HOLD")
        return {
            "signal": signal,
            "value":  {"ATR14": round(atr14), "ATR5": round(atr5),
                       "ATR%": round(atr_pct, 2)},
            "reason": (f"ATR14={atr14:.0f}({atr_pct:.1f}%) "
                       f"{'변동성확대↑' if vol_expand else '고변동위험' if high_vol else '보통'}"),
        }

    # ── 6. OBV (거래량 추세) ───────────────────────────────
    def _check_obv(self, c: pd.Series, v: pd.Series) -> dict:
        direction = np.sign(c.diff()).fillna(0)
        obv       = (direction * v).cumsum()
        obv_ma5   = obv.rolling(5).mean()
        obv_ma20  = obv.rolling(20).mean()

        obv_cur  = float(obv.iloc[-1])
        om5      = float(obv_ma5.iloc[-1])
        om20     = float(obv_ma20.iloc[-1])
        prev_om5 = float(obv_ma5.iloc[-2])

        obv_bull = (om5 > om20) and (om5 > prev_om5)
        obv_bear = (om5 < om20) and (om5 < prev_om5)

        signal = ("BUY"  if obv_bull else
                  "SELL" if obv_bear else "HOLD")
        return {
            "signal": signal,
            "value":  {"OBV": round(obv_cur), "OBV_MA5": round(om5),
                       "OBV_MA20": round(om20)},
            "reason": (f"OBV_MA5={om5:,.0f} MA20={om20:,.0f} "
                       f"({'매집↑' if obv_bull else '분산↓' if obv_bear else '중립'})"),
        }
