"""
미국 증시 야간 분석기 (US Market Screener)
==========================================
매일 00:00 KST (미국 장마감 후) 자동 실행

분석 내용:
  1. 주요 지수 현황  — S&P500 / 나스닥 / 다우 / VIX / 공포탐욕지수
  2. 섹터별 강도     — 11개 섹터 ETF 등락률 + 강도 순위
  3. 핵심 종목 분석  — 빅테크 + 반도체 + 금융 등 30개 주요주
  4. 시장 국면 판단  — BULL / LATERAL / BEAR
  5. 한국 시장 영향  — 미국 마감 기준 내일 한국 시장 예측 방향
  6. 주목 종목 TOP10 — 기술적 매수 신호 발생 종목

데이터 소스: yfinance (Yahoo Finance)
실행 시간: 매일 00:00 KST (미국 동부 기준 전일 11:00 AM)
"""

import json
import os
from datetime import datetime, date
import pytz

try:
    import yfinance as yf
    import numpy as np
    import pandas as pd
    HAS_YFINANCE = True
except ImportError:
    HAS_YFINANCE = False

from utils.logger import get_logger

logger = get_logger("USMarketScreener")

KST = pytz.timezone("Asia/Seoul")
US_RESULT_FILE = os.path.join(os.path.dirname(__file__), "..", "data", "us_market.json")

# ── 주요 지수 ────────────────────────────────────────────────
US_INDICES = {
    "^GSPC":  {"name": "S&P 500",    "emoji": "🇺🇸"},
    "^IXIC":  {"name": "나스닥",      "emoji": "💻"},
    "^DJI":   {"name": "다우존스",    "emoji": "🏦"},
    "^VIX":   {"name": "VIX 공포지수","emoji": "😱"},
    "^TNX":   {"name": "미국10년채",  "emoji": "📈"},
    "DX-Y.NYB":{"name":"달러인덱스",  "emoji": "💵"},
    "GC=F":   {"name": "금",          "emoji": "🥇"},
    "CL=F":   {"name": "WTI원유",     "emoji": "🛢️"},
}

# ── 섹터 ETF ─────────────────────────────────────────────────
US_SECTORS = {
    "XLK":  "기술(Tech)",
    "XLF":  "금융(Finance)",
    "XLV":  "헬스케어",
    "XLE":  "에너지",
    "XLI":  "산업재",
    "XLC":  "통신서비스",
    "XLY":  "경기소비재",
    "XLP":  "필수소비재",
    "XLB":  "소재",
    "XLRE": "리츠(부동산)",
    "XLU":  "유틸리티",
}

# ── 핵심 종목 (30개) ─────────────────────────────────────────
US_STOCKS = {
    # 빅테크
    "AAPL":  "애플",
    "MSFT":  "마이크로소프트",
    "NVDA":  "엔비디아",
    "AMZN":  "아마존",
    "GOOGL": "구글",
    "META":  "메타",
    "TSLA":  "테슬라",
    # 반도체
    "AMD":   "AMD",
    "INTC":  "인텔",
    "QCOM":  "퀄컴",
    "AVGO":  "브로드컴",
    "MU":    "마이크론",
    # 금융
    "JPM":   "JP모건",
    "BAC":   "뱅크오브아메리카",
    "GS":    "골드만삭스",
    # 바이오/헬스
    "JNJ":   "존슨앤존슨",
    "LLY":   "일라이릴리",
    "UNH":   "유나이티드헬스",
    # 소비재
    "AMZN":  "아마존",
    "WMT":   "월마트",
    "COST":  "코스트코",
    # ETF (지수추종)
    "SPY":   "S&P500 ETF",
    "QQQ":   "나스닥100 ETF",
    "SOXS":  "반도체 인버스",
    "SOXX":  "반도체 ETF",
    # 경기사이클
    "XOM":   "엑슨모빌",
    "CAT":   "캐터필러",
    "BA":    "보잉",
    "DIS":   "디즈니",
    "NFLX":  "넷플릭스",
}


def _safe_pct(cur, prev) -> float:
    """안전한 등락률 계산"""
    try:
        if prev and prev != 0:
            return round((cur - prev) / prev * 100, 2)
    except Exception:
        pass
    return 0.0


def _calc_rsi(series: "pd.Series", period: int = 14) -> float:
    """RSI 계산"""
    try:
        delta = series.diff()
        gain  = delta.clip(lower=0).rolling(period).mean()
        loss  = (-delta.clip(upper=0)).rolling(period).mean()
        rs    = gain / loss
        rsi   = 100 - (100 / (1 + rs))
        return round(float(rsi.iloc[-1]), 1)
    except Exception:
        return 50.0


def _calc_macd_signal(series: "pd.Series") -> str:
    """MACD 골든/데드크로스 판단"""
    try:
        ema12 = series.ewm(span=12).mean()
        ema26 = series.ewm(span=26).mean()
        macd  = ema12 - ema26
        sig   = macd.ewm(span=9).mean()
        if macd.iloc[-1] > sig.iloc[-1] and macd.iloc[-2] <= sig.iloc[-2]:
            return "골든크로스"
        elif macd.iloc[-1] < sig.iloc[-1] and macd.iloc[-2] >= sig.iloc[-2]:
            return "데드크로스"
        elif macd.iloc[-1] > sig.iloc[-1]:
            return "상승"
        else:
            return "하락"
    except Exception:
        return "—"


def _score_stock(hist: "pd.DataFrame") -> dict:
    """
    종목 기술적 분석 → 점수(0~100) 및 신호 반환
    """
    try:
        c = hist["Close"]
        v = hist["Volume"]

        cur   = float(c.iloc[-1])
        prev  = float(c.iloc[-2])
        pct   = _safe_pct(cur, prev)

        ma5   = float(c.rolling(5).mean().iloc[-1])
        ma20  = float(c.rolling(20).mean().iloc[-1])
        ma60  = float(c.rolling(60).mean().iloc[-1]) if len(c) >= 60 else ma20
        rsi   = _calc_rsi(c)
        macd  = _calc_macd_signal(c)

        # 52주 최고/최저
        high52 = float(c.tail(252).max()) if len(c) >= 252 else float(c.max())
        low52  = float(c.tail(252).min()) if len(c) >= 252 else float(c.min())
        from_high = _safe_pct(cur, high52)
        from_low  = _safe_pct(cur, low52)

        # 거래량 비율 (5일 평균 대비)
        vol_ratio = float(v.iloc[-1] / v.rolling(5).mean().iloc[-1]) if v.rolling(5).mean().iloc[-1] > 0 else 1.0

        # 점수 계산 (0~100)
        score = 50.0
        if cur > ma5:   score += 5
        if cur > ma20:  score += 10
        if cur > ma60:  score += 10
        if ma5  > ma20: score += 8
        if ma20 > ma60: score += 7
        if rsi < 30:    score += 15   # 과매도 — 반등 기대
        elif rsi < 50:  score += 5
        elif rsi > 70:  score -= 10   # 과매수
        if "골든" in macd: score += 10
        if "데드" in macd: score -= 10
        if vol_ratio > 1.5 and pct > 0: score += 5   # 거래량 급증 + 상승
        if from_high > -5:  score += 5   # 52주 고점 근접

        score = max(0.0, min(100.0, score))

        # 신호 판정
        if score >= 70:
            signal = "BUY"
        elif score <= 35:
            signal = "SELL"
        else:
            signal = "HOLD"

        return {
            "cur_price":  round(cur, 2),
            "pct_1d":     pct,
            "ma5":        round(ma5, 2),
            "ma20":       round(ma20, 2),
            "ma60":       round(ma60, 2),
            "rsi":        rsi,
            "macd":       macd,
            "from_high52":round(from_high, 1),
            "vol_ratio":  round(vol_ratio, 2),
            "score":      round(score, 1),
            "signal":     signal,
        }
    except Exception as e:
        logger.warning(f"종목 분석 실패: {e}")
        return {"score": 50.0, "signal": "HOLD", "pct_1d": 0.0}


def _detect_us_regime(sp500_pct: float, vix: float, nasdaq_pct: float) -> str:
    """
    미국 시장 국면 판단
      BULL:    S&P500 상승 + VIX 낮음
      BEAR:    S&P500 하락 + VIX 높음
      LATERAL: 그 외
    """
    if vix >= 30:
        return "BEAR"
    elif sp500_pct >= 0.3 and vix < 20:
        return "BULL"
    elif sp500_pct <= -0.5:
        return "BEAR"
    else:
        return "LATERAL"


def _korea_impact(us_regime: str, sp500_pct: float, nasdaq_pct: float, vix: float) -> dict:
    """
    미국 증시 → 내일 한국 시장 예측
    """
    if us_regime == "BULL":
        direction = "상승 예상"
        emoji     = "🟢"
        reason    = f"S&P500 {sp500_pct:+.2f}%, VIX {vix:.1f} (안정) → 코스피 동반 상승 기대"
        kospi_est = round(sp500_pct * 0.7, 2)   # 미국 대비 70% 연동
    elif us_regime == "BEAR":
        direction = "하락 예상"
        emoji     = "🔴"
        reason    = f"S&P500 {sp500_pct:+.2f}%, VIX {vix:.1f} (공포) → 코스피 동반 하락 주의"
        kospi_est = round(sp500_pct * 0.8, 2)
    else:
        direction = "보합/혼조"
        emoji     = "🟡"
        reason    = f"S&P500 {sp500_pct:+.2f}%, 방향성 불명확 → 관망 유효"
        kospi_est = round(sp500_pct * 0.5, 2)

    # 반도체 비중 높은 한국 시장은 나스닥 영향도 큼
    semicon_note = ""
    if nasdaq_pct >= 1.0:
        semicon_note = "💡 나스닥 강세 → 삼성전자·SK하이닉스 수혜 가능"
    elif nasdaq_pct <= -1.0:
        semicon_note = "⚠️ 나스닥 약세 → 반도체주 하락 압력 주의"

    return {
        "direction":   direction,
        "emoji":       emoji,
        "reason":      reason,
        "kospi_est":   kospi_est,
        "semicon_note": semicon_note,
    }


def run_us_screening() -> dict:
    """
    미국 증시 전체 분석 실행
    Returns: 분석 결과 dict (파일 저장 + 반환)
    """
    if not HAS_YFINANCE:
        logger.error("yfinance 미설치 — pip install yfinance")
        return {"error": "yfinance 미설치"}

    logger.info("🇺🇸 미국 증시 야간 분석 시작...")
    now_kst = datetime.now(KST).strftime("%Y-%m-%d %H:%M KST")
    result = {
        "analyzed_at": now_kst,
        "date":        date.today().isoformat(),
        "indices":     {},
        "sectors":     {},
        "stocks":      {},
        "regime":      "LATERAL",
        "korea_impact": {},
        "top_buy":     [],
        "summary":     {},
    }

    # ── 1. 주요 지수 ───────────────────────────────────────
    sp500_pct = 0.0
    nasdaq_pct = 0.0
    vix_val = 20.0

    for sym, meta in US_INDICES.items():
        try:
            hist = yf.Ticker(sym).history(period="5d")
            if hist.empty or len(hist) < 2:
                continue
            cur  = float(hist["Close"].iloc[-1])
            prev = float(hist["Close"].iloc[-2])
            pct  = _safe_pct(cur, prev)

            result["indices"][sym] = {
                "name":    meta["name"],
                "emoji":   meta["emoji"],
                "price":   round(cur, 2),
                "pct_1d":  pct,
            }
            if sym == "^GSPC":  sp500_pct  = pct
            if sym == "^IXIC":  nasdaq_pct = pct
            if sym == "^VIX":   vix_val    = cur
        except Exception as e:
            logger.warning(f"지수 {sym} 조회 실패: {e}")

    # ── 2. 섹터 분석 ───────────────────────────────────────
    sector_results = []
    for sym, name in US_SECTORS.items():
        try:
            hist = yf.Ticker(sym).history(period="30d")
            if hist.empty or len(hist) < 5:
                continue
            c   = hist["Close"]
            cur  = float(c.iloc[-1])
            prev = float(c.iloc[-2])
            pct  = _safe_pct(cur, prev)
            pct5d = _safe_pct(cur, float(c.iloc[-5])) if len(c) >= 5 else pct

            entry = {
                "symbol":  sym,
                "name":    name,
                "price":   round(cur, 2),
                "pct_1d":  pct,
                "pct_5d":  pct5d,
            }
            result["sectors"][sym] = entry
            sector_results.append(entry)
        except Exception as e:
            logger.warning(f"섹터 {sym} 조회 실패: {e}")

    # 섹터 강도 순위 (1일 등락률 기준)
    sector_results.sort(key=lambda x: x["pct_1d"], reverse=True)

    # ── 3. 핵심 종목 분석 ──────────────────────────────────
    buy_candidates = []
    for sym, name in US_STOCKS.items():
        try:
            hist = yf.Ticker(sym).history(period="90d")
            if hist.empty or len(hist) < 20:
                continue
            analysis = _score_stock(hist)
            analysis["symbol"] = sym
            analysis["name"]   = name
            result["stocks"][sym] = analysis

            if analysis["signal"] == "BUY":
                buy_candidates.append(analysis)
        except Exception as e:
            logger.warning(f"종목 {sym}({name}) 분석 실패: {e}")

    # TOP10 매수 후보 (점수 높은 순)
    buy_candidates.sort(key=lambda x: x["score"], reverse=True)
    result["top_buy"] = buy_candidates[:10]

    # ── 4. 시장 국면 판단 ──────────────────────────────────
    regime = _detect_us_regime(sp500_pct, vix_val, nasdaq_pct)
    result["regime"] = regime

    # ── 5. 한국 시장 영향 ──────────────────────────────────
    result["korea_impact"] = _korea_impact(regime, sp500_pct, nasdaq_pct, vix_val)

    # ── 6. 요약 ────────────────────────────────────────────
    bull_sectors  = [s for s in sector_results if s["pct_1d"] > 0]
    bear_sectors  = [s for s in sector_results if s["pct_1d"] < 0]
    result["summary"] = {
        "regime":           regime,
        "sp500_pct":        sp500_pct,
        "nasdaq_pct":       nasdaq_pct,
        "vix":              round(vix_val, 2),
        "bull_sectors":     len(bull_sectors),
        "bear_sectors":     len(bear_sectors),
        "top_sector":       sector_results[0]["name"] if sector_results else "—",
        "worst_sector":     sector_results[-1]["name"] if sector_results else "—",
        "buy_candidates":   len(buy_candidates),
        "analyzed_at":      now_kst,
    }

    # ── 파일 저장 ───────────────────────────────────────────
    os.makedirs(os.path.dirname(US_RESULT_FILE), exist_ok=True)
    with open(US_RESULT_FILE, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    logger.info(
        f"✅ 미국 분석 완료 — 국면:{regime} | S&P500:{sp500_pct:+.2f}% | "
        f"VIX:{vix_val:.1f} | 매수후보:{len(buy_candidates)}개"
    )
    return result


def load_us_result() -> dict:
    """저장된 미국 분석 결과 로드"""
    try:
        if os.path.exists(US_RESULT_FILE):
            with open(US_RESULT_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception as e:
        logger.warning(f"미국 분석 결과 로드 실패: {e}")
    return {}


if __name__ == "__main__":
    result = run_us_screening()
    print(json.dumps(result["summary"], ensure_ascii=False, indent=2))
    print("\n🔺 매수 TOP5:")
    for s in result["top_buy"][:5]:
        print(f"  {s['name']}({s['symbol']}): ${s['cur_price']} | 점수:{s['score']} | RSI:{s['rsi']}")
