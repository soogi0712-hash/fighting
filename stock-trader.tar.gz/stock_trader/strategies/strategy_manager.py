"""
통합 전략 매니저
=================

★ 장기 복리수익률 극대화 설계 철학 ★

  우선순위:
    1. 계좌 생존     — 일손실/전체손실 한도 초과 시 즉시 매수 중단
    2. 손실 제한     — 손절은 지표 검증 없이 즉시 실행; 손절금 즉시 재배분
    3. 강한 종목 집중 — trend_score 높은 종목에 자금 우선 투입
    4. 복리 성장     — 실질 수익 중인 종목만 피라미딩 추가
    5. 수익률 극대화  — 추세 유지되는 한 홀드; MA20이탈·트레일링에만 청산

  핵심 흐름:
    1. 세션 확인 (휴장 → 스킵)
    2. OHLCV + 현재가 수집
    3. IndicatorValidator.validate() → score(0~6) + trend_score(0~100)
    4. PyramidStrategyManager.evaluate() → action 판단
    5. 세션별 score_cutoff 검사 (BUY 계열)
    6. SELL 계열:
       - is_forced(손절/트레일링) → 즉시 실행
       - 일반 매도 → sell_score ≥ 2 확인
    7. 손절 체결 시:
       - 회수금 + trend_score 기반 prioritize_reallocation() 호출
       - 재배분 대상 종목에 즉시 추가매수 시도 (복리 성장)

★ 비용 원칙 ★
  - avg_price = 수수료 포함 주당 취득원가
  - 모든 % 판단 = 실질수익률 (net_profit_pct_from_cost)
  - 복리풀 = 실질 순이익(수수료·세금 차감 후)만 적립
"""

import json
import os
import time
from datetime import datetime
from utils.logger import get_logger
from utils.market_session import session_info, is_tradeable
from config import Config
from strategies.pyramid_strategy   import PyramidStrategyManager
from strategies.indicator_validator import IndicatorValidator
from screener.trade_decision        import TradeDecisionEngine
from screener.transaction_cost      import net_profit_pct_from_cost

logger = get_logger("StrategyManager")

TRADE_LOG_FILE = os.path.join(
    os.path.dirname(__file__), "..", "data", "trade_log.json"
)


class StrategyManager:

    def __init__(self, kis_api):
        self.api        = kis_api
        self.validator  = IndicatorValidator()
        self.decision   = TradeDecisionEngine()
        self.pyramid    = PyramidStrategyManager(
            kis_api,
            max_per_stock=Config.MAX_INVESTMENT_PER_STOCK,
            max_total    =Config.MAX_TOTAL_INVESTMENT,
        )
        os.makedirs(os.path.dirname(TRADE_LOG_FILE), exist_ok=True)

    # ── 하위 호환: app.py 에서 positions 접근 ──────────────
    @property
    def positions(self) -> dict:
        return {code: pos.to_dict()
                for code, pos in self.pyramid.positions.items()}

    # ══════════════════════════════════════════════════════════
    # 메인 실행
    # ══════════════════════════════════════════════════════════
    def run(self, stock: dict) -> dict:
        """
        단일 종목에 대한 매매 판단 + 실행.

        Args:
            stock: {code, name, [score_result: AIScorer.score() 반환값]}

        Returns:
            {action, code, name, ...}
        """
        code = stock["code"]
        name = stock["name"]
        sess = session_info()

        # 1) 휴장
        if not sess["tradeable"]:
            return {"action": "SKIP",
                    "reason": f"휴장({sess['session']})",
                    "session": sess["session"]}

        # 2) OHLCV + 현재가
        candles   = self.api.get_ohlcv(code, period="D", count=200)
        if not candles:
            return {"action": "SKIP", "reason": "OHLCV 없음",
                    "session": sess["session"]}

        cur_data  = self.api.get_current_price(code)
        cur_price = float(cur_data.get("price", 0) or candles[-1]["close"])

        # 3) 보조지표 + 추세강도 검증
        iv         = self.validator.validate(candles)
        ind_score  = iv["score"]        # 매수 신호 지표 수 (0~6)
        sell_score = iv["sell_score"]   # 매도 신호 지표 수 (0~6)
        trend_score= iv["trend_score"]  # ★ 추세강도 점수 (0~100)
        strong_trend= iv["strong_trend"] # ★ True if trend_score ≥ 60

        # score_result 에 trend_score 합산 (재배분·집중도 결정에 사용)
        score_result = stock.get("score_result", {})
        score_result.update({
            "cur_price":   cur_price,
            "price_ma20":  iv["detail"].get("MA", {}).get("value", {}).get("MA20", 0),
            "trend_score": trend_score,
            "strong_trend":strong_trend,
        })

        # 4) 피라미딩 전략 판단 (실질수익률 기준)
        balance   = self.api.get_balance()
        cash      = float(balance.get("cash", 0))
        decision  = self.pyramid.evaluate(code, name, cur_price, ind_score, cash)
        action    = decision.get("action", "HOLD")

        # ── 세션별 BUY 지표 기준 ──────────────────────────
        cutoff_map = {
            "장전시간외": 3, "정규장시작": 3,
            "정규장":     2, "정규장마감": 4,
            "장후시간외": 3,
        }
        ind_cutoff = cutoff_map.get(sess["session"], 2)

        # ★ 강한 추세 종목은 진입 기준 1단계 완화
        if strong_trend and ind_cutoff > 1:
            ind_cutoff -= 1

        logger.info(
            f"[{sess['icon']} {sess['session']}] {name} "
            f"지표BUY={ind_score}/6 SELL={sell_score}/6 "
            f"추세={trend_score:.0f}/100{'★' if strong_trend else ''} "
            f"cutoff≥{ind_cutoff} | action={action}"
        )

        # ── BUY 계열 ──────────────────────────────────────
        if action.startswith("BUY"):
            level = decision["level"]

            # 지표 부족 → 홀드
            if ind_score < ind_cutoff:
                return {
                    "action":      "HOLD",
                    "code":        code, "name": name,
                    "price":       cur_price,
                    "ind_score":   ind_score,
                    "ind_cutoff":  ind_cutoff,
                    "trend_score": trend_score,
                    "session":     sess["session"],
                    "reason":      (f"지표 부족({ind_score}/{ind_cutoff}) — "
                                    f"{decision['reason']}"),
                    "indicators":  iv,
                }

            # 마감 직전 신규 1단계 진입 억제
            if sess["session"] == "정규장마감" and level == 1:
                return {"action": "HOLD", "code": code, "name": name,
                        "reason": "마감전 신규진입 억제",
                        "session": sess["session"]}

            qty      = decision["qty"]
            price    = decision["price"]
            ord_dvsn = sess["order_dvsn"]
            use_price= price if ord_dvsn in ("05", "06") else 0

            result = self.api.buy(code, qty, use_price, ord_dvsn=ord_dvsn)

            # ── 주문 성공 여부 판단 ──────────────────────────
            # rt_cd=="0" : 명확한 성공
            # 그 외(500 등) : KIS 서버 에러지만 실제 체결됐을 수 있음
            #   → 3초 대기 후 잔고 재조회, 보유 확인되면 포지션 자동 등록
            order_ok = result.get("rt_cd") == "0"

            if not order_ok:
                logger.warning(
                    f"⚠️ {code} 주문 응답 이상({result.get('msg1','?')}) "
                    f"— 3초 후 잔고 재확인..."
                )
                time.sleep(3)
                try:
                    balance = self.api.get_balance()
                    holdings = {h["code"]: h for h in balance.get("holdings", [])}
                    if code in holdings:
                        h = holdings[code]
                        actual_qty   = int(h.get("qty", qty))
                        actual_price = float(h.get("avg_price", price))
                        logger.info(
                            f"✅ {code}({name}) 잔고 확인 → 실제 체결됨 "
                            f"{actual_qty}주 @{actual_price:,.0f}원 — 포지션 자동 등록"
                        )
                        # 이미 포지션에 없을 때만 등록 (중복 방지)
                        if code not in self.pyramid.positions:
                            self.pyramid.apply_buy(
                                code, name, level, actual_qty, actual_price,
                                using_compound=decision.get("using_compound", 0)
                            )
                            self._log_trade(
                                "BUY", code, name, actual_price, actual_qty,
                                decision["reason"] + " [잔고확인 자동등록]",
                                sess["session"],
                                extra={
                                    "level":         level,
                                    "ind_score":     ind_score,
                                    "trend_score":   trend_score,
                                    "compound_pool": self.pyramid.compound_pool,
                                }
                            )
                            return {
                                "action":        "BUY",
                                "code":          code, "name": name,
                                "price":         actual_price, "qty": actual_qty,
                                "level":         level,
                                "amount":        actual_price * actual_qty,
                                "ind_score":     ind_score,
                                "trend_score":   trend_score,
                                "strong_trend":  strong_trend,
                                "reason":        decision["reason"] + " [잔고확인 자동등록]",
                                "session":       sess["session"],
                                "order_label":   sess["order_label"],
                                "indicators":    iv,
                                "compound_pool": self.pyramid.compound_pool,
                            }
                        else:
                            logger.info(f"ℹ️ {code} 이미 포지션 존재 — 중복 등록 스킵")
                    else:
                        logger.warning(f"❌ {code} 잔고 재확인 결과 미보유 — 주문 실패 처리")
                except Exception as e2:
                    logger.error(f"잔고 재확인 실패 {code}: {e2}")
                return {"action": "BUY_FAIL", "code": code,
                        "reason": result.get("msg1"), "session": sess["session"]}

            # ── 명확한 성공(rt_cd==0) ────────────────────────
            if order_ok:
                self.pyramid.apply_buy(
                    code, name, level, qty, price,
                    using_compound=decision.get("using_compound", 0)
                )
                self._log_trade(
                    "BUY", code, name, price, qty,
                    decision["reason"], sess["session"],
                    extra={
                        "level":         level,
                        "ind_score":     ind_score,
                        "trend_score":   trend_score,
                        "compound_pool": self.pyramid.compound_pool,
                    }
                )
                return {
                    "action":        "BUY",
                    "code":          code, "name": name,
                    "price":         price, "qty": qty,
                    "level":         level,
                    "amount":        price * qty,
                    "ind_score":     ind_score,
                    "trend_score":   trend_score,
                    "strong_trend":  strong_trend,
                    "reason":        decision["reason"],
                    "session":       sess["session"],
                    "order_label":   sess["order_label"],
                    "indicators":    iv,
                    "compound_pool": self.pyramid.compound_pool,
                }
            return {"action": "BUY_FAIL", "code": code,
                    "reason": result.get("msg1"), "session": sess["session"]}

        # ── SELL 계열 ─────────────────────────────────────
        elif action in ("SELL_ALL", "SELL_PARTIAL"):
            qty      = decision["qty"]
            price    = decision["price"]
            is_full  = (action == "SELL_ALL")
            ord_dvsn = sess["order_dvsn"]
            use_price= price if ord_dvsn in ("05", "06") else 0
            level    = decision.get("level")
            reason   = decision["reason"]

            # ★ 손절/트레일링은 is_forced=True → 지표 우선순위 무시
            is_forced = (
                "손절" in reason
                or "트레일링" in reason
                or "마감"    in reason
            )

            if not is_forced and sell_score < 2:
                return {
                    "action":  "HOLD", "code": code, "name": name,
                    "reason":  f"매도지표 부족({sell_score}/2) — 홀드",
                    "session": sess["session"],
                }

            result = self.api.sell(code, qty, use_price, ord_dvsn=ord_dvsn)

            if result.get("rt_cd") == "0":
                profit = self.pyramid.apply_sell(
                    code, qty, price, level=level, is_full=is_full
                )
                net_pct = profit.get("net_profit_pct", 0.0)

                self._log_trade(
                    "SELL", code, name, price, qty,
                    reason, sess["session"],
                    extra={
                        "level":         level,
                        "profit":        profit,
                        "net_pct":       net_pct,
                        "is_forced":     is_forced,
                        "trend_score":   trend_score,
                        "compound_pool": self.pyramid.compound_pool,
                    }
                )

                sell_result = {
                    "action":        "SELL",
                    "code":          code, "name": name,
                    "price":         price, "qty": qty,
                    "profit":        profit,
                    "net_pct":       net_pct,
                    "is_full":       is_full,
                    "level":         level,
                    "reason":        reason,
                    "is_forced":     is_forced,
                    "session":       sess["session"],
                    "order_label":   sess["order_label"],
                    "compound_pool": self.pyramid.compound_pool,
                    "indicators":    iv,
                    "trend_score":   trend_score,
                }

                # ★ 손절 체결 후 즉시 재배분 시도
                # 손절(실질손실)이면 회수금을 강한 종목에 재투입
                if is_forced and "손절" in reason and is_full:
                    recycled = profit.get("net_proceeds", 0.0)
                    realloc  = self._try_recycle_to_strong(
                        recycled, sess, ind_score, ind_cutoff
                    )
                    sell_result["recycled_cash"]    = recycled
                    sell_result["realloc_attempted"] = realloc

                return sell_result

            return {"action": "SELL_FAIL", "code": code,
                    "reason": result.get("msg1"), "session": sess["session"]}

        # ── HOLD ──────────────────────────────────────────
        return {
            "action":        "HOLD",
            "code":          code, "name": name,
            "price":         cur_price,
            "ind_score":     ind_score,
            "sell_score":    sell_score,
            "ind_cutoff":    ind_cutoff,
            "trend_score":   trend_score,
            "strong_trend":  strong_trend,
            "session":       sess["session"],
            "reason":        decision.get("reason", "홀드"),
            "indicators":    iv,
            "compound_pool": self.pyramid.compound_pool,
            "pyramid_level": decision.get("level", 0),
        }

    # ══════════════════════════════════════════════════════════
    # ★ 손절 회수금 → 강한 종목 재배분
    # ══════════════════════════════════════════════════════════
    def _try_recycle_to_strong(self, recycled_cash: float,
                                sess: dict,
                                ind_score: int,
                                ind_cutoff: int) -> list[dict]:
        """
        손절 후 회수금을 현재 강한 종목에 즉시 재투입.

        1. 현재 보유 포지션 목록 + 현재가로 scored_positions 구성
        2. TradeDecisionEngine.prioritize_reallocation() 호출
        3. 상위 종목에 추가매수 시도 (ind_score ≥ ind_cutoff 조건 유지)
        """
        if recycled_cash <= 0:
            return []

        realloc_results = []

        # 현재 보유 포지션 정보 수집
        scored_positions = []
        for code, pos_dict in self.positions.items():
            try:
                cur_data  = self.api.get_current_price(code)
                cur_price = float(cur_data.get("price", 0))
                if not cur_price:
                    continue

                candles = self.api.get_ohlcv(code, period="D", count=200)
                iv_pos  = self.validator.validate(candles) if candles else {}
                ts      = iv_pos.get("trend_score", 0)
                ai      = pos_dict.get("entry_score", 0)
                rs      = pos_dict.get("rs_value", 0.0)

                net_pct = net_profit_pct_from_cost(
                    pos_dict.get("avg_price", 0), cur_price
                )

                scored_positions.append({
                    "code":        code,
                    "name":        pos_dict.get("name", code),
                    "avg_price":   pos_dict.get("avg_price", 0),
                    "cur_price":   cur_price,
                    "total_score": ai,
                    "rs_value":    rs,
                    "trend_score": ts,
                    "added_levels":pos_dict.get("added_levels", []),
                    "qty":         pos_dict.get("total_qty", 0),
                    "net_pct":     net_pct,
                })
            except Exception as e:
                logger.warning(f"재배분 포지션 조회 실패 {code}: {e}")

        if not scored_positions:
            logger.info("재배분 대상 포지션 없음")
            return []

        # 재배분 우선순위 결정
        targets = self.decision.prioritize_reallocation(
            scored_positions, recycled_cash
        )

        ord_dvsn = sess["order_dvsn"]

        for tgt in targets:
            code  = tgt["code"]
            alloc = tgt["alloc_amount"]
            if alloc <= 0:
                continue

            # 현재 포지션 재확인
            pos  = self.pyramid.get_position(code)
            if pos is None:
                continue

            # 지표 재확인 (추세가 강하면 기준 완화)
            candles = self.api.get_ohlcv(code, period="D", count=200)
            if not candles:
                continue
            iv2 = self.validator.validate(candles)
            if iv2.get("score", 0) < ind_cutoff:
                logger.info(
                    f"재배분 스킵 {tgt['name']}: "
                    f"지표부족 {iv2.get('score',0)}/{ind_cutoff}"
                )
                continue

            # 현재가
            cur_data  = self.api.get_current_price(code)
            cur_price = float(cur_data.get("price", 0))
            if not cur_price:
                continue

            # 추가매수 가능 레벨 확인
            balance = self.api.get_balance()
            cash    = float(balance.get("cash", 0))
            add_dec = self.pyramid.evaluate(
                code, tgt["name"], cur_price,
                iv2.get("score", 0), min(cash, alloc)
            )

            if add_dec.get("action", "").startswith("BUY"):
                qty       = add_dec["qty"]
                use_price = cur_price if ord_dvsn in ("05", "06") else 0
                res       = self.api.buy(
                    code, qty, use_price, ord_dvsn=ord_dvsn
                )
                if res.get("rt_cd") == "0":
                    self.pyramid.apply_buy(
                        code, tgt["name"],
                        add_dec["level"], qty, cur_price,
                        using_compound=add_dec.get("using_compound", 0)
                    )
                    self._log_trade(
                        "ADD_BUY", code, tgt["name"],
                        cur_price, qty,
                        f"손절재배분→{tgt['reason']}",
                        sess["session"],
                        extra={
                            "recycled_cash":  recycled_cash,
                            "alloc_amount":   alloc,
                            "trend_score":    tgt["trend_score"],
                            "compound_pool":  self.pyramid.compound_pool,
                        }
                    )
                    realloc_results.append({
                        "code":    code,
                        "name":    tgt["name"],
                        "qty":     qty,
                        "price":   cur_price,
                        "alloc":   alloc,
                        "status":  "OK",
                    })
                    logger.info(
                        f"♻️ 손절재배분 완료: {tgt['name']} {qty}주 "
                        f"@{cur_price:,}원 (배분={alloc:,.0f}원)"
                    )
                else:
                    realloc_results.append({
                        "code":   code,
                        "name":   tgt["name"],
                        "status": "FAIL",
                        "reason": res.get("msg1"),
                    })
            else:
                logger.info(
                    f"재배분 스킵 {tgt['name']}: "
                    f"피라미딩 판단={add_dec.get('action')} "
                    f"({add_dec.get('reason','')})"
                )

        return realloc_results

    # ── 거래 로그 ──────────────────────────────────────────
    def _log_trade(self, action, code, name, price, qty,
                   reason, session, extra=None):
        entry = {
            "timestamp": datetime.now().isoformat(),
            "action": action, "session": session,
            "code": code, "name": name,
            "price": price, "qty": qty,
            "amount": price * qty, "reason": reason,
        }
        if extra:
            entry.update(extra)
        try:
            logs = []
            if os.path.exists(TRADE_LOG_FILE):
                with open(TRADE_LOG_FILE) as f:
                    logs = json.load(f)
            logs.append(entry)
            with open(TRADE_LOG_FILE, "w") as f:
                json.dump(logs, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"거래로그 오류: {e}")

    def get_trade_history(self, limit=50) -> list:
        try:
            if os.path.exists(TRADE_LOG_FILE):
                with open(TRADE_LOG_FILE) as f:
                    return list(reversed(json.load(f)))[:limit]
        except Exception:
            pass
        return []
