"""
해외주식 전략 매니저 (미국 주식 전용)
========================================

★ 설계 철학:
  - 국내주식과 독립적으로 동작 (별도 포지션 관리)
  - yfinance 데이터 → 장중엔 KIS API 현재가로 보완
  - 피라미딩 1~4단계 (국내와 동일 구조)
  - 손절 -10% / 트레일링스탑 -15%
  - 미국 정규장(ET 09:30~16:00) 시간에만 매매

★ 지표:
  - MA(5/20/60) 정배열
  - RSI(14) 과매도 반등
  - MACD 골든크로스
  - 볼린저밴드 하단 이탈 후 회복
  - 거래량 급증 (5일평균 1.5배 이상)
  - 추세강도 (ADX 기반)

★ 포지션 파일: data/us_positions.json
"""

import os
import json
import time
import numpy as np
from datetime import datetime
from utils.logger        import get_logger
from utils.market_session import us_session_info, is_us_tradeable
from screener.transaction_cost import calc_buy_qty

logger = get_logger("USStrategyManager")

US_POSITIONS_FILE = os.path.join(
    os.path.dirname(__file__), "..", "data", "us_positions.json"
)

# ── 피라미딩 레벨 설정 (국내와 동일 구조) ─────────────────────
PYRAMID_LEVELS = {
    1: {"invest_ratio": 0.25},   # 총투자금의 25%
    2: {"invest_ratio": 0.25},   # +10% 수익 시 추가
    3: {"invest_ratio": 0.25},   # +20% 수익 시 추가
    4: {"invest_ratio": 0.25},   # +35% 수익 시 추가
}

# ── 기본 종목 리스트 (티커: {이름, 거래소}) ───────────────────
DEFAULT_US_WATCHLIST = {
    "NVDA":  {"name": "엔비디아",          "excd": "NASD"},
    "AAPL":  {"name": "애플",              "excd": "NASD"},
    "MSFT":  {"name": "마이크로소프트",     "excd": "NASD"},
    "TSLA":  {"name": "테슬라",            "excd": "NASD"},
    "AMZN":  {"name": "아마존",            "excd": "NASD"},
    "META":  {"name": "메타",              "excd": "NASD"},
    "GOOGL": {"name": "구글",              "excd": "NASD"},
    "AMD":   {"name": "AMD",              "excd": "NASD"},
    "SOXX":  {"name": "반도체ETF(SOXX)",   "excd": "NASD"},
    "QQQ":   {"name": "나스닥100ETF(QQQ)", "excd": "NASD"},
}

STOP_LOSS_PCT      = 10.0    # 손절 -10%
TRAILING_STOP_PCT  = 15.0   # 트레일링 스탑 -15%
TRAILING_ACT_PCT   =  5.0   # 트레일링 활성화 수익률 +5%
ADD_BUY_PCT_1      = 10.0   # 1차 추가매수 조건 수익률
ADD_BUY_PCT_2      = 20.0
ADD_BUY_PCT_3      = 35.0


# ══════════════════════════════════════════════════════════════
# 보조지표 계산 (yfinance 없이 순수 numpy)
# ══════════════════════════════════════════════════════════════

def _calc_indicators(candles: list[dict]) -> dict:
    """
    OHLCV 캔들 리스트 → 지표 점수 계산
    Returns: {score, sell_score, trend_score, strong_trend, detail}
    """
    if len(candles) < 20:
        return {"score": 0, "sell_score": 0, "trend_score": 0, "strong_trend": False, "detail": {}}

    closes  = np.array([c["close"]  for c in candles], dtype=float)
    volumes = np.array([c["volume"] for c in candles], dtype=float)
    highs   = np.array([c["high"]   for c in candles], dtype=float)
    lows    = np.array([c["low"]    for c in candles], dtype=float)

    cur = closes[-1]

    # ── MA ────────────────────────────────────────────────────
    ma5  = float(np.mean(closes[-5:]))
    ma20 = float(np.mean(closes[-20:]))
    ma60 = float(np.mean(closes[-60:])) if len(closes) >= 60 else ma20
    ma_buy  = cur > ma5 > ma20
    ma_sell = cur < ma5 < ma20
    ma_detail = {"MA5": round(ma5, 2), "MA20": round(ma20, 2), "MA60": round(ma60, 2)}

    # ── RSI ───────────────────────────────────────────────────
    delta = np.diff(closes)
    gain  = np.where(delta > 0, delta, 0)
    loss  = np.where(delta < 0, -delta, 0)
    avg_g = np.mean(gain[-14:])
    avg_l = np.mean(loss[-14:])
    rsi   = 100 - (100 / (1 + avg_g / avg_l)) if avg_l != 0 else 50.0
    rsi_buy  = rsi < 45    # 과매도 → 반등 기대
    rsi_sell = rsi > 75    # 과매수 → 조정 주의

    # ── MACD ──────────────────────────────────────────────────
    def ema(arr, span):
        k = 2 / (span + 1)
        result = [arr[0]]
        for v in arr[1:]:
            result.append(result[-1] * (1 - k) + v * k)
        return np.array(result)

    ema12   = ema(closes, 12)
    ema26   = ema(closes, 26)
    macd    = ema12 - ema26
    sig     = ema(macd, 9)
    macd_buy  = macd[-1] > sig[-1] and macd[-2] <= sig[-2]   # 골든크로스
    macd_sell = macd[-1] < sig[-1] and macd[-2] >= sig[-2]   # 데드크로스
    macd_above = macd[-1] > sig[-1]   # 골든크로스 이후 유지

    # ── 볼린저밴드 ─────────────────────────────────────────────
    bb_mid  = ma20
    bb_std  = float(np.std(closes[-20:]))
    bb_up   = bb_mid + 2 * bb_std
    bb_low  = bb_mid - 2 * bb_std
    bb_buy  = cur > bb_low and closes[-2] <= bb_low   # 하단 이탈 후 회복
    bb_sell = cur > bb_up                              # 상단 돌파 (과열)
    bb_detail = {"upper": round(bb_up, 2), "mid": round(bb_mid, 2), "lower": round(bb_low, 2)}

    # ── OBV ───────────────────────────────────────────────────
    obv = np.zeros(len(closes))
    for i in range(1, len(closes)):
        obv[i] = obv[i-1] + (volumes[i] if closes[i] > closes[i-1] else -volumes[i] if closes[i] < closes[i-1] else 0)
    obv_ma5  = float(np.mean(obv[-5:]))
    obv_ma20 = float(np.mean(obv[-20:]))
    obv_buy  = obv_ma5 > obv_ma20
    obv_sell = obv_ma5 < obv_ma20

    # ── 거래량 급증 ────────────────────────────────────────────
    vol_avg5  = float(np.mean(volumes[-6:-1])) if len(volumes) >= 6 else float(volumes[-1])
    vol_ratio = float(volumes[-1]) / vol_avg5 if vol_avg5 > 0 else 1.0
    vol_buy   = vol_ratio >= 1.5 and closes[-1] > closes[-2]

    # ── 추세강도 (ADX 간소화) ──────────────────────────────────
    ret20  = float((closes[-1] - closes[-21]) / closes[-21] * 100) if len(closes) >= 21 else 0.0
    ret5   = float((closes[-1] - closes[-6])  / closes[-6]  * 100) if len(closes) >= 6  else 0.0
    high20 = float(np.max(highs[-20:]))
    near20 = float(closes[-1] / high20 * 100) if high20 > 0 else 50.0

    # 추세강도 점수 (0~100)
    trend_score = 0.0
    trend_score += min(25.0, max(0.0, ret20 * 1.5))    # 20일 수익률
    trend_score += min(25.0, max(0.0, ret5  * 5.0))    # 5일 모멘텀
    trend_score += 25.0 if ma5 > ma20 > ma60 else 0.0  # 정배열
    trend_score += max(0.0, (near20 - 80) * 2.5)       # 고점 근접도
    trend_score  = min(100.0, trend_score)
    strong_trend = trend_score >= 60

    # ── 점수 집계 ─────────────────────────────────────────────
    buy_signals  = {"MA": ma_buy, "RSI": rsi_buy, "MACD": macd_buy or macd_above,
                    "BB": bb_buy, "OBV": obv_buy, "VOL": vol_buy}
    sell_signals = {"MA": ma_sell, "RSI": rsi_sell, "MACD": macd_sell,
                    "BB": bb_sell, "OBV": obv_sell}

    score      = sum(1 for v in buy_signals.values()  if v)
    sell_score = sum(1 for v in sell_signals.values() if v)

    return {
        "score":        score,
        "sell_score":   sell_score,
        "trend_score":  round(trend_score, 1),
        "strong_trend": strong_trend,
        "rsi":          round(float(rsi), 1),
        "macd":         round(float(macd[-1]), 4),
        "ma5":          round(ma5, 2),
        "ma20":         round(ma20, 2),
        "ma60":         round(ma60, 2),
        "vol_ratio":    round(vol_ratio, 2),
        "ret20":        round(ret20, 1),
        "detail": {
            "MA":   {"signal": "BUY" if ma_buy else ("SELL" if ma_sell else "HOLD"),
                     "value": ma_detail},
            "RSI":  {"signal": "BUY" if rsi_buy else ("SELL" if rsi_sell else "HOLD"),
                     "value": {"RSI": round(float(rsi), 1)}},
            "MACD": {"signal": "BUY" if (macd_buy or macd_above) else ("SELL" if macd_sell else "HOLD"),
                     "value": {"MACD": round(float(macd[-1]), 4), "Signal": round(float(sig[-1]), 4)}},
            "BB":   {"signal": "BUY" if bb_buy else ("SELL" if bb_sell else "HOLD"),
                     "value": bb_detail},
            "OBV":  {"signal": "BUY" if obv_buy else ("SELL" if obv_sell else "HOLD"),
                     "value": {"OBV_MA5": round(obv_ma5, 0), "OBV_MA20": round(obv_ma20, 0)}},
            "VOL":  {"signal": "BUY" if vol_buy else "HOLD",
                     "value": {"vol_ratio": round(vol_ratio, 2)}},
        },
    }


# ══════════════════════════════════════════════════════════════
# 포지션 관리
# ══════════════════════════════════════════════════════════════

class USPosition:
    """해외주식 단일 종목 포지션"""

    def __init__(self, symbol: str, name: str, excd: str,
                 qty: int, avg_price: float):
        self.symbol    = symbol
        self.name      = name
        self.excd      = excd
        self.qty       = qty
        self.avg_price = avg_price          # USD
        self.highest_price = avg_price      # 트레일링용 고점
        self.current_level = 1
        self.created_at    = datetime.now().isoformat()

    def update_high(self, cur_price: float):
        if cur_price > self.highest_price:
            self.highest_price = cur_price

    def net_pct(self, cur_price: float) -> float:
        """실질 수익률 % (수수료 ~0.25% 포함)"""
        if self.avg_price <= 0:
            return 0.0
        gross = (cur_price - self.avg_price) / self.avg_price * 100
        return round(gross - 0.25, 2)   # 미국주식 수수료 약 0.25%

    def to_dict(self) -> dict:
        return {
            "symbol":        self.symbol,
            "name":          self.name,
            "excd":          self.excd,
            "qty":           self.qty,
            "avg_price":     self.avg_price,
            "highest_price": self.highest_price,
            "current_level": self.current_level,
            "created_at":    self.created_at,
            "is_overseas":   True,
        }


class USPositionManager:
    """해외주식 포지션 파일 영속 관리"""

    def __init__(self):
        self.positions: dict[str, USPosition] = {}
        os.makedirs(os.path.dirname(US_POSITIONS_FILE), exist_ok=True)
        self._load()

    def _load(self):
        try:
            if os.path.exists(US_POSITIONS_FILE):
                data = json.load(open(US_POSITIONS_FILE, encoding="utf-8"))
                for sym, d in data.items():
                    p = USPosition(sym, d["name"], d["excd"],
                                   d["qty"], d["avg_price"])
                    p.highest_price = d.get("highest_price", d["avg_price"])
                    p.current_level = d.get("current_level", 1)
                    p.created_at    = d.get("created_at", "")
                    self.positions[sym] = p
                logger.info(f"[US포지션] {len(self.positions)}개 로드")
        except Exception as e:
            logger.warning(f"[US포지션] 로드 실패: {e}")

    def save(self):
        try:
            data = {sym: p.to_dict() for sym, p in self.positions.items()}
            with open(US_POSITIONS_FILE, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"[US포지션] 저장 실패: {e}")

    def add(self, pos: USPosition):
        self.positions[pos.symbol] = pos
        self.save()

    def remove(self, symbol: str):
        self.positions.pop(symbol, None)
        self.save()

    def update(self, symbol: str, qty: int, avg_price: float, level: int):
        if symbol in self.positions:
            self.positions[symbol].qty         = qty
            self.positions[symbol].avg_price   = avg_price
            self.positions[symbol].current_level = level
            self.save()


# ══════════════════════════════════════════════════════════════
# 전략 매니저
# ══════════════════════════════════════════════════════════════

class USStrategyManager:
    """
    해외주식 전략 실행기.
    app.py 의 _trading_loop 에서 미국장 세션 중 호출됨.
    """

    def __init__(self, kis_api, max_total_usd: float = 5000.0):
        """
        kis_api     : KISApi 인스턴스
        max_total_usd : 해외주식 총 투자 한도 (USD)
        """
        self.api           = kis_api
        self.max_total_usd = max_total_usd
        self.pos_mgr       = USPositionManager()

    @property
    def positions(self) -> dict:
        return {sym: p.to_dict() for sym, p in self.pos_mgr.positions.items()}

    # ── 단일 종목 판단 ────────────────────────────────────────
    def run(self, stock: dict) -> dict:
        """
        Args:
            stock: {"symbol": "NVDA", "name": "엔비디아", "excd": "NASD"}
        Returns:
            {action, symbol, name, ...}
        """
        symbol = stock["symbol"]
        name   = stock.get("name", symbol)
        excd   = stock.get("excd", "NASD")
        sess   = us_session_info()

        # 1) 미국장 휴장 → 스킵
        if not sess["tradeable"]:
            return {"action": "SKIP", "symbol": symbol, "name": name,
                    "reason": f"미국 휴장({sess['session']})", "session": sess["session"]}

        # 2) OHLCV + 현재가
        candles = self.api.get_us_ohlcv(symbol, excd, count=120)
        if not candles or len(candles) < 20:
            return {"action": "SKIP", "symbol": symbol, "name": name,
                    "reason": "OHLCV 부족", "session": sess["session"]}

        price_data = self.api.get_us_current_price(symbol, excd)
        cur_price  = price_data.get("price", 0.0)
        if cur_price <= 0:
            cur_price = candles[-1]["close"]

        # 3) 지표 계산
        iv          = _calc_indicators(candles)
        ind_score   = iv["score"]
        sell_score  = iv["sell_score"]
        trend_score = iv["trend_score"]
        strong_trend = iv["strong_trend"]

        # cutoff: 정규장 중이면 3개 이상 (강추세면 2개)
        ind_cutoff = 2 if strong_trend else 3

        logger.info(
            f"[🇺🇸 {sess['session']}] {name}({symbol}) "
            f"BUY={ind_score}/6 SELL={sell_score}/6 "
            f"추세={trend_score:.0f}/100{'★' if strong_trend else ''} "
            f"cutoff≥{ind_cutoff} ${cur_price:.2f}"
        )

        pos = self.pos_mgr.positions.get(symbol)

        # ── 보유 중 → 손절/트레일링/추가매수 판단 ─────────────
        if pos:
            pos.update_high(cur_price)
            net_pct = pos.net_pct(cur_price)

            # 손절: -10%
            if net_pct <= -STOP_LOSS_PCT:
                return self._do_sell(symbol, name, excd, pos.qty, cur_price,
                                     f"손절 {net_pct:.1f}%", sess, is_full=True)

            # 트레일링스탑: 고점 대비 -15% & 활성화 기준 충족
            high_pct = (cur_price - pos.highest_price) / pos.highest_price * 100 \
                if pos.highest_price > 0 else 0.0
            from_high_pct = (pos.net_pct(pos.highest_price)
                             if pos.highest_price != pos.avg_price else 0.0)
            if from_high_pct >= TRAILING_ACT_PCT and high_pct <= -TRAILING_STOP_PCT:
                return self._do_sell(symbol, name, excd, pos.qty, cur_price,
                                     f"트레일링스탑 고점대비{high_pct:.1f}%", sess, is_full=True)

            # 매도 지표 충분 → 청산
            if sell_score >= 3 and not strong_trend:
                return self._do_sell(symbol, name, excd, pos.qty, cur_price,
                                     f"매도지표{sell_score}개", sess, is_full=True)

            # 피라미딩 추가매수
            add_lvl = self._next_add_level(pos, net_pct)
            if add_lvl and ind_score >= ind_cutoff:
                return self._do_add_buy(symbol, name, excd, pos,
                                        cur_price, add_lvl, sess, iv)

            return {
                "action":      "HOLD",
                "symbol":      symbol, "name": name,
                "price":       cur_price,
                "net_pct":     net_pct,
                "ind_score":   ind_score,
                "sell_score":  sell_score,
                "trend_score": trend_score,
                "session":     sess["session"],
                "reason":      f"피라미딩L{pos.current_level} 유지 ({net_pct:+.1f}%)",
                "indicators":  iv,
            }

        # ── 미보유 → 신규 진입 ────────────────────────────────
        if ind_score < ind_cutoff:
            return {
                "action":      "HOLD",
                "symbol":      symbol, "name": name,
                "price":       cur_price,
                "ind_score":   ind_score,
                "ind_cutoff":  ind_cutoff,
                "trend_score": trend_score,
                "session":     sess["session"],
                "reason":      f"지표 부족({ind_score}/{ind_cutoff})",
                "indicators":  iv,
            }

        return self._do_buy(symbol, name, excd, cur_price, 1, sess, iv)

    # ── 내부: 매수 실행 ──────────────────────────────────────
    def _do_buy(self, symbol, name, excd, cur_price, level, sess, iv) -> dict:
        """신규 1단계 매수"""
        # 투자금 계산: 총한도 / 4단계 → 단계당 25%
        invest_usd = self.max_total_usd * PYRAMID_LEVELS[level]["invest_ratio"]
        qty = max(1, int(invest_usd / cur_price))

        result = self.api.buy_us(symbol, qty, cur_price, excd)
        order_ok = result.get("rt_cd") == "0"

        if not order_ok:
            logger.warning(f"⚠️ {symbol} US 주문 이상 — 3초 후 잔고 재확인...")
            time.sleep(3)
            try:
                bal = self.api.get_us_balance()
                h_map = {h["symbol"]: h for h in bal.get("holdings", [])}
                if symbol in h_map:
                    h = h_map[symbol]
                    actual_qty   = int(h.get("qty", qty))
                    actual_price = float(h.get("avg_price", cur_price))
                    pos = USPosition(symbol, name, excd, actual_qty, actual_price)
                    pos.current_level = level
                    self.pos_mgr.add(pos)
                    logger.info(f"✅ {symbol} 잔고확인 자동등록 {actual_qty}주 ${actual_price:.2f}")
                    return self._buy_result(symbol, name, excd, actual_price,
                                            actual_qty, level, sess, iv, "[잔고확인]")
                else:
                    return {"action": "BUY_FAIL", "symbol": symbol, "name": name,
                            "reason": result.get("msg1"), "session": sess["session"]}
            except Exception as e2:
                logger.error(f"US 잔고재확인 실패 {symbol}: {e2}")
                return {"action": "BUY_FAIL", "symbol": symbol, "name": name,
                        "reason": str(e2), "session": sess["session"]}

        pos = USPosition(symbol, name, excd, qty, cur_price)
        pos.current_level = level
        self.pos_mgr.add(pos)
        return self._buy_result(symbol, name, excd, cur_price, qty, level, sess, iv, "")

    def _do_add_buy(self, symbol, name, excd, pos: USPosition,
                    cur_price, level, sess, iv) -> dict:
        """피라미딩 추가매수"""
        invest_usd = self.max_total_usd * PYRAMID_LEVELS[level]["invest_ratio"]
        add_qty    = max(1, int(invest_usd / cur_price))

        result = self.api.buy_us(symbol, add_qty, cur_price, excd)
        if result.get("rt_cd") != "0":
            return {"action": "BUY_FAIL", "symbol": symbol, "name": name,
                    "reason": result.get("msg1"), "session": sess["session"]}

        # 평균단가 재계산
        new_qty   = pos.qty + add_qty
        new_avg   = (pos.avg_price * pos.qty + cur_price * add_qty) / new_qty
        self.pos_mgr.update(symbol, new_qty, new_avg, level)

        logger.info(f"🟢 US 추가매수L{level} {symbol} {add_qty}주 ${cur_price:.2f}")
        return self._buy_result(symbol, name, excd, cur_price, add_qty, level, sess, iv,
                                f"[L{level}추가]")

    def _do_sell(self, symbol, name, excd, qty, cur_price, reason, sess,
                 is_full=True) -> dict:
        """매도 실행"""
        result = self.api.sell_us(symbol, qty, cur_price, excd)
        if result.get("rt_cd") == "0":
            pos     = self.pos_mgr.positions.get(symbol)
            avg_p   = pos.avg_price if pos else cur_price
            pnl_usd = (cur_price - avg_p) * qty
            pnl_pct = (cur_price - avg_p) / avg_p * 100 if avg_p > 0 else 0.0
            if is_full:
                self.pos_mgr.remove(symbol)
            logger.info(f"🔴 US 매도 {symbol} {qty}주 ${cur_price:.2f} | PnL ${pnl_usd:+.2f}")
            return {
                "action":    "SELL",
                "symbol":    symbol, "name": name, "excd": excd,
                "price":     cur_price, "qty": qty,
                "pnl_usd":   round(pnl_usd, 2),
                "pnl_pct":   round(pnl_pct, 2),
                "reason":    reason,
                "session":   sess["session"],
                "is_full":   is_full,
                "currency":  "USD",
            }
        return {"action": "SELL_FAIL", "symbol": symbol, "name": name,
                "reason": result.get("msg1"), "session": sess["session"]}

    # ── 추가매수 레벨 결정 ────────────────────────────────────
    def _next_add_level(self, pos: USPosition, net_pct: float):
        """다음 피라미딩 단계 반환. 없으면 None"""
        thresholds = {2: ADD_BUY_PCT_1, 3: ADD_BUY_PCT_2, 4: ADD_BUY_PCT_3}
        for lvl, thr in thresholds.items():
            if pos.current_level < lvl and net_pct >= thr:
                return lvl
        return None

    # ── 결과 딕셔너리 헬퍼 ───────────────────────────────────
    def _buy_result(self, symbol, name, excd, price, qty, level, sess, iv, tag) -> dict:
        return {
            "action":      "BUY",
            "symbol":      symbol, "name": name, "excd": excd,
            "price":       price,  "qty": qty,
            "amount_usd":  round(price * qty, 2),
            "level":       level,
            "ind_score":   iv["score"],
            "trend_score": iv["trend_score"],
            "reason":      f"US BUY_L{level} {tag}".strip(),
            "session":     sess["session"],
            "indicators":  iv,
            "currency":    "USD",
        }

    # ── 잔고 기반 포지션 자동 복원 ────────────────────────────
    def sync_from_balance(self):
        """
        서버 시작 시 KIS 해외주식 잔고 기반 포지션 자동 복원.
        """
        try:
            bal = self.api.get_us_balance()
            for h in bal.get("holdings", []):
                sym = h["symbol"]
                if sym not in self.pos_mgr.positions:
                    pos = USPosition(
                        sym, h.get("name", sym), h.get("excd", "NASD"),
                        h["qty"], h["avg_price"]
                    )
                    self.pos_mgr.add(pos)
                    logger.info(f"🔄 US 포지션 복원: {sym} {h['qty']}주 ${h['avg_price']:.2f}")
        except Exception as e:
            logger.warning(f"US 포지션 동기화 실패: {e}")
