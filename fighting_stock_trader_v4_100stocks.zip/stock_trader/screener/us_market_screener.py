"""
미국 증시 야간 분석기 (US Market Screener)
==========================================
매일 00:00 KST (미국 장마감 후) 자동 실행

분석 내용:
  1. 주요 지수 현황  — S&P500 / 나스닥 / 다우 / VIX / 공포탐욕지수
  2. 섹터별 강도     — 11개 섹터 ETF 등락률 + 강도 순위
  3. 핵심 종목 분석  — 빅테크 + 반도체 + 금융 등 30개 주요주
  4. 시장 국면 판단  — BULL / LATERAL / BEAR
  5. 한국 시장 영향  — 미국 마감 기준 내일 한국 시장 예측 방향
  6. 주목 종목 TOP10 — 기술적 매수 신호 발생 종목

데이터 소스: yfinance (Yahoo Finance)
실행 시간: 매일 00:00 KST (미국 동부 기준 전일 11:00 AM)
"""

import json
import os
from datetime import datetime, date
import pytz

try:
    import yfinance as yf
    import numpy as np
    import pandas as pd
    HAS_YFINANCE = True
except ImportError:
    HAS_YFINANCE = False

from utils.logger import get_logger

logger = get_logger("USMarketScreener")

KST = pytz.timezone("Asia/Seoul")
US_RESULT_FILE = os.path.join(os.path.dirname(__file__), "..", "data", "us_market.json")

# ── 주요 지수 ────────────────────────────────────────────────
US_INDICES = {
    "^GSPC":  {"name": "S&P 500",    "emoji": "🇺🇸"},
    "^IXIC":  {"name": "나스닥",      "emoji": "💻"},
    "^DJI":   {"name": "다우존스",    "emoji": "🏦"},
    "^VIX":   {"name": "VIX 공포지수","emoji": "😱"},
    "^TNX":   {"name": "미국10년채",  "emoji": "📈"},
    "DX-Y.NYB":{"name":"달러인덱스",  "emoji": "💵"},
    "GC=F":   {"name": "금",          "emoji": "🥇"},
    "CL=F":   {"name": "WTI원유",     "emoji": "🛢️"},
}

# ── 섹터 ETF ─────────────────────────────────────────────────
US_SECTORS = {
    "XLK":  "기술(Tech)",
    "XLF":  "금융(Finance)",
    "XLV":  "헬스케어",
    "XLE":  "에너지",
    "XLI":  "산업재",
    "XLC":  "통신서비스",
    "XLY":  "경기소비재",
    "XLP":  "필수소비재",
    "XLB":  "소재",
    "XLRE": "리츠(부동산)",
    "XLU":  "유틸리티",
}

# ── 스크리닝 풀 유니버스 100개 ──────────────────────────────
# ★ 매일 00:00 KST 전체 분석 → 상위 20개 자동 관심종목 등록
# ★ 선정 기준: 하루 5~30% 급등 가능, 유동성 충분, 테마 모멘텀
US_STOCKS = {
    # ══════════════════════════════════════════════════════════
    # [1] 레버리지 ETF — 지수 2~3배 증폭, 초고변동성
    # ══════════════════════════════════════════════════════════
    "TQQQ":  "나스닥100 3배레버리지",
    "SOXL":  "반도체 3배레버리지",
    "FNGU":  "빅테크 3배레버리지",
    "LABU":  "바이오 3배레버리지",
    "TNA":   "소형주 3배레버리지",
    "TECL":  "기술섹터 3배레버리지",
    "CURE":  "헬스케어 3배레버리지",
    "DPST":  "은행섹터 3배레버리지",
    "NAIL":  "주택건설 3배레버리지",
    "HIBL":  "S&P고베타 3배레버리지",
    "UVXY":  "VIX단기선물1.5배",
    "SPXL":  "S&P500 3배레버리지",
    "FAS":   "금융섹터 3배레버리지",
    "RETL":  "소매섹터 3배레버리지",

    # ══════════════════════════════════════════════════════════
    # [2] 암호화폐 / 블록체인 — 비트코인 연동 초고변동
    # ══════════════════════════════════════════════════════════
    "MSTR":  "마이크로스트래티지(BTC보유)",
    "COIN":  "코인베이스(암호화폐거래소)",
    "RIOT":  "라이엇플랫폼스(BTC채굴)",
    "MARA":  "마라홀딩스(BTC채굴)",
    "HUT":   "허트8(BTC채굴)",
    "CLSK":  "클린스파크(그린채굴)",
    "CIFR":  "사이퍼마이닝(채굴)",
    "WULF":  "테라울프(친환경채굴)",
    "IREN":  "아이렌(AI+채굴)",
    "BTBT":  "비트팜스(채굴)",
    "BFII":  "비트파이(채굴)",

    # ══════════════════════════════════════════════════════════
    # [3] AI / 양자컴퓨팅 — 2024~2025 핫 테마
    # ══════════════════════════════════════════════════════════
    "SMCI":  "슈퍼마이크로(AI서버)",
    "IONQ":  "아이온큐(양자컴퓨팅)",
    "RGTI":  "리게티컴퓨팅(양자)",
    "QUBT":  "퀀텀컴퓨팅Inc(양자)",
    "QBTS":  "D-Wave퀀텀(양자)",
    "SOUN":  "사운드하운드AI(음성AI)",
    "BBAI":  "빅베어AI(기업AI)",
    "UPST":  "업스타트(AI대출)",
    "NVDA":  "엔비디아(AI반도체리더)",
    "ARM":   "ARM홀딩스(CPU설계)",
    "AI":    "C3.ai(기업AI플랫폼)",
    "AMBA":  "암바렐라(엣지AI반도체)",
    "LSCC":  "래티스세미(엣지FPGA)",

    # ══════════════════════════════════════════════════════════
    # [4] 바이오 / 유전자편집 / 제약 — 임상결과 시 30~100%
    # ══════════════════════════════════════════════════════════
    "RXRX":  "리커전제약(AI신약)",
    "CRSP":  "크리스퍼테라퓨틱스(유전자편집)",
    "BEAM":  "빔테라퓨틱스(유전자편집)",
    "NTLA":  "인텔리아테라퓨틱스(유전자편집)",
    "EDIT":  "에디타스메디신(유전자편집)",
    "SAVA":  "카사바사이언스(알츠하이머)",
    "ARQT":  "아쿠아테라퓨틱스(피부)",
    "AGEN":  "에이전우스(면역항암)",
    "IOVA":  "아이오반스(세포치료)",
    "FATE":  "페이트테라퓨틱스(세포치료)",
    "ACAD":  "아카디아제약(신경계)",
    "PTGX":  "프로테나(신경퇴행)",
    "INSM":  "인스메드(폐질환)",
    "AUPH":  "오로비아제약(루푸스신장염)",
    "IMVT":  "이뮤노반트(자가면역)",
    "RLAY":  "릴레이테라퓨틱스(암치료)",
    "KYMR":  "카이메라테라퓨틱스(단백질분해)",

    # ══════════════════════════════════════════════════════════
    # [5] EV / 청정에너지 소형주
    # ══════════════════════════════════════════════════════════
    "RIVN":  "리비안(EV트럭)",
    "LCID":  "루시드모터스(EV럭셔리)",
    "CHPT":  "차지포인트(EV충전)",
    "BLNK":  "블링크차징(EV충전)",
    "PLUG":  "플러그파워(수소연료전지)",
    "FCEL":  "퓨얼셀에너지(연료전지)",
    "BE":    "블룸에너지(고체연료전지)",
    "NKLA":  "니콜라(수소트럭)",
    "EVGO":  "이브고(EV급속충전)",
    "PTRA":  "프로테라(EV버스)",
    "GOEV":  "카누(EV밴)",

    # ══════════════════════════════════════════════════════════
    # [6] 우주 / 방위 / 에어택시 소형주
    # ══════════════════════════════════════════════════════════
    "RKLB":  "로켓랩(우주발사체)",
    "LUNR":  "인투이티브머신스(달탐사)",
    "ASTS":  "AST스페이스모바일(우주인터넷)",
    "SPIR":  "스파이어글로벌(우주데이터)",
    "JOBY":  "조비에비에이션(에어택시)",
    "ACHR":  "아처에비에이션(에어택시)",
    "ASTR":  "아스트라스페이스(발사체)",
    "RDW":   "레드와이어(우주제조)",

    # ══════════════════════════════════════════════════════════
    # [7] 핀테크 / 소형 금융
    # ══════════════════════════════════════════════════════════
    "SOFI":  "소파이(핀테크뱅크)",
    "AFRM":  "어펌(BNPL)",
    "OPEN":  "오픈도어(프롭테크)",
    "HOOD":  "로빈후드(MZ증권)",
    "DAVE":  "데이브(소액대출앱)",
    "OPFI":  "오포테크(핀테크대출)",
    "FLYW":  "플라이와이어(교육금융결제)",

    # ══════════════════════════════════════════════════════════
    # [8] 반도체 중형 — 대형주보다 변동성 큼
    # ══════════════════════════════════════════════════════════
    "AMD":   "AMD(중형반도체)",
    "MU":    "마이크론(메모리반도체)",
    "WOLF":  "울프스피드(전력반도체)",
    "FORM":  "폼팩터(반도체테스트)",
    "ACLS":  "액셀리스테크(이온주입)",
    "AEHR":  "에어테스트(반도체번인)",
    "NVTS":  "나비타스세미(GaN반도체)",
    "POWI":  "파워인티그레이션(전력IC)",

    # ══════════════════════════════════════════════════════════
    # [9] 중국 테크 / 해외성장주 — 규제뉴스 시 급등락
    # ══════════════════════════════════════════════════════════
    "XPEV":  "샤오펑(중국EV)",
    "NIO":   "니오(중국EV)",
    "LI":    "리오토(중국EV)",
    "FUTU":  "푸투홀딩스(중국핀테크)",
    "TIGR":  "업타이거증권(중국증권)",

    # ══════════════════════════════════════════════════════════
    # [10] 밈주식 / 기타 고변동 특수종목
    # ══════════════════════════════════════════════════════════
    "PLTR":  "팔란티어(AI데이터)",
    "CLOV":  "클로버헬스(헬스테크밈)",
    "SPCE":  "버진갤럭틱(우주관광)",
    "GME":   "게임스탑(게임소매밈)",
    "AMC":   "AMC엔터(영화관밈)",
    "BBBY":  "베드배스앤비욘드(생활용품밈)",
    "WISH":  "컨텍스트로직(커머스)",
    "CPRX":  "카탈리스트바이오(희귀질환)",
}


def _safe_pct(cur, prev) -> float:
    """안전한 등락률 계산"""
    try:
        if prev and prev != 0:
            return round((cur - prev) / prev * 100, 2)
    except Exception:
        pass
    return 0.0


def _calc_rsi(series: "pd.Series", period: int = 14) -> float:
    """RSI 계산"""
    try:
        delta = series.diff()
        gain  = delta.clip(lower=0).rolling(period).mean()
        loss  = (-delta.clip(upper=0)).rolling(period).mean()
        rs    = gain / loss
        rsi   = 100 - (100 / (1 + rs))
        return round(float(rsi.iloc[-1]), 1)
    except Exception:
        return 50.0


def _calc_macd_signal(series: "pd.Series") -> str:
    """MACD 골든/데드크로스 판단"""
    try:
        ema12 = series.ewm(span=12).mean()
        ema26 = series.ewm(span=26).mean()
        macd  = ema12 - ema26
        sig   = macd.ewm(span=9).mean()
        if macd.iloc[-1] > sig.iloc[-1] and macd.iloc[-2] <= sig.iloc[-2]:
            return "골든크로스"
        elif macd.iloc[-1] < sig.iloc[-1] and macd.iloc[-2] >= sig.iloc[-2]:
            return "데드크로스"
        elif macd.iloc[-1] > sig.iloc[-1]:
            return "상승"
        else:
            return "하락"
    except Exception:
        return "—"


def _score_stock(hist: "pd.DataFrame") -> dict:
    """
    종목 기술적 분석 → 점수(0~100) 및 신호 반환
    ★ 변동성 중소형주 최적화:
      - 거래량 급증에 가장 높은 가중치
      - 단기 모멘텀(1일, 5일 등락률) 중시
      - 과매도 반등보다 상승 모멘텀 추종 위주
    """
    try:
        c = hist["Close"]
        v = hist["Volume"]

        cur   = float(c.iloc[-1])
        prev  = float(c.iloc[-2])
        pct   = _safe_pct(cur, prev)          # 1일 등락률

        ma5   = float(c.rolling(5).mean().iloc[-1])
        ma20  = float(c.rolling(20).mean().iloc[-1])
        ma60  = float(c.rolling(60).mean().iloc[-1]) if len(c) >= 60 else ma20
        rsi   = _calc_rsi(c)
        macd  = _calc_macd_signal(c)

        # 5일 등락률 (단기 모멘텀)
        pct5d = _safe_pct(cur, float(c.iloc[-6])) if len(c) >= 6 else pct

        # 52주 최고/최저
        high52    = float(c.tail(252).max()) if len(c) >= 252 else float(c.max())
        low52     = float(c.tail(252).min()) if len(c) >= 252 else float(c.min())
        from_high = _safe_pct(cur, high52)
        from_low  = _safe_pct(cur, low52)

        # 거래량 비율 (5일 평균 대비)
        vol_avg5  = v.rolling(5).mean().iloc[-1]
        vol_ratio = float(v.iloc[-1] / vol_avg5) if vol_avg5 > 0 else 1.0

        # ── 점수 계산 (변동성 종목 최적화) ──────────────────────
        score = 40.0   # 기본점수 낮게 시작 (엄격한 필터)

        # ① 가장 중요: 거래량 폭발 (단타 핵심 신호)
        if vol_ratio >= 5.0:  score += 20   # 5배 이상: 세력 진입 강력 신호
        elif vol_ratio >= 3.0: score += 14  # 3배 이상: 매우 강한 관심
        elif vol_ratio >= 2.0: score += 8   # 2배 이상: 관심 증가

        # ② 두 번째: 단기 모멘텀 (오늘 + 5일)
        if pct >= 5.0:   score += 15  # 오늘 +5% 이상: 강한 상승 모멘텀
        elif pct >= 3.0: score += 10  # 오늘 +3% 이상
        elif pct >= 1.0: score += 5   # 오늘 +1% 이상
        elif pct < -2.0: score -= 8   # 오늘 -2% 이하: 약세
        if pct5d >= 10.0:  score += 8  # 5일간 +10% 이상
        elif pct5d >= 5.0: score += 4

        # ③ 정배열 (MA 트렌드)
        if cur > ma5:   score += 5
        if cur > ma20:  score += 6
        if ma5  > ma20: score += 5

        # ④ RSI — 변동성 주식은 과열 허용 (50~80 구간이 매수 타이밍)
        if 45 <= rsi <= 70:  score += 8   # 최적 구간
        elif 35 <= rsi < 45: score += 3   # 약간 저평가
        elif rsi > 80:       score -= 5   # 단기 과열 경고
        elif rsi < 30:       score += 2   # 과매도 반등 (변동성 주식은 덜 신뢰)

        # ⑤ MACD
        if "골든" in macd:  score += 10  # 전환 시그널 강력
        elif "상승" in macd: score += 4
        if "데드"  in macd:  score -= 8

        # ⑥ 52주 고점 돌파 여부 (변동성 주식 핵심: 신고가 돌파 시 폭발)
        if from_high >= -3.0:   score += 10  # 52주 고점 3% 이내
        elif from_high >= -10.0: score += 4
        elif from_high < -50.0:  score -= 5  # 52주 저점 근처 = 약세

        score = max(0.0, min(100.0, score))

        # ── 신호 판정 (변동성 종목은 BUY 기준 엄격하게) ─────────
        if score >= 72:
            signal = "BUY"
        elif score <= 35:
            signal = "SELL"
        else:
            signal = "HOLD"

        return {
            "cur_price":   round(cur, 2),
            "pct_1d":      pct,
            "pct_5d":      round(pct5d, 2),
            "ma5":         round(ma5, 2),
            "ma20":        round(ma20, 2),
            "ma60":        round(ma60, 2),
            "rsi":         rsi,
            "macd":        macd,
            "from_high52": round(from_high, 1),
            "from_low52":  round(from_low, 1),
            "vol_ratio":   round(vol_ratio, 2),
            "score":       round(score, 1),
            "signal":      signal,
        }
    except Exception as e:
        logger.warning(f"종목 분석 실패: {e}")
        return {"score": 50.0, "signal": "HOLD", "pct_1d": 0.0}


def _detect_us_regime(sp500_pct: float, vix: float, nasdaq_pct: float) -> str:
    """
    미국 시장 국면 판단
      BULL:    S&P500 상승 + VIX 낮음
      BEAR:    S&P500 하락 + VIX 높음
      LATERAL: 그 외
    """
    if vix >= 30:
        return "BEAR"
    elif sp500_pct >= 0.3 and vix < 20:
        return "BULL"
    elif sp500_pct <= -0.5:
        return "BEAR"
    else:
        return "LATERAL"


def _korea_impact(us_regime: str, sp500_pct: float, nasdaq_pct: float, vix: float) -> dict:
    """
    미국 증시 → 내일 한국 시장 예측
    """
    if us_regime == "BULL":
        direction = "상승 예상"
        emoji     = "🟢"
        reason    = f"S&P500 {sp500_pct:+.2f}%, VIX {vix:.1f} (안정) → 코스피 동반 상승 기대"
        kospi_est = round(sp500_pct * 0.7, 2)   # 미국 대비 70% 연동
    elif us_regime == "BEAR":
        direction = "하락 예상"
        emoji     = "🔴"
        reason    = f"S&P500 {sp500_pct:+.2f}%, VIX {vix:.1f} (공포) → 코스피 동반 하락 주의"
        kospi_est = round(sp500_pct * 0.8, 2)
    else:
        direction = "보합/혼조"
        emoji     = "🟡"
        reason    = f"S&P500 {sp500_pct:+.2f}%, 방향성 불명확 → 관망 유효"
        kospi_est = round(sp500_pct * 0.5, 2)

    # 반도체 비중 높은 한국 시장은 나스닥 영향도 큼
    semicon_note = ""
    if nasdaq_pct >= 1.0:
        semicon_note = "💡 나스닥 강세 → 삼성전자·SK하이닉스 수혜 가능"
    elif nasdaq_pct <= -1.0:
        semicon_note = "⚠️ 나스닥 약세 → 반도체주 하락 압력 주의"

    return {
        "direction":   direction,
        "emoji":       emoji,
        "reason":      reason,
        "kospi_est":   kospi_est,
        "semicon_note": semicon_note,
    }


def run_us_screening() -> dict:
    """
    미국 증시 전체 분석 실행
    Returns: 분석 결과 dict (파일 저장 + 반환)
    """
    if not HAS_YFINANCE:
        logger.error("yfinance 미설치 — pip install yfinance")
        return {"error": "yfinance 미설치"}

    logger.info("🇺🇸 미국 증시 야간 분석 시작...")
    now_kst = datetime.now(KST).strftime("%Y-%m-%d %H:%M KST")
    result = {
        "analyzed_at": now_kst,
        "date":        date.today().isoformat(),
        "indices":     {},
        "sectors":     {},
        "stocks":      {},
        "regime":      "LATERAL",
        "korea_impact": {},
        "top_buy":     [],
        "summary":     {},
    }

    # ── 1. 주요 지수 ───────────────────────────────────────
    sp500_pct = 0.0
    nasdaq_pct = 0.0
    vix_val = 20.0

    for sym, meta in US_INDICES.items():
        try:
            hist = yf.Ticker(sym).history(period="5d")
            if hist.empty or len(hist) < 2:
                continue
            cur  = float(hist["Close"].iloc[-1])
            prev = float(hist["Close"].iloc[-2])
            pct  = _safe_pct(cur, prev)

            result["indices"][sym] = {
                "name":    meta["name"],
                "emoji":   meta["emoji"],
                "price":   round(cur, 2),
                "pct_1d":  pct,
            }
            if sym == "^GSPC":  sp500_pct  = pct
            if sym == "^IXIC":  nasdaq_pct = pct
            if sym == "^VIX":   vix_val    = cur
        except Exception as e:
            logger.warning(f"지수 {sym} 조회 실패: {e}")

    # ── 2. 섹터 분석 ───────────────────────────────────────
    sector_results = []
    for sym, name in US_SECTORS.items():
        try:
            hist = yf.Ticker(sym).history(period="30d")
            if hist.empty or len(hist) < 5:
                continue
            c   = hist["Close"]
            cur  = float(c.iloc[-1])
            prev = float(c.iloc[-2])
            pct  = _safe_pct(cur, prev)
            pct5d = _safe_pct(cur, float(c.iloc[-5])) if len(c) >= 5 else pct

            entry = {
                "symbol":  sym,
                "name":    name,
                "price":   round(cur, 2),
                "pct_1d":  pct,
                "pct_5d":  pct5d,
            }
            result["sectors"][sym] = entry
            sector_results.append(entry)
        except Exception as e:
            logger.warning(f"섹터 {sym} 조회 실패: {e}")

    # 섹터 강도 순위 (1일 등락률 기준)
    sector_results.sort(key=lambda x: x["pct_1d"], reverse=True)

    # ── 3. 핵심 종목 분석 ──────────────────────────────────
    buy_candidates = []
    for sym, name in US_STOCKS.items():
        try:
            hist = yf.Ticker(sym).history(period="90d")
            if hist.empty or len(hist) < 20:
                continue
            analysis = _score_stock(hist)
            analysis["symbol"] = sym
            analysis["name"]   = name
            result["stocks"][sym] = analysis

            if analysis["signal"] == "BUY":
                buy_candidates.append(analysis)
        except Exception as e:
            logger.warning(f"종목 {sym}({name}) 분석 실패: {e}")

    # TOP10 매수 후보 (점수 높은 순)
    buy_candidates.sort(key=lambda x: x["score"], reverse=True)
    result["top_buy"] = buy_candidates[:20]   # ★ 상위 20개 반환 (100개 풀 분석)

    # ── 4. 시장 국면 판단 ──────────────────────────────────
    regime = _detect_us_regime(sp500_pct, vix_val, nasdaq_pct)
    result["regime"] = regime

    # ── 5. 한국 시장 영향 ──────────────────────────────────
    result["korea_impact"] = _korea_impact(regime, sp500_pct, nasdaq_pct, vix_val)

    # ── 6. 요약 ────────────────────────────────────────────
    bull_sectors  = [s for s in sector_results if s["pct_1d"] > 0]
    bear_sectors  = [s for s in sector_results if s["pct_1d"] < 0]
    result["summary"] = {
        "regime":           regime,
        "sp500_pct":        sp500_pct,
        "nasdaq_pct":       nasdaq_pct,
        "vix":              round(vix_val, 2),
        "bull_sectors":     len(bull_sectors),
        "bear_sectors":     len(bear_sectors),
        "top_sector":       sector_results[0]["name"] if sector_results else "—",
        "worst_sector":     sector_results[-1]["name"] if sector_results else "—",
        "buy_candidates":   len(buy_candidates),
        "analyzed_at":      now_kst,
    }

    # ── 파일 저장 ───────────────────────────────────────────
    os.makedirs(os.path.dirname(US_RESULT_FILE), exist_ok=True)
    with open(US_RESULT_FILE, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    logger.info(
        f"✅ 미국 분석 완료 — 국면:{regime} | S&P500:{sp500_pct:+.2f}% | "
        f"VIX:{vix_val:.1f} | 매수후보:{len(buy_candidates)}개"
    )
    return result


def load_us_result() -> dict:
    """저장된 미국 분석 결과 로드"""
    try:
        if os.path.exists(US_RESULT_FILE):
            with open(US_RESULT_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception as e:
        logger.warning(f"미국 분석 결과 로드 실패: {e}")
    return {}


if __name__ == "__main__":
    result = run_us_screening()
    print(json.dumps(result["summary"], ensure_ascii=False, indent=2))
    print("\n🔺 매수 TOP5:")
    for s in result["top_buy"][:10]:
        print(f"  {s['name']}({s['symbol']}): ${s['cur_price']} | 점수:{s['score']} | RSI:{s['rsi']}")
