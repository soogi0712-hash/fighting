"""
해외주식 전략 매니저 (미국 주식 전용) — 급등주 단타 전략
==========================================================

★ 핵심 철학:
  "단타 위주 + 수익이 높으면 오래 가져간다"
  "아마존·애플 같은 무거운 대형주 NO → 변동성 높은 중소형주로 하루 30만원"

  1. 진입: 장중 급등 중인 종목만 매수
     - 장중 등락률 +3% 이상 (중소형주 기준 상향)
     - 거래량 전일 대비 2배 이상 (세력 유입)
     - 5분봉 기반 단기 RSI < 75 (과열 제외)
     - MA5 > MA20 (단기 정배열)

  2. 청산 — 3단계 수익 구간별 다른 전략:
     ① 단타 구간 (수익 0~+5%):  빠른 청산 → SELL 지표 2개면 즉시 매도
     ② 중간 구간 (+5~+15%):     트레일링 스탑 -3% (수익 지키기)
     ③ 급등 홀딩 (+15% 이상):   트레일링 스탑 -6% (더 먹기)

  3. 손절: -3% 빠른 손절 (중소형주 노이즈 감안)

  4. 목표 수익: 하루 $200~250 (약 30만원)
     - 1회 투자금 $800~1000
     - 하루 1~3회 거래 목표

★ 관심종목: 변동성 높은 중소형주 위주 (하루 5~20% 급등 가능 종목)
  - 바이오/제약, 소형 기술주, 테마주, 레버리지 ETF 등
  - 시총 $1B~50B 구간 (대형주 제외)

★ 포지션 파일: data/us_positions.json
"""

import os
import json
import time
import numpy as np
from datetime import datetime
from utils.logger         import get_logger
from utils.market_session import us_session_info, is_us_tradeable

logger = get_logger("USStrategy")

US_POSITIONS_FILE = os.path.join(
    os.path.dirname(__file__), "..", "data", "us_positions.json"
)

# ── 기본 관심종목 100개 풀 유니버스 ─────────────────────────
# ★ 선정 기준: 하루 5~30% 급등 가능, 유동성 충분, 테마 모멘텀
# ★ 매일 스크리닝 후 상위 20개가 자동으로 관심종목 갱신됨
# ★ 이 100개가 매 2분마다 전체 순환 체크됨
DEFAULT_US_WATCHLIST = {
    # ══════════════════════════════════════════════════════════
    # [1] 레버리지 ETF — 지수 2~3배 증폭, 초고변동성
    # ══════════════════════════════════════════════════════════
    "TQQQ":  {"name": "나스닥100 3배레버리지",      "excd": "NASD"},
    "SOXL":  {"name": "반도체 3배레버리지",          "excd": "NASD"},
    "FNGU":  {"name": "빅테크 3배레버리지",          "excd": "NYSE"},
    "LABU":  {"name": "바이오 3배레버리지",          "excd": "NYSE"},
    "TNA":   {"name": "소형주 3배레버리지",          "excd": "NYSE"},
    "TECL":  {"name": "기술섹터 3배레버리지",        "excd": "NYSE"},
    "CURE":  {"name": "헬스케어 3배레버리지",        "excd": "NYSE"},
    "DPST":  {"name": "은행섹터 3배레버리지",        "excd": "NYSE"},
    "NAIL":  {"name": "주택건설 3배레버리지",        "excd": "NYSE"},
    "HIBL":  {"name": "S&P고베타 3배레버리지",       "excd": "NYSE"},

    # ══════════════════════════════════════════════════════════
    # [2] 암호화폐 / 블록체인 — 비트코인 연동 초고변동
    # ══════════════════════════════════════════════════════════
    "MSTR":  {"name": "마이크로스트래티지(BTC보유)", "excd": "NASD"},
    "COIN":  {"name": "코인베이스(암호화폐거래소)",  "excd": "NASD"},
    "RIOT":  {"name": "라이엇플랫폼스(BTC채굴)",     "excd": "NASD"},
    "MARA":  {"name": "마라홀딩스(BTC채굴)",         "excd": "NASD"},
    "HUT":   {"name": "허트8(BTC채굴)",              "excd": "NASD"},
    "CLSK":  {"name": "클린스파크(그린채굴)",         "excd": "NASD"},
    "CIFR":  {"name": "사이퍼마이닝(채굴)",           "excd": "NASD"},
    "WULF":  {"name": "테라울프(친환경채굴)",         "excd": "NASD"},
    "IREN":  {"name": "아이렌(AI+채굴)",              "excd": "NASD"},
    "BTBT":  {"name": "비트팜스(채굴)",               "excd": "NASD"},

    # ══════════════════════════════════════════════════════════
    # [3] AI / 양자컴퓨팅 소형주 — 2024~2025 핫 테마
    # ══════════════════════════════════════════════════════════
    "SMCI":  {"name": "슈퍼마이크로(AI서버)",        "excd": "NASD"},
    "IONQ":  {"name": "아이온큐(양자컴퓨팅)",        "excd": "NYSE"},
    "RGTI":  {"name": "리게티컴퓨팅(양자)",          "excd": "NASD"},
    "QUBT":  {"name": "퀀텀컴퓨팅Inc(양자)",         "excd": "NASD"},
    "QBTS":  {"name": "D-Wave퀀텀(양자)",            "excd": "NYSE"},
    "SOUN":  {"name": "사운드하운드AI(음성AI)",       "excd": "NASD"},
    "BBAI":  {"name": "빅베어AI(기업AI)",            "excd": "NYSE"},
    "UPST":  {"name": "업스타트(AI대출)",             "excd": "NASD"},
    "AITX":  {"name": "AI테크놀로지(로봇보안)",       "excd": "NASD"},
    "GFAI":  {"name": "가드포스AI(보안로봇)",         "excd": "NASD"},
    "ARBB":  {"name": "아비트리지(차익거래AI)",       "excd": "NASD"},
    "PAYO":  {"name": "페이온어(핀테크AI)",           "excd": "NASD"},

    # ══════════════════════════════════════════════════════════
    # [4] 바이오 / 유전자편집 / 제약 — 임상결과 시 30~100%
    # ══════════════════════════════════════════════════════════
    "RXRX":  {"name": "리커전제약(AI신약)",           "excd": "NASD"},
    "CRSP":  {"name": "크리스퍼테라퓨틱스(유전자)",  "excd": "NASD"},
    "BEAM":  {"name": "빔테라퓨틱스(유전자편집)",    "excd": "NASD"},
    "NTLA":  {"name": "인텔리아테라퓨틱스(유전자)",  "excd": "NASD"},
    "EDIT":  {"name": "에디타스메디신(유전자)",       "excd": "NASD"},
    "SAVA":  {"name": "카사바사이언스(알츠하이머)",   "excd": "NASD"},
    "ARQT":  {"name": "아쿠아테라퓨틱스(피부)",      "excd": "NASD"},
    "AGEN":  {"name": "에이전우스(면역항암)",         "excd": "NASD"},
    "IOVA":  {"name": "아이오반스(세포치료)",         "excd": "NASD"},
    "FATE":  {"name": "페이트테라퓨틱스(세포치료)",  "excd": "NASD"},
    "NKTR":  {"name": "넥타테라퓨틱스(약물전달)",    "excd": "NASD"},
    "CRIS":  {"name": "큐리스(항암제)",               "excd": "NASD"},
    "ACAD":  {"name": "아카디아제약(신경계)",         "excd": "NASD"},
    "PTGX":  {"name": "프로테나(신경퇴행)",           "excd": "NASD"},
    "INSM":  {"name": "인스메드(폐질환)",             "excd": "NASD"},

    # ══════════════════════════════════════════════════════════
    # [5] EV / 청정에너지 소형주
    # ══════════════════════════════════════════════════════════
    "RIVN":  {"name": "리비안(EV트럭)",               "excd": "NASD"},
    "LCID":  {"name": "루시드모터스(EV럭셔리)",       "excd": "NASD"},
    "CHPT":  {"name": "차지포인트(EV충전)",            "excd": "NYSE"},
    "BLNK":  {"name": "블링크차징(EV충전)",            "excd": "NASD"},
    "PLUG":  {"name": "플러그파워(수소연료전지)",      "excd": "NASD"},
    "FCEL":  {"name": "퓨얼셀에너지(연료전지)",       "excd": "NASD"},
    "BE":    {"name": "블룸에너지(고체연료전지)",      "excd": "NYSE"},
    "NKLA":  {"name": "니콜라(수소트럭)",              "excd": "NASD"},
    "GOEV":  {"name": "카누(EV밴)",                   "excd": "NASD"},
    "EVGO":  {"name": "이브고(EV급속충전)",            "excd": "NASD"},

    # ══════════════════════════════════════════════════════════
    # [6] 우주 / 방위 / 드론 소형주
    # ══════════════════════════════════════════════════════════
    "RKLB":  {"name": "로켓랩(우주발사체)",           "excd": "NASD"},
    "LUNR":  {"name": "인투이티브머신스(달탐사)",     "excd": "NASD"},
    "ASTS":  {"name": "AST스페이스모바일(우주인터넷)","excd": "NASD"},
    "SPIR":  {"name": "스파이어글로벌(우주데이터)",   "excd": "NYSE"},
    "ASTR":  {"name": "아스트라스페이스(발사체)",     "excd": "NASD"},
    "MNTS":  {"name": "머큐어리시스템즈(방위AI)",     "excd": "NASD"},
    "JOBY":  {"name": "조비에비에이션(에어택시)",     "excd": "NYSE"},
    "ACHR":  {"name": "아처에비에이션(에어택시)",     "excd": "NYSE"},
    "LILM":  {"name": "릴리움(전동항공)",             "excd": "NASD"},

    # ══════════════════════════════════════════════════════════
    # [7] 핀테크 / 소형 금융
    # ══════════════════════════════════════════════════════════
    "SOFI":  {"name": "소파이(핀테크뱅크)",           "excd": "NASD"},
    "AFRM":  {"name": "어펌(BNPL)",                   "excd": "NASD"},
    "OPEN":  {"name": "오픈도어(프롭테크)",            "excd": "NASD"},
    "HOOD":  {"name": "로빈후드(MZ증권)",              "excd": "NASD"},
    "DAVE":  {"name": "데이브(소액대출앱)",            "excd": "NASD"},
    "CURO":  {"name": "큐로그룹(소비자금융)",          "excd": "NYSE"},
    "OPFI":  {"name": "오포테크(핀테크대출)",          "excd": "NYSE"},

    # ══════════════════════════════════════════════════════════
    # [8] 반도체 중형 — 대형주보다 변동성 큼
    # ══════════════════════════════════════════════════════════
    "AMD":   {"name": "AMD(중형반도체)",              "excd": "NASD"},
    "MU":    {"name": "마이크론(메모리반도체)",        "excd": "NASD"},
    "WOLF":  {"name": "울프스피드(전력반도체)",       "excd": "NYSE"},
    "FORM":  {"name": "폼팩터(반도체테스트)",         "excd": "NASD"},
    "ACLS":  {"name": "액셀리스테크(이온주입)",        "excd": "NASD"},
    "AEHR":  {"name": "에어테스트(반도체번인)",        "excd": "NASD"},
    "NVTS":  {"name": "나비타스세미(GaN반도체)",      "excd": "NASD"},
    "POWI":  {"name": "파워인티그레이션(전력IC)",     "excd": "NASD"},

    # ══════════════════════════════════════════════════════════
    # [9] 소형 성장주 / 밈주식급 고변동
    # ══════════════════════════════════════════════════════════
    "PLTR":  {"name": "팔란티어(AI데이터)",           "excd": "NYSE"},
    "CLOV":  {"name": "클로버헬스(헬스테크)",         "excd": "NASD"},
    "SPCE":  {"name": "버진갤럭틱(우주관광)",         "excd": "NYSE"},
    "WISH":  {"name": "컨텍스트로직(커머스)",         "excd": "NASD"},
    "CPRX":  {"name": "카탈리스트바이오(희귀질환)",   "excd": "NASD"},
    "XPEV":  {"name": "샤오펑(중국EV)",               "excd": "NYSE"},
    "NIO":   {"name": "니오(중국EV)",                 "excd": "NYSE"},
    "LI":    {"name": "리오토(중국EV)",               "excd": "NASD"},
    "FUTU":  {"name": "푸투홀딩스(중국핀테크)",       "excd": "NASD"},

    # ══════════════════════════════════════════════════════════
    # [10] 기타 고변동 테마주
    # ══════════════════════════════════════════════════════════
    "NKTR":  {"name": "넥타테라퓨틱스(약물전달)",    "excd": "NASD"},
    "PRTY":  {"name": "파티시티(파티용품소매)",       "excd": "NASD"},
    "SUNL":  {"name": "선라이트파이낸셜(태양광금융)", "excd": "NASD"},
    "RENN":  {"name": "렌런인크(중국SNS)",            "excd": "NYSE"},
    "PHVS":  {"name": "파비온헬스(제약)",             "excd": "NASD"},
    "LOVE":  {"name": "러브색(가구소매)",              "excd": "NYSE"},
}

# ── 핵심 파라미터 ─────────────────────────────────────────────
INVEST_PER_TRADE_USD = 800.0    # 1회 투자금 $800 (중소형주 변동성 감안 소폭 축소)

# 진입 조건 (중소형주 기준으로 상향 — 노이즈 제거)
ENTRY_INTRADAY_PCT   =  3.0    # 장중 등락률 최소 +3% (중소형주 노이즈 위 진입)
ENTRY_VOL_RATIO      =  2.0    # 거래량 전일 대비 2배 이상
ENTRY_RSI_MAX        = 75.0    # 단기 RSI 75 미만 (중소형주는 더 오버슈팅)

# 청산 — 구간별 트레일링 스탑 (중소형주 변동성 감안 확대)
STOP_LOSS_PCT        =  3.0    # 손절 -3% (중소형주 노이즈 감안 +1%)

# 수익 구간 경계 (중소형주 더 크게 움직이므로 구간 확대)
ZONE_MID             =  5.0    # +5% 이상 = 중간구간
ZONE_HIGH            = 15.0    # +15% 이상 = 급등 홀딩 구간

# 구간별 트레일링 스탑
TRAIL_ZONE_LOW       =  2.0    # 단타구간: 고점 대비 -2% (중소형 노이즈 감안)
TRAIL_ZONE_MID       =  3.0    # 중간구간: 고점 대비 -3%
TRAIL_ZONE_HIGH      =  6.0    # 급등구간: 고점 대비 -6% (더 먹기)

# 단타구간 매도 신호 임계
SELL_SCORE_FAST      =  2      # 단타구간: 매도지표 2개면 즉시 청산

# ── 추가매수 (급등 모멘텀 지속 시) ───────────────────────────
ADD_BUY_PCT          =  7.0    # +7% 수익 시 절반 추가 (중소형주 더 확인 후)
ADD_BUY_RATIO        =  0.5    # 추가매수 비율 (기존 투자금의 50%)
MAX_LEVEL            =  2      # 최대 2단계까지만


# ══════════════════════════════════════════════════════════════
# 지표 계산
# ══════════════════════════════════════════════════════════════

def _calc_indicators(candles: list[dict]) -> dict:
    """일봉 캔들 → 지표 계산 (급등 판단용)"""
    if len(candles) < 6:
        return {"score": 0, "sell_score": 0, "rsi": 50.0,
                "vol_ratio": 1.0, "intraday_pct": 0.0, "ma5": 0.0, "ma20": 0.0}

    closes  = np.array([c["close"]  for c in candles], dtype=float)
    opens   = np.array([c["open"]   for c in candles], dtype=float)
    volumes = np.array([c["volume"] for c in candles], dtype=float)
    highs   = np.array([c["high"]   for c in candles], dtype=float)

    cur  = closes[-1]
    prev = closes[-2] if len(closes) >= 2 else cur

    # ── 장중 등락률 (전일 종가 대비 오늘 현재가) ──────────────
    intraday_pct = float((cur - prev) / prev * 100) if prev > 0 else 0.0

    # ── MA ────────────────────────────────────────────────────
    ma5  = float(np.mean(closes[-5:]))
    ma20 = float(np.mean(closes[-20:])) if len(closes) >= 20 else ma5
    ma_bull = cur > ma5 > ma20

    # ── RSI(14) ──────────────────────────────────────────────
    if len(closes) >= 15:
        delta = np.diff(closes[-15:])
        gain  = np.where(delta > 0, delta, 0.0)
        loss  = np.where(delta < 0, -delta, 0.0)
        avg_g = float(np.mean(gain))
        avg_l = float(np.mean(loss))
        rsi   = 100.0 - (100.0 / (1 + avg_g / avg_l)) if avg_l > 0 else 50.0
    else:
        rsi = 50.0

    # ── 거래량 급증 ────────────────────────────────────────────
    vol_avg5  = float(np.mean(volumes[-6:-1])) if len(volumes) >= 6 else float(volumes[-1])
    vol_ratio = float(volumes[-1]) / vol_avg5 if vol_avg5 > 0 else 1.0

    # ── MACD ──────────────────────────────────────────────────
    def _ema(arr, span):
        k = 2 / (span + 1)
        r = [arr[0]]
        for v in arr[1:]:
            r.append(r[-1] * (1 - k) + v * k)
        return np.array(r)

    macd_above = False
    macd_cross = False
    if len(closes) >= 26:
        ema12 = _ema(closes, 12)
        ema26 = _ema(closes, 26)
        macd  = ema12 - ema26
        sig   = _ema(macd, 9)
        macd_above = macd[-1] > sig[-1]
        macd_cross = macd[-1] > sig[-1] and macd[-2] <= sig[-2]

    # ── 진입 점수 (급등 확인용) ─────────────────────────────────
    buy_score = 0
    if intraday_pct >= ENTRY_INTRADAY_PCT:  buy_score += 2   # 핵심: 장중 급등
    if vol_ratio    >= ENTRY_VOL_RATIO:     buy_score += 2   # 핵심: 거래량 폭발
    if ma_bull:                             buy_score += 1
    if macd_above or macd_cross:            buy_score += 1

    # ── 매도 점수 ────────────────────────────────────────────
    sell_score = 0
    if intraday_pct <= 0:         sell_score += 2   # 모멘텀 소멸
    if rsi > 80:                  sell_score += 2   # 단기 과열
    if not macd_above:            sell_score += 1
    if cur < ma5:                 sell_score += 1

    return {
        "score":        buy_score,
        "sell_score":   sell_score,
        "rsi":          round(rsi, 1),
        "vol_ratio":    round(vol_ratio, 2),
        "intraday_pct": round(intraday_pct, 2),
        "ma5":          round(ma5, 2),
        "ma20":         round(ma20, 2),
        "macd_above":   macd_above,
        "ma_bull":      ma_bull,
    }


# ══════════════════════════════════════════════════════════════
# 포지션 관리
# ══════════════════════════════════════════════════════════════

class USPosition:
    def __init__(self, symbol, name, excd, qty, avg_price):
        self.symbol        = symbol
        self.name          = name
        self.excd          = excd
        self.qty           = qty
        self.avg_price     = avg_price
        self.highest_price = avg_price   # 트레일링용 고점
        self.current_level = 1
        self.created_at    = datetime.now().isoformat()

    def update_high(self, price: float):
        if price > self.highest_price:
            self.highest_price = price

    def net_pct(self, cur_price: float) -> float:
        if self.avg_price <= 0:
            return 0.0
        return round((cur_price - self.avg_price) / self.avg_price * 100 - 0.25, 2)

    def to_dict(self) -> dict:
        return {
            "symbol":        self.symbol,
            "name":          self.name,
            "excd":          self.excd,
            "qty":           self.qty,
            "avg_price":     self.avg_price,
            "highest_price": self.highest_price,
            "current_level": self.current_level,
            "created_at":    self.created_at,
            "is_overseas":   True,
        }


class USPositionManager:
    def __init__(self):
        self.positions: dict[str, USPosition] = {}
        os.makedirs(os.path.dirname(US_POSITIONS_FILE), exist_ok=True)
        self._load()

    def _load(self):
        try:
            if os.path.exists(US_POSITIONS_FILE):
                data = json.load(open(US_POSITIONS_FILE, encoding="utf-8"))
                for sym, d in data.items():
                    p = USPosition(sym, d["name"], d["excd"],
                                   d["qty"], d["avg_price"])
                    p.highest_price = d.get("highest_price", d["avg_price"])
                    p.current_level = d.get("current_level", 1)
                    p.created_at    = d.get("created_at", "")
                    self.positions[sym] = p
                logger.info(f"[US포지션] {len(self.positions)}개 로드")
        except Exception as e:
            logger.warning(f"[US포지션] 로드 실패: {e}")

    def save(self):
        try:
            data = {sym: p.to_dict() for sym, p in self.positions.items()}
            with open(US_POSITIONS_FILE, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"[US포지션] 저장 실패: {e}")

    def add(self, pos: USPosition):
        self.positions[pos.symbol] = pos
        self.save()

    def remove(self, symbol: str):
        self.positions.pop(symbol, None)
        self.save()

    def update(self, symbol: str, qty: int, avg_price: float, level: int):
        if symbol in self.positions:
            p = self.positions[symbol]
            p.qty           = qty
            p.avg_price     = avg_price
            p.current_level = level
            self.save()


# ══════════════════════════════════════════════════════════════
# 전략 매니저
# ══════════════════════════════════════════════════════════════

class USStrategyManager:
    """
    급등주 단타 전략
    ─────────────────
    - 장중 +2% 이상 + 거래량 2배 이상 종목 진입
    - 수익 구간별 트레일링 스탑:
        0~+3%   → 빠른 청산 (단타)
        +3~+10% → 트레일링 -2%
        +10% 이상 → 트레일링 -5% (급등 홀딩)
    - 손절 -2% (빠른 손실 컷)
    """

    def __init__(self, kis_api, max_total_usd: float = 5000.0):
        self.api           = kis_api
        self.max_total_usd = max_total_usd
        self.pos_mgr       = USPositionManager()

    @property
    def positions(self) -> dict:
        return {sym: p.to_dict() for sym, p in self.pos_mgr.positions.items()}

    def run(self, stock: dict) -> dict:
        symbol = stock["symbol"]
        name   = stock.get("name", symbol)
        excd   = stock.get("excd", "NASD")
        sess   = us_session_info()

        if not sess["tradeable"]:
            return {"action": "SKIP", "symbol": symbol, "name": name,
                    "reason": f"미국 휴장({sess['session']})", "session": sess["session"]}

        # ── OHLCV + 현재가 ────────────────────────────────────
        candles = self.api.get_us_ohlcv(symbol, excd, count=60)
        if not candles or len(candles) < 6:
            return {"action": "SKIP", "symbol": symbol, "name": name,
                    "reason": "OHLCV 부족", "session": sess["session"]}

        price_data = self.api.get_us_current_price(symbol, excd)
        cur_price  = price_data.get("price", 0.0)
        if cur_price <= 0:
            cur_price = candles[-1]["close"]

        # ── 장중 등락률: KIS 현재가 API의 change_rate 우선 ──────
        # KIS가 당일 등락률 직접 제공 → 가장 정확
        intraday_pct = price_data.get("change_rate", 0.0)

        # ── 지표 계산 ─────────────────────────────────────────
        # candles의 마지막 봉 close를 현재가로 교체 (장중 반영)
        candles_live = candles[:-1] + [{**candles[-1], "close": cur_price}]
        iv = _calc_indicators(candles_live)

        # KIS 등락률이 있으면 우선 사용
        if intraday_pct != 0.0:
            iv["intraday_pct"] = round(float(intraday_pct), 2)

        pos = self.pos_mgr.positions.get(symbol)

        logger.info(
            f"[🇺🇸] {name}({symbol}) ${cur_price:.2f} "
            f"등락:{iv['intraday_pct']:+.1f}% "
            f"거래량:{iv['vol_ratio']:.1f}x "
            f"RSI:{iv['rsi']:.0f} "
            f"BUY점수:{iv['score']}/6"
            + (f" | 보유중 {pos.net_pct(cur_price):+.1f}%" if pos else "")
        )

        # ════════════════════════════════════════════════════
        # 보유 중 → 청산/추가매수 판단
        # ════════════════════════════════════════════════════
        if pos:
            pos.update_high(cur_price)
            net_pct  = pos.net_pct(cur_price)
            high_pct = (cur_price - pos.highest_price) / pos.highest_price * 100 \
                       if pos.highest_price > 0 else 0.0

            # ① 손절 -2%
            if net_pct <= -STOP_LOSS_PCT:
                return self._do_sell(symbol, name, excd, pos.qty, cur_price,
                                     f"손절 {net_pct:.1f}%", sess)

            # ② 구간별 트레일링 스탑
            max_net = pos.net_pct(pos.highest_price)   # 고점 기준 최대 수익률

            if max_net >= ZONE_HIGH:
                # 급등 홀딩 구간 (+10% 이상): 고점 대비 -5%에서 청산
                trail = TRAIL_ZONE_HIGH
                zone  = "급등홀딩"
            elif max_net >= ZONE_MID:
                # 중간 구간 (+3~10%): 고점 대비 -2%
                trail = TRAIL_ZONE_MID
                zone  = "중간"
            else:
                # 단타 구간 (0~3%): 빠른 청산
                trail = TRAIL_ZONE_LOW
                zone  = "단타"

            if high_pct <= -trail:
                return self._do_sell(symbol, name, excd, pos.qty, cur_price,
                                     f"트레일링({zone}) 고점대비{high_pct:.1f}%", sess)

            # ③ 단타 구간에서 매도 지표 2개 이상 → 즉시 청산
            if zone == "단타" and iv["sell_score"] >= SELL_SCORE_FAST:
                return self._do_sell(symbol, name, excd, pos.qty, cur_price,
                                     f"단타청산 매도지표{iv['sell_score']}개", sess)

            # ④ 모멘텀 완전 소멸 (등락률 마이너스 전환 + 거래량 감소)
            if iv["intraday_pct"] < -0.5 and iv["vol_ratio"] < 1.0 and net_pct > 0:
                return self._do_sell(symbol, name, excd, pos.qty, cur_price,
                                     f"모멘텀소멸 {iv['intraday_pct']:+.1f}%", sess)

            # ⑤ 추가매수: +5% 수익 + 급등 지속 중 → 1회만
            if (pos.current_level < MAX_LEVEL
                    and net_pct >= ADD_BUY_PCT
                    and iv["intraday_pct"] >= 1.0
                    and iv["vol_ratio"] >= 1.5):
                return self._do_add_buy(symbol, name, excd, pos, cur_price, sess, iv)

            return {
                "action":       "HOLD",
                "symbol":       symbol, "name": name,
                "price":        cur_price,
                "net_pct":      net_pct,
                "ind_score":    iv["score"],
                "sell_score":   iv["sell_score"],
                "trend_score":  0,
                "intraday_pct": iv["intraday_pct"],
                "vol_ratio":    iv["vol_ratio"],
                "rsi":          iv["rsi"],
                "session":      sess["session"],
                "reason":       f"[{zone}] 보유 {net_pct:+.1f}% | 고점대비{high_pct:.1f}% | trail-{trail}%",
            }

        # ════════════════════════════════════════════════════
        # 미보유 → 급등 진입 조건 체크
        # ════════════════════════════════════════════════════

        # 핵심 조건 1: 장중 +2% 이상 (급등 필터)
        if iv["intraday_pct"] < ENTRY_INTRADAY_PCT:
            return {
                "action":       "HOLD",
                "symbol":       symbol, "name": name,
                "price":        cur_price,
                "ind_score":    iv["score"],
                "sell_score":   iv["sell_score"],
                "trend_score":  0,
                "intraday_pct": iv["intraday_pct"],
                "vol_ratio":    iv["vol_ratio"],
                "rsi":          iv["rsi"],
                "session":      sess["session"],
                "reason":       f"급등 미충족 {iv['intraday_pct']:+.1f}% (기준 +{ENTRY_INTRADAY_PCT}%)",
            }

        # 핵심 조건 2: 거래량 2배 이상
        if iv["vol_ratio"] < ENTRY_VOL_RATIO:
            return {
                "action":       "HOLD",
                "symbol":       symbol, "name": name,
                "price":        cur_price,
                "ind_score":    iv["score"],
                "sell_score":   iv["sell_score"],
                "trend_score":  0,
                "intraday_pct": iv["intraday_pct"],
                "vol_ratio":    iv["vol_ratio"],
                "rsi":          iv["rsi"],
                "session":      sess["session"],
                "reason":       f"거래량 부족 {iv['vol_ratio']:.1f}x (기준 {ENTRY_VOL_RATIO}x)",
            }

        # 조건 3: RSI 과열 제외 (70 미만)
        if iv["rsi"] >= ENTRY_RSI_MAX:
            return {
                "action":       "HOLD",
                "symbol":       symbol, "name": name,
                "price":        cur_price,
                "ind_score":    iv["score"],
                "sell_score":   iv["sell_score"],
                "trend_score":  0,
                "intraday_pct": iv["intraday_pct"],
                "vol_ratio":    iv["vol_ratio"],
                "rsi":          iv["rsi"],
                "session":      sess["session"],
                "reason":       f"RSI 과열 {iv['rsi']:.0f} (기준 <{ENTRY_RSI_MAX})",
            }

        # ✅ 모든 조건 충족 → 급등 진입!
        return self._do_buy(symbol, name, excd, cur_price, sess, iv)

    # ── 매수 실행 ────────────────────────────────────────────
    def _do_buy(self, symbol, name, excd, cur_price, sess, iv) -> dict:
        qty = max(1, int(INVEST_PER_TRADE_USD / cur_price))

        result = self.api.buy_us(symbol, qty, cur_price, excd)
        order_ok = result.get("rt_cd") == "0"

        if not order_ok:
            logger.warning(f"⚠️ {symbol} 주문 이상 → 3초 후 잔고 재확인")
            time.sleep(3)
            try:
                bal   = self.api.get_us_balance()
                h_map = {h["symbol"]: h for h in bal.get("holdings", [])}
                if symbol in h_map:
                    h            = h_map[symbol]
                    actual_qty   = int(h.get("qty", qty))
                    actual_price = float(h.get("avg_price", cur_price))
                    pos = USPosition(symbol, name, excd, actual_qty, actual_price)
                    self.pos_mgr.add(pos)
                    logger.info(f"✅ {symbol} 잔고확인 자동등록 {actual_qty}주")
                    return self._buy_result(symbol, name, excd, actual_price,
                                            actual_qty, 1, sess, iv, "[잔고확인]")
                else:
                    return {"action": "BUY_FAIL", "symbol": symbol, "name": name,
                            "reason": result.get("msg1", "주문실패"), "session": sess["session"]}
            except Exception as e2:
                return {"action": "BUY_FAIL", "symbol": symbol, "name": name,
                        "reason": str(e2), "session": sess["session"]}

        pos = USPosition(symbol, name, excd, qty, cur_price)
        self.pos_mgr.add(pos)
        logger.info(
            f"🟢 US 급등진입 {name}({symbol}) "
            f"${cur_price:.2f}×{qty}주 "
            f"등락:{iv['intraday_pct']:+.1f}% 거래량:{iv['vol_ratio']:.1f}x"
        )
        return self._buy_result(symbol, name, excd, cur_price, qty, 1, sess, iv, "")

    def _do_add_buy(self, symbol, name, excd, pos: USPosition,
                    cur_price, sess, iv) -> dict:
        add_usd = INVEST_PER_TRADE_USD * ADD_BUY_RATIO
        add_qty = max(1, int(add_usd / cur_price))

        result = self.api.buy_us(symbol, add_qty, cur_price, excd)
        if result.get("rt_cd") != "0":
            return {"action": "BUY_FAIL", "symbol": symbol, "name": name,
                    "reason": result.get("msg1", "추가매수실패"), "session": sess["session"]}

        new_qty = pos.qty + add_qty
        new_avg = (pos.avg_price * pos.qty + cur_price * add_qty) / new_qty
        self.pos_mgr.update(symbol, new_qty, new_avg, 2)
        logger.info(f"🟢 US 추가매수 {symbol} {add_qty}주 ${cur_price:.2f} (모멘텀 지속)")
        return self._buy_result(symbol, name, excd, cur_price, add_qty, 2, sess, iv,
                                "[모멘텀 추가]")

    def _do_sell(self, symbol, name, excd, qty, cur_price, reason, sess) -> dict:
        result = self.api.sell_us(symbol, qty, cur_price, excd)
        if result.get("rt_cd") == "0":
            pos     = self.pos_mgr.positions.get(symbol)
            avg_p   = pos.avg_price if pos else cur_price
            pnl_usd = (cur_price - avg_p) * qty
            pnl_pct = (cur_price - avg_p) / avg_p * 100 if avg_p > 0 else 0.0
            self.pos_mgr.remove(symbol)
            logger.info(
                f"{'💰' if pnl_usd >= 0 else '🔴'} US 매도 {symbol} "
                f"{qty}주 ${cur_price:.2f} | PnL ${pnl_usd:+.2f} ({pnl_pct:+.1f}%) | {reason}"
            )
            return {
                "action":   "SELL",
                "symbol":   symbol, "name": name, "excd": excd,
                "price":    cur_price, "qty": qty,
                "pnl_usd":  round(pnl_usd, 2),
                "pnl_pct":  round(pnl_pct, 2),
                "reason":   reason,
                "session":  sess["session"],
                "currency": "USD",
            }
        return {"action": "SELL_FAIL", "symbol": symbol, "name": name,
                "reason": result.get("msg1", "매도실패"), "session": sess["session"]}

    def _buy_result(self, symbol, name, excd, price, qty, level, sess, iv, tag) -> dict:
        return {
            "action":       "BUY",
            "symbol":       symbol, "name": name, "excd": excd,
            "price":        price,  "qty":  qty,
            "amount_usd":   round(price * qty, 2),
            "level":        level,
            "ind_score":    iv["score"],
            "trend_score":  0,
            "intraday_pct": iv["intraday_pct"],
            "vol_ratio":    iv["vol_ratio"],
            "rsi":          iv["rsi"],
            "reason":       f"급등진입 {iv['intraday_pct']:+.1f}% {iv['vol_ratio']:.1f}x {tag}".strip(),
            "session":      sess["session"],
            "currency":     "USD",
        }

    def sync_from_balance(self):
        """서버 시작 시 KIS 잔고 기반 포지션 자동 복원"""
        try:
            bal = self.api.get_us_balance()
            for h in bal.get("holdings", []):
                sym = h["symbol"]
                if sym not in self.pos_mgr.positions:
                    pos = USPosition(sym, h.get("name", sym), h.get("excd", "NASD"),
                                     h["qty"], h["avg_price"])
                    self.pos_mgr.add(pos)
                    logger.info(f"🔄 US 포지션 복원: {sym} {h['qty']}주 ${h['avg_price']:.2f}")
        except Exception as e:
            logger.warning(f"US 포지션 동기화 실패: {e}")
